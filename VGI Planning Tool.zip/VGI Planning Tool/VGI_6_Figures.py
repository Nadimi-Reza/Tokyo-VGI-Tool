import warnings
import os,sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

import Global_Var as GV


warnings.filterwarnings('ignore')

Input_list=GV.Step_5_Input_list

# determine if application is a script file or frozen exe
if getattr(sys, 'frozen', False):
	application_path = os.path.dirname(sys.executable)
elif __file__:
	application_path = os.path.dirname(__file__)



def Report_func(attached_part,Output_list):
	row_falg = True
	for i in range(len(Output_list)):

		Base_path = application_path + "\\{}".format(Output_list[i][0])
		Base_path = Base_path + "\\{}".format(attached_part)
		df = pd.read_csv(Base_path)

		if len(df) > 0:
			if row_falg == True:
				df_header = list(df.columns)
				total = df.to_numpy()
				Month_data = np.array([i + 1] * len(total)).reshape(-1, 1)
				total = np.hstack((Month_data, total))
				row_falg = False
			else:
				df = df.to_numpy()
				Month_data = np.array([i + 1] * len(df)).reshape(-1, 1)
				df = np.hstack((Month_data, df))
				total = np.vstack((total, df))
	final_header = ['Month']
	for i in range(len(df_header)):
		final_header.append(df_header[i])
	total = pd.DataFrame(total, columns=final_header)
	return(total)


def Bar_Chart_func(values,categories,X_axis,Y_axis,Title,storing_place):
	bars=plt.bar(categories, values, color='skyblue', edgecolor='black')
	# Add value labels on top of each bar
	for bar in bars:
		height = bar.get_height()
		plt.text(
			bar.get_x() + bar.get_width() / 2,
			height,
			str(round(height,2)),  # round to nearest integer
			ha='center',
			va='bottom'
		)

	plt.xlabel(X_axis)
	plt.ylabel(Y_axis)
	plt.title(Title)
	plt.tight_layout()
	plt.savefig(storing_place)  # Saves as PNG by default

def Stacked_Area_func(df,Peak_data,storing_place):

	df_col=list(df.columns)

	# Create an hour column: 0.0, 0.5, ..., 23.5
	df['Hour'] = (df[df_col[0]] - 1) * 0.5

	# Set the index to the Settlement Period for plotting
	df.set_index('Hour', inplace=True)

	# Create figure and first axis
	fig, ax1 = plt.subplots(figsize=(12, 6))

	ax1.stackplot(
		df.index,
		df[df_col[1]],
		df[df_col[2]],
		labels=[df_col[1], df_col[2]],
		colors=['green', 'orange']
	)

	ax1.set_xlabel('Time [30-minute]')
	ax1.set_ylabel('TEPCO Power Generation [GW]')
	ax1.legend(loc='upper left')
	ax1.grid(False)

	# Create second y-axis sharing the same x-axis
	ax2 = ax1.twinx()

	# Plot the new data (e.g., Demand) on ax2
	Peak_data_col=list(Peak_data.columns)

	ax2.plot(
		df.index,
		Peak_data[Peak_data_col[0]],
		color='blue',
		label='Maximum BEV Charging Load',
		linewidth=2,
		linestyle='-',  # solid line
		marker='',  # no markers
		alpha=0.8
	)


	ax2.set_ylabel('Maximum BEV Charging Load [kW]')
	ax2.legend(loc='upper right')

	# Fix x-axis to show full hours: 0 to 23
	ax1.set_xticks(np.arange(0, 24, 1))  # Tick every hour
	ax1.set_xlim(0, 24)

	# Final touches
	plt.title('Daily peak load curve along with TEPCO power generation')
	plt.tight_layout()
	plt.savefig(storing_place)  # Saves as PNG by default

def Cluster_Columns_func(Zonal_BEV_Data,y_axis,title,storing_place):
	Zonal_col=list(Zonal_BEV_Data.columns)
	# Create a mapping from city name to its desired sort position
	Zone_order_map = {city: i for i, city in enumerate(GV.Main_14_Zone)}

	# Add a temporary sort column to the pivot DataFrame
	Zonal_BEV_Data['CitySortOrder'] = Zonal_BEV_Data[Zonal_col[0]].map(Zone_order_map)

	# Sort by city order and then by Code
	Zonal_BEV_Data = Zonal_BEV_Data.sort_values(by=['CitySortOrder', Zonal_col[1]])

	# Drop the temporary sort column if no longer needed
	Zonal_BEV_Data = Zonal_BEV_Data.drop(columns='CitySortOrder')
	Zonal_BEV_Data[Zonal_col[1]] = Zonal_BEV_Data[Zonal_col[1]].replace({1: 'Residential Charger', 2: 'Public Chargers'})

	# Step 1: Pivot to reshape for plotting
	plot_df = Zonal_BEV_Data.pivot(index=Zonal_col[0], columns=Zonal_col[1], values=Zonal_col[2])
	# Flatten the MultiIndex to regular columns
	plot_df = plot_df.reset_index()

	# Add a temporary sort column to the pivot DataFrame
	plot_df['CitySortOrder'] = plot_df[Zonal_col[0]].map(Zone_order_map)
	plot_df = plot_df.sort_values(by=['CitySortOrder'])
	plot_df = plot_df.drop(columns='CitySortOrder')

	# Get current column list
	cols = list(plot_df.columns)

	# Swap column 2 with column 3 (index 1 with index 2)
	cols[1], cols[2] = cols[2], cols[1]

	# Reorder DataFrame columns
	plot_df = plot_df[cols]

	# Step 2: Plot
	ax = plot_df.plot(kind='bar', figsize=(10, 6), color=['blue', 'red'])
	###################
	# Add value labels on top of each bar
	for container in ax.containers:
		for bar in container:
			height = bar.get_height()
			ax.text(
				bar.get_x() + bar.get_width() / 2,  # x position (center of bar)
				height,  # y position (top of bar)
				f'{height:.2f}',  # formatted label
				ha='center',
				va='bottom',
				rotation=90,  # rotate vertically
				fontsize=9
			)

	# Fix x-axis tick labels (if needed)
	ax.set_xticks(range(len(plot_df.index)))
	ax.set_xticklabels(plot_df[Zonal_col[0]], rotation=90, ha='right')

	# Axis labels and title
	ax.set_ylabel(y_axis)
	ax.set_title(title)
	ax.legend()

	plt.tight_layout()
	plt.savefig(storing_place)  # Saves as PNG by default

def Stacked_Columns_func(data,storing_place):
	# Charging types and energy flow labels
	charging_types = ['Slow Charging', 'Medium Charging', 'Fast Charging']

	df = pd.DataFrame({
		'G2V': data[:,0].tolist(),
		'V2G': data[:,1].tolist()
	}, index=charging_types)

	df_col = list(df.columns)

	# Transpose to get columns as x-axis and rows as stacked parts
	df_T = df.T

	# Plot stacked bar chart
	ax = df_T.plot(kind='bar', stacked=True, figsize=(8, 6), color=['blue', 'red','black'])

	# Add labels and title

	# ax.set_xlabel(df_col)
	ax.set_ylabel('Annual energy exchange per BEV [kWh]')

	ax.legend()
	plt.xticks(rotation=0)

	plt.tight_layout()
	plt.savefig(storing_place)  # Saves as PNG by default

def Cluster_Chart_Queue_func(df,storing_place):
	df_col=list(df.columns)
	# Plotting
	x = np.arange(len(df))  # the label locations
	width = 0.4  # width of the bars

	fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 8), sharex=True)

	# Plot medium
	ax1.bar(x - width / 2, df[df_col[1]], width, label=df_col[1], color='blue')
	ax1.set_xlabel('Time of day')
	ax1.set_ylabel('Number of BEVs in Fast Charging Queue')

	# Plot fast
	ax2.bar(x + width / 2, df[df_col[2]], width, label=df_col[2], color='red')
	ax2.set_xlabel('Time of day')
	ax2.set_ylabel('Number of BEVs in Medium Charging Queue')

	# Custom X-axis: show hour labels every 2 SPs
	hour_labels = list(range(1, 25))  # 1 to 24 hours
	hour_ticks = np.arange(1, 49, 2) - 1  # SP=1,3,5,... → index = 0,2,4,... → tick at every 2 SPs

	ax2.set_xticks(hour_ticks)
	ax2.set_xticklabels(hour_labels)

	# Layout
	plt.tight_layout()
	plt.savefig(storing_place)  # Saves as PNG by default

def Main_Function_Figures(Output_list,BEV_Num,Simulation_day):
	Directory_Path = application_path + '\\Figures'
	if not os.path.exists(Directory_Path):
		os.makedirs(Directory_Path)
	else:
		for filename in os.listdir(Directory_Path):
			file_path = os.path.join(Directory_Path, filename)
			if os.path.isfile(file_path):
				os.remove(file_path)

	# Figure 7 of the paper
	File_Name = GV.Step_5_Input_list[1]
	Total_BEV_Energy_Usage = Report_func(File_Name,Output_list)
	# Sum of each column
	row_sums = Total_BEV_Energy_Usage.sum(axis=0)

	G2V_init = np.array([row_sums[2], row_sums[3], row_sums[4]])/(BEV_Num*Simulation_day) #Annual charging amount (kWh) per BEV
	G2V=list(G2V_init*Simulation_day)
	row_sums = row_sums / 1000  # kWh to MWh

	values = [row_sums[2], row_sums[3] + row_sums[4]]  # kWh to MWh
	categories = ['Residential Charger', 'Public Chargers']
	X_axis = ''
	Y_axis = 'Total Battery Charging Energy [MWh]'
	Title = 'Total Charging Energy: {} [MWh]'.format(round(sum(values), 2))

	storing_place = Directory_Path + '\\Fig 7_Total annual energy delivered to BEVs.png'

	Bar_Chart_func(values, categories, X_axis, Y_axis, Title, storing_place)

	# Figure 8 of the paper
	File_Name = GV.Step_5_Input_list[2]
	Zonal_BEV_Energy_Usage = Report_func(File_Name,Output_list)
	# Sum of each column
	row_sums = Zonal_BEV_Energy_Usage.sum(axis=0)
	row_sums = row_sums / 1000  # kWh to MWh

	row_sums.index = row_sums.index.str.replace('_Home', '', regex=False)
	row_sums.index = row_sums.index.str.replace('_Public Medium Speed', '', regex=False)
	row_sums.index = row_sums.index.str.replace('_Public Fast Speed', '', regex=False)
	row_sums = row_sums[2:]

	Zonal_BEV_Data = row_sums.to_numpy().reshape(-1, 1)
	Charging_list = np.array([1, 2, 2] * len(GV.Main_14_Zone)).reshape(-1, 1)
	Zone_list = row_sums.index.to_numpy().reshape(-1, 1)
	storing_place = Directory_Path + '\\Fig 8_BEV charging energy demand across main zones.png'

	Zonal_col = ['Zone Name', 'Charger', 'Energy']

	Zonal_BEV_Data = pd.DataFrame(np.hstack((np.hstack((Zone_list, Charging_list)), Zonal_BEV_Data)), columns=Zonal_col)
	# Pivot table with sum of charge amounts for each city-code combination
	Zonal_BEV_Data = Zonal_BEV_Data.pivot_table(index=[Zonal_col[0], Zonal_col[1]], values=Zonal_col[2], aggfunc='sum')

	# Flatten the MultiIndex to regular columns
	Zonal_BEV_Data = Zonal_BEV_Data.reset_index()

	Zonal_BEV_Data[Zonal_col[2]] = Zonal_BEV_Data[Zonal_col[2]] / 1000  # kWh to MWh
	y_axis='Annual charging energy demand [MWh]'
	title='Total annual G2V energy supply'

	Cluster_Columns_func(Zonal_BEV_Data,y_axis,title,storing_place)



	##Figure 9 of the paper
	Col_name = list(Total_BEV_Energy_Usage.columns)
	Max_BEV_Charging_Load = Total_BEV_Energy_Usage[[Col_name[1]]]
	New_col = 'Max_BEV_Load'
	Max_BEV_Charging_Load[New_col] = Total_BEV_Energy_Usage[[Col_name[2], Col_name[3], Col_name[4]]].sum(axis=1)

	# Create a pivot table with SP as the index and max as the aggregation function
	pivot_table = Max_BEV_Charging_Load.pivot_table(index=Col_name[1], values=New_col, aggfunc='max')

	TEPCO_Peak_Day_Data = pd.read_excel(sys.path[0] + '\\' + Input_list[0])

	storing_place = Directory_Path + '\\Fig 9_Daily peak load curve along with TEPCO power generation.png'
	Stacked_Area_func(TEPCO_Peak_Day_Data, pivot_table, storing_place)

	##Figures 10 and 11 of the paper
	File_Name = GV.Step_5_Input_list[3]
	Zonal_BEV_Energy_Discharge = Report_func(File_Name, Output_list)
	Zonal_col=list(Zonal_BEV_Energy_Discharge.columns)
	Zonal_col.append('Total_SP')


	try:
		V2G_Annual_col=[col for col in Zonal_BEV_Energy_Discharge.columns if col.startswith('SP')]
		Zonal_BEV_Energy_Discharge[Zonal_col[-1]] = Zonal_BEV_Energy_Discharge[V2G_Annual_col].sum(axis=1)
		Zonal_BEV_Energy_Discharge_Ave_Daily = Zonal_BEV_Energy_Discharge[[Zonal_col[1], Zonal_col[2], Zonal_col[-1]]]

		# Pivot table with sum of charge amounts for each city-code combination
		Zonal_BEV_Energy_Discharge_Ave_Daily = Zonal_BEV_Energy_Discharge_Ave_Daily.pivot_table(index=[Zonal_col[1], Zonal_col[2]], values=Zonal_col[-1],aggfunc='sum')

		# Flatten the MultiIndex to regular columns
		Zonal_BEV_Energy_Discharge_Ave_Daily = Zonal_BEV_Energy_Discharge_Ave_Daily.reset_index()
		Zonal_Ave_col=list(Zonal_BEV_Energy_Discharge_Ave_Daily.columns)
		Zonal_BEV_Energy_Discharge_Ave_Daily[Zonal_Ave_col[-1]]=Zonal_BEV_Energy_Discharge_Ave_Daily[Zonal_Ave_col[-1]]/Simulation_day

		# Sum of Total_SP for each Charging Place
		V2G_daily = Zonal_BEV_Energy_Discharge_Ave_Daily.groupby(Zonal_Ave_col[1])[Zonal_Ave_col[2]].sum().reset_index()
		V2G_daily=V2G_daily.to_numpy()
		V2G_daily[:,1]=(V2G_daily[:,1]/BEV_Num)*Simulation_day #assuming to sell power everyday

		V2G=[V2G_daily[0,1]+V2G_daily[1,1],0,0]
		storing_place = Directory_Path + '\\Fig 10_Average energy flow under V2G and G2V programs.png'

		G2v_V2G=np.column_stack((G2V, V2G))
		Stacked_Columns_func(G2v_V2G, storing_place)

		storing_place = Directory_Path + '\\Fig 11_Daily peak load curve along with TEPCO power generation.png'
		y_axis='Average daily V2G energy supply [kWh]'
		title='Average daily V2G energy supply in terms of main zones'
		Cluster_Columns_func(Zonal_BEV_Energy_Discharge_Ave_Daily,y_axis,title, storing_place)
	except:
		pass


	#Figure 12 of the paper
	storing_place = Directory_Path + '\\Fig 12_Queue analysis_Fast and Medium charging stations.png'
	File_Name = GV.Step_5_Input_list[4]
	Total_Queue_Data = Report_func(File_Name, Output_list)
	Queue_col=list(Total_Queue_Data.columns)
	Total_Queue_Data=Total_Queue_Data[[Queue_col[1],Queue_col[3],Queue_col[4]]]
	Queue_col = list(Total_Queue_Data.columns)
	Total_Queue_Data = Total_Queue_Data.groupby(Queue_col[0])[[Queue_col[1], Queue_col[2]]].max().reset_index()
	Cluster_Chart_Queue_func(Total_Queue_Data, storing_place)






