import numpy as np
SoC=1
SoC_Flag=True
base_year=0
base_month=0
base_day=0
ts_day=1 #total simulation day

Tw_min=4 #Waiting Time assumes 4 hours for V2G program
V2G_Matrix_init=np.zeros((1,52)).astype('object') #columns include zone name (because of this, its type is object), , charging place, date, and 48 settlement periods
V2G_Matrix=np.zeros((1,52)).astype('object')
V2G_Matrix_Flag=False #The V2G matrix is available or not

Step_2_Input_list=['VGI_config_files\\Step1_Driver_Percentage_Main_Zones.xlsx','VGI_config_files\\Step1_Trips_Per_Day.xlsx','VGI_config_files\\Step1_Distance_Duration_Trip.xlsx','VGI_config_files\\Step1_Distance_Duration_Between two cities.xlsx','VGI_config_files\\Step1_Departure_Destination_Trip.xlsx']
Step_3_Input_list=['VGI_config_files\\Step2_BEV Cabin Heat Insulation.xlsx','VGI_config_files\\Step2_BEV Car Type.xlsx','VGI_config_files\\Step2_BEV General parameters.xlsx','VGI_config_files\\Step2_BEV Driving Cycles_JC08.xlsx',"VGI_config_files\\Step2_BEV Weather data.xlsx","VGI_config_files\\Step2_BEV Motor Efficiency.xlsx","VGI_config_files\\Step2_BEV Specific Heat.xlsx",'VGI_config_files\\Step2_BEV Solar Irradiance.xlsx']
Step_4_Input_list=['VGI_config_files\\Step3_Charging Station.xlsx']
Step_5_Input_list=['VGI_config_files\\Step4_TEPCO_Peak_Data_2023_7_18.xlsx','Step2_3_Total_Tokyo_BEV_Energy_Usage.csv','Step2_3_Zone_Based_BEV_Energy_Usage_Data.csv','Step2_3_Zone_Based_BEV_Vehicle_2_Grid.csv','Step2_3_Total_Tokyo_Maximum_Daily_BEV_Queue.csv']

Step1_Matrix_column_name = ['Year', 'Month', 'Week', 'Day', 'EV_ID', 'Driving Type', 'Departure_Time', 'Arrival_Time','From', 'To', 'Travel Distance [km]', 'First Departure Time [h]', 'Travel Time[h]','Arrival Time [h]', 'Duration of stay at To [h]', 'Second Departure Time [h]', 'EV living city','EV working city']

Main_14_Zone = np.array(["Tokyo wards",
						   "Tama area",
						   "Yokohama",
						   "Kawasaki",
						   "Sagamihara",
						   "Kanagawa",
						   "Saitama",
						   "Southern saitama",
						   "Northern saitama",
						   "Chiba",
						   "Northern chiba",
						   "Southwestern chiba",
						   "Eastern chiba",
						   "Southern ibaraki"])

BEV_Housetype=1 #it indicates if a current house is detached (1) or apartment (0)

Trip_Distination_3cases=['Home','Workplace','Others']
Charging_Strategy=['Home','Public Medium Speed','Public Fast Speed','Charging by house PV']

Trip_Module_Run_Flag = False  # If this flag is True, then the Trip Module will be implemented.
Model_V2G_Service_Flag=False #This flag is used to model whole system with (True) or without(False) V2G service

Unmanaged_Charging_Flag=True #This flag indicates if the G2V charging is carried out in the manageable or unmanageable way.

BEV_ID=0 #this variable stores the current BEV ID

Initial_Mat_Sqlit_Name='Initial_BEV_Matrix'
Initial_Matrix_col=['BEV_ID','BEV_Living_Zone','BEV_Working_Zone','Driver_type_weekdays']
Initial_BEV_Mat=0
Initial_Matrix_Existance_Flag=False
Total_simulation_day=0

math_counter=0
Commuter_Minuter_oneway=40 #the average trip duration obtained from the survey data by the typical average commute time in Tokyo (40 minutes each way)

