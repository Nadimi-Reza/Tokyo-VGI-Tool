import numpy as np
import pandas as pd
import math
import matplotlib.pyplot as plt
from scipy.optimize import minimize
import Global_Var as GV

Input_list=GV.Step_4_Input_list
Inp_charging_station=0

def Charging_Station_Data():
	return(pd.read_excel(Input_list[Inp_charging_station],sheet_name='Specification').fillna(0).to_numpy())


def Vehicle2Grid_Discharging_Optimization_Model(C_rate,battery_capacity,Tw,P_charge,SOC_current,SOC_Threshold,Zone_name,Start_Time,Date,Charging_place,Battery_Discharging_Eff,Battery_Charging_Eff):

	P_discharge=C_rate*battery_capacity*Battery_Discharging_Eff #initial C_rate is 0.2C or discharging the full battery in 5 hours. In other words, the vehicle discharges power as much as P_discharge in one hour

	def f(x):
		return ((SOC_current - P_discharge * x - SOC_Threshold) + ((Tw - x) * P_charge - x * P_discharge))

	x0 = [0]
	cons = ({'type': 'ineq',
	         'fun': lambda x: SOC_current - P_discharge * x - SOC_Threshold},
	        {'type': 'ineq',
	         'fun': lambda x: ((Tw - x) * P_charge*Battery_Charging_Eff - x * P_discharge)},
	        {'type': 'ineq',
	         'fun': lambda x: x})

	res = minimize(f, x0, constraints=cons)
	V2G_Discharge_Time_Mat(Zone_name, P_discharge, res.x[0], Start_Time, Date, Charging_place,Battery_Charging_Eff)
	return()

def V2G_Discharge_Time_Mat(Zone_name,P_discharge,T_discharge,Start_Time,Date,Charging_place,Battery_Charging_Eff):
	Col_before_time = 4

	Start_SP=Start_Time*2+Col_before_time #the value 3 is because of three data including zone name, charging place and date
	if GV.V2G_Matrix_Flag==True:
		GV.V2G_Matrix=np.vstack((GV.V2G_Matrix,GV.V2G_Matrix_init))
	else:
		GV.V2G_Matrix_Flag = True

	#####
	GV.V2G_Matrix[-1, 0] = GV.BEV_ID
	GV.V2G_Matrix[-1, 1] = Zone_name
	GV.V2G_Matrix[-1, 2] = Charging_place

	GV.V2G_Matrix[-1, 3] = Date

	###
	Com_SP = max(0,math.floor(T_discharge))
	GV.V2G_Matrix[-1,Start_SP:Start_SP + Com_SP] = Battery_Charging_Eff * P_discharge  # P_charge is in one hour, while V2G_Matrix is in 30-minute
	if (T_discharge - Com_SP) > 0:
		try:
			GV.V2G_Matrix[-1, Start_SP + Com_SP] = (P_discharge * Battery_Charging_Eff) * (T_discharge - Com_SP)
		except:
			pass

	return()


def Grid2Vehicle_Charging(CC_SoC_max,CC_SoC,CC_SoC_Index,CC_SoC_initial,CC_Charging_Station_Data,CC_SoC_Charging_Cycle,CC_duration,CC_powering_rate_row,Battery_Charging_Eff):


	SoC_CC_col=list(CC_SoC_Charging_Cycle.columns)

	CC_SoC[CC_SoC_Index, 2] += 1
	CC_SoC[CC_SoC_Index, 3] = min(CC_SoC_max - CC_SoC_initial, CC_duration * CC_Charging_Station_Data[CC_powering_rate_row, 1])*Battery_Charging_Eff  # CC_duration hours * power rating at home
	CC_SoC_Charging_Cycle.loc[CC_SoC_Index, SoC_CC_col[1]] = "{};{}".format(CC_SoC_Charging_Cycle.loc[CC_SoC_Index, SoC_CC_col[1]],str(CC_SoC[CC_SoC_Index, 3]))
	CC_SoC_Charging_Cycle.loc[CC_SoC_Index, SoC_CC_col[2]] = "{};{}".format(CC_SoC_Charging_Cycle.loc[CC_SoC_Index, SoC_CC_col[2]], str(CC_SoC[CC_SoC_Index, 1]))
	CC_SoC_Charging_Cycle.loc[CC_SoC_Index, SoC_CC_col[3]] = "{};{}".format(CC_SoC_Charging_Cycle.loc[CC_SoC_Index, SoC_CC_col[3]], str(CC_Charging_Station_Data[CC_powering_rate_row, 0]))
	CC_SoC_Charging_Cycle.loc[CC_SoC_Index, SoC_CC_col[4]] = "{};{}".format(CC_SoC_Charging_Cycle.loc[CC_SoC_Index, SoC_CC_col[4]], str(GV.BEV_Date))


	CC_SoC[CC_SoC_Index, 1]=CC_SoC_initial+CC_SoC[CC_SoC_Index, 3]
	CC_SoC_initial = CC_SoC[CC_SoC_Index, 1]


	return(CC_SoC,CC_SoC_Charging_Cycle,CC_SoC_initial)

def Charging_Timestamp(CT_SoC_initial,CT_SoC_current,CT_Powering_rate_row,CT_Charging_Station,CT_Arrival_Time,CT_Departure_Time,CT_Timestamp,Battery_Charging_Eff):


	# SP=CT_Duration*2 #SP stands for settlement period: hour is converted to 30-minutes
	SP_power_rate=(CT_Charging_Station[CT_Powering_rate_row,1]/2)*Battery_Charging_Eff #amount of charge per each SP

	# CT_Powering_rate=CT_Charging_Station[CT_Powering_rate_row,1]
	CT_Timestamp_col_start = int(math.floor(CT_Arrival_Time * 2))+1

	CT_Timestamp_col_finish = int(math.floor(CT_Departure_Time * 2))

	if CT_Timestamp_col_start > CT_Timestamp_col_finish:
		CT_Timestamp_col_finish=48+CT_Timestamp_col_finish
		# CT_Timestamp_col_start = CT_Timestamp_col_finish



	SP_Number = math.ceil(((CT_SoC_initial - CT_SoC_current)) / SP_power_rate)
	Round_coeff = SP_Number - ((CT_SoC_initial - CT_SoC_current)) / SP_power_rate

	Allowance_Flag=True
	if (CT_Timestamp_col_finish-CT_Timestamp_col_start)<(SP_Number+math.ceil(Round_coeff)):
		CT_Timestamp_col_finish=CT_Timestamp_col_start+SP_Number
		Round_coeff=0
		Allowance_Flag=False

	if CT_Powering_rate_row==0:
		if GV.Unmanaged_Charging_Flag == True:
			CT_Timestamp_col_finish = CT_Timestamp_col_start + (SP_Number + math.ceil(Round_coeff))
		else:
			if Allowance_Flag==True:
				CT_Timestamp_col_start=int(math.floor(np.random.uniform(CT_Timestamp_col_start,CT_Timestamp_col_finish-SP_Number)))
				CT_Timestamp_col_finish = int(math.floor(CT_Timestamp_col_start+SP_Number))

		CT_Timestamp[CT_Timestamp_col_start:CT_Timestamp_col_finish, CT_Powering_rate_row]=SP_power_rate
		CT_Timestamp[CT_Timestamp_col_start, CT_Powering_rate_row] = SP_power_rate*Round_coeff
	else:
		CT_Timestamp_col_start = CT_Timestamp_col_start
		CT_Timestamp_col_finish = CT_Timestamp_col_start+SP_Number
		CT_Timestamp[CT_Timestamp_col_start:CT_Timestamp_col_finish, CT_Powering_rate_row] = SP_power_rate
		CT_Timestamp[CT_Timestamp_col_finish, CT_Powering_rate_row] = SP_power_rate * Round_coeff

	return(CT_Timestamp)

def Charging_G2V_plot(C_G2V_data,agg_func):
	if agg_func=='mean':
		agg_suff='_Mean'
	elif agg_func=='sum':
		agg_suff='_Mean' #although it runs sum function, but calculates the mean value
	elif agg_func=='max':
		agg_suff = '_Max'
	else:
		agg_suff = '_Total'

	Fixed_rows=48
	G2V_columns=list(C_G2V_data.columns)
	repeat_rows=int(round(C_G2V_data.shape[0]/Fixed_rows))
	rows=np.array(np.arange(1,Fixed_rows+1).tolist()*repeat_rows).reshape(-1,1)
	C_G2V_data=C_G2V_data.to_numpy()
	C_G2V_data=C_G2V_data[:len(rows),:]
	G2V_New_Col=['Settlement Period']
	for i in range(len(G2V_columns)):
		G2V_New_Col.append(G2V_columns[i])
	C_G2V_data=pd.DataFrame(np.hstack((rows,C_G2V_data)),columns=G2V_New_Col)

	C_G2V_pivot_mean = pd.pivot_table(C_G2V_data, values=G2V_columns, index=G2V_New_Col[0], aggfunc=agg_func)
	# C_G2V_pivot_std = pd.pivot_table(C_G2V_data, values=G2V_columns, index=G2V_New_Col[0], aggfunc="std")

	C_G2V_pivot_mean = C_G2V_pivot_mean.add_suffix(agg_suff)
	# C_G2V_pivot_std = C_G2V_pivot_std.add_suffix('_Standard deviation')

	G2V_New_Col = ['Settlement Period']

	col_name = list(C_G2V_pivot_mean.columns)

	for j in range(len(col_name)):
		G2V_New_Col.append(col_name[j])

	x = np.array(np.arange(1, Fixed_rows + 1))

	Figure_Flag=False
	if Figure_Flag==True:
		C_G2V_pivot_mean = np.array(C_G2V_pivot_mean.values.astype(int))


		y1=C_G2V_pivot_mean[:,0]
		y2=C_G2V_pivot_mean[:,1]
		y3=C_G2V_pivot_mean[:,2]

		plt.figure(figsize=(5, 2.7), layout='constrained')
		plt.plot(x, y1, label=G2V_columns[0])
		plt.plot(x, y2, label=G2V_columns[1])
		plt.plot(x, y3, label=G2V_columns[2])
		plt.xlabel('Settlement Period [30-minute]')
		plt.ylabel('Charging Power [kW]')
		plt.title("Average Daily Grid2vehicle Charging Power")
		plt.legend()
		plt.show()

	C_G2V_pivot_mean_std=np.hstack((x.reshape(-1,1),C_G2V_pivot_mean))


	return(pd.DataFrame(C_G2V_pivot_mean_std,columns=G2V_New_Col))












