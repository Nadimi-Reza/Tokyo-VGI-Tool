#VGI Planning Tool
#The Vehicle Grid Integration (VGI) Planning Tool is a simulation application designed to model the large-scale deployment of battery electric vehicles (BEVs) in the Tokyo Metropolitan area, Japan.
# The tool integrates several modules to simulate driving behavior, electricity consumption, and charging infrastructure planning.

#Project Structure
#The application is composed of seven main Python scripts along with a global variables script that shares common variables across modules:
#VGI_0_Main_Function.py – Main script to initialize and run the simulation.
#Step1_Report_Module.py – Generates Excel-based output reports, including both aggregated results for the Tokyo Metropolitan Area and detailed reports by zone.
#Step2_EV_Driving_Profile_Module.py – Simulates EV driving behavior and generates trip data.
#Step3_EV_Electricity_Consumption_Module.py – Calculates energy consumption for BEV trips, supporting both Vehicle-to-Grid (V2G) and Grid-to-Vehicle (G2V) directions.
#Step4_EV_Charging_Power_Rating_Module.py – Computes charging power profiles and state of charge (SoC) for G2V; V2G events are modeled without altering SoC.
#VGI_5_Initial_Matrix.py - Creates an initial matrix with data such as BEV ID, residential and workplace locations, and BEV driver types, which are then replicated for each month.
#VGI_6_Figures.py - This script generates and saves all the paper's figures as a report inside the Figures folder, located in the main directory (i.e., the directory where the VGI Planning Tool is executed).
#VGI_Global_Variables.py – Stores global variables used by all modules.


#How to Use
#Before running the simulation, you must define the following initial parameters:
#Output_list – Name of the output directory (e.g., Output_VGI_Files). This folder will be created inside the main directory and will store all resulting Excel output files.
#BEV_Num – Number of battery electric vehicles to simulate.
#Selected_Month – Specifies the months for which the simulation should run.
#Simulation_year – The year for which the simulation is to be conducted.
#Three operational flags – These control the activation of the trip simulation module, V2G service, and the selection between managed or unmanaged BEV charging methods.


#Once parameters are set, execute the tool by running: python VGI_0_Main_Function.py


#This project is licensed under the MIT License. See the LICENSE file for details.


#Citation
#If you use this tool in your research, please cite the following paper:
"Vehicle Grid Integration Planning Tool: Novel Approach in Case of Tokyo"

#Author Name(s): Reza Nadimi, Mika Goto
#Affiliation: Department of Innovation Science, School of Environment and Society, Institute of Science Tokyo, Tokyo, Japan
#DOI:

import shutil
import warnings
import os,sys
import calendar
import multiprocessing
from joblib import Parallel, delayed


import VGI_1_Report_Module as Step1_Module
import VGI_5_Initial_Matrix as Step5_Module
import VGI_6_Figures as Step6_Module
import Global_Var as GV


warnings.filterwarnings('ignore')

Input_list=GV.Step_5_Input_list

# determine if application is a script file or frozen exe
if getattr(sys, 'frozen', False):
	application_path = os.path.dirname(sys.executable)
elif __file__:
	application_path = os.path.dirname(__file__)

if __name__ == "__main__":

	#Initial Parameters
	Percentage_CPU_2_Run=50 #It utilizes part of the CPU to run VGI Planning Tool application. please selecet a value between 10 to 100 %
	Output_Directory = ['Output_VGI_Files'] #Name of the output directory. This folder will be created inside the main directory and will store all resulting Excel output files.
	BEV_Num=100  # Number of battery electric vehicles in VGI simulation.
	Selected_Month =[1,2,3,4,5,6,7,8,9,10,11,12] #The BEV simulation is executed concurrently for each month using Python's Parallel Computing Library.
	Simulation_year = 2023  # Simulation year: weather data has been set for 2023
	GV.Trip_Module_Run_Flag=True #if this Flag is true, then the trip module will run, otherwise, generated trip data in the last time will be used
	GV.Model_V2G_Service_Flag = False  # This Flag is used to model whole system with V2G service (True) or without V2G service (False)
	GV.Unmanaged_Charging_Flag=True #This flag indicates if the G2V charging is carried out in the manageable (False) or unmanageable (True) way.
	GV.Initial_Matrix_Existance_Flag=False  #this flag indicates if the Initial matrix is available or not.

	# Convert month numbers to strings for comparison
	Valid_dirs = {f"{Output_Directory[0]}_{month}" for month in Selected_Month}
	# Loop through all items in the base directory
	for item in os.listdir(application_path):
		item_path = os.path.join(application_path, item)
		if os.path.isdir(item_path) and item.startswith(f"{Output_Directory[0]}_"):
			# Check if the directory is not in the valid list
			if item not in Valid_dirs:
				shutil.rmtree(item_path)



	if GV.Initial_Matrix_Existance_Flag==False:
		Step5_Module.Initial_Matrix_Generation(BEV_Num)

	# Create a dictionary to store the number of days per month
	days_in_month=[calendar.monthrange(Simulation_year, month)[1] for month in range(1, 13)]


	Output_list = []
	Inp_Parameters = []
	
	for i in range(len(Selected_Month)):
		Parm = []
		Output_list.append(['{}_{}'.format(Output_Directory[0],Selected_Month[i])])
		Parm.append(BEV_Num)
		Parm.append(Output_list[i])
		Parm.append(Selected_Month[i])
		Parm.append(days_in_month[Selected_Month[i]-1])
		Parm.append(Simulation_year)
		Parm.append(GV.Trip_Module_Run_Flag)
		Parm.append(GV.Model_V2G_Service_Flag)
		Parm.append(GV.Unmanaged_Charging_Flag)
		Inp_Parameters.append(Parm)
		GV.Total_simulation_day += days_in_month[Selected_Month[i] - 1]

	# Get the total number of available CPU cores
	total_cores = multiprocessing.cpu_count()

	if Percentage_CPU_2_Run==100:
		num_jobs=-1 #n_jobs=-1: Use all available CPU cores;
	else:
		num_jobs = max(1, int(round(total_cores *Percentage_CPU_2_Run/100,0)))

	Parallel(n_jobs=num_jobs, backend='multiprocessing')(delayed(Step1_Module.Main_func_Step1)(Inp_Parameters[j]) for j in range(len(Inp_Parameters)))

	Step6_Module.Main_Function_Figures(Output_list,BEV_Num,GV.Total_simulation_day)













