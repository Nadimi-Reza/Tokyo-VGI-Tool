import difflib
import math
from datetime import datetime
import numba
import numpy as np
import pandas as pd
from numba import jit
import itertools
import VGI_4_Charging_Power_Rating_Module as Step4_Module
import Global_Var as GV


Charging_Station_Data=Step4_Module.Charging_Station_Data()
Input_list=GV.Step_3_Input_list



Trip_Distination_3cases=['Home','Workplace','Others']
Charging_Strategy=['Home','Public Medium Speed','Public Fast Speed']
#order of data in the Input_list
Inp_cabin_heat=0
Inp_car_type=1
Inp_general_parameters=2
Inp_driving_cycle=3
Inp_weather_data=4
Inp_motor_efficiency=5
Inp_air_specific_heat=6
Inp_solar_irradiance=7

Surface_transmissivity=0.5

#VTE_AS_col stands for the column number of the VTE_Actual_speed matrix
VTE_AS_year_col = 0
VTE_AS_month_col = 1
VTE_AS_week_col = 2
VTE_AS_day_col = 3
VTE_AS_EVID_col = 4
VTE_AS_Drtype_col = 5
VTE_AS_Depdate_col = 6
VTE_AS_Arrdate_col = 7
VTE_AS_From_col = 8
VTE_AS_To_col = 9
VTE_AS_TraDis_col = 10
VTE_AS_DepTime1_col = 11
VTE_AS_TrTime_col = 12
VTE_AS_ArrTime_col = 13
VTE_AS_StayTime_col = 14
VTE_AS_DepTime2_col = 15
VTE_AS_EV_Live_city_col = 16
VTE_AS_EV_Work_city_col = 17



GRAVITY = 9.81 # m/s2
ROAD_TYPE=0
ROAD_SLOPE=0

class Weather_Data_class:
    # def __init__(self):
    #     pass


    @staticmethod
    def Saturated_Vapor_Pressure_func(SVP_Inp):
        # Saturated_Vapor_Pressure equation has been obtained from https://bmcnoldy.earth.miami.edu/Humidity.html
        #Saturated_Vapor_Pressure=EXP((17.625*Input)/(243.04+Input))
        # Input is either Dew point or air temperature in degree Celsius.
        return (np.exp((17.625 * SVP_Inp) / (243.04 + SVP_Inp)))


    def Relative_Humidity_func(self,RH_dp, RH_t):
        # relative humidity equation has been obtained from https://bmcnoldy.earth.miami.edu/Humidity.html
        #RH: =100*(EXP((17.625*TD)/(243.04+TD))/EXP((17.625*T)/(243.04+T)))
        # based on emobpy: 100*Saturated_Vapor_Pressure_func(RH_dp)/Saturated_Vapor_Pressure_func(RH_t)
        return (100*self.Saturated_Vapor_Pressure_func(RH_dp)/self.Saturated_Vapor_Pressure_func(RH_t))


    def Dew_Point_func(self,DP_RH, DP_t):
        # dew point equation has been obtained from https://bmcnoldy.earth.miami.edu/Humidity.html
        #TD: =243.04*(LN(RH/100)+((17.625*T)/(243.04+T)))/(17.625-LN(RH/100)-((17.625*T)/(243.04+T)))
        # based on emobpy: 100*Saturated_Vapor_Pressure_func(RH_dp)/Saturated_Vapor_Pressure_func(RH_t)
        return (243.04*(np.log(DP_RH/100)+self.Saturated_Vapor_Pressure_func(DP_t))/(17.625-np.log(DP_RH/100)-self.Saturated_Vapor_Pressure_func(DP_RH)))

    def Air_Density_func(self,AD_pressure,AD_temperature):
        #This function calculates the air density for dry air based on ideal gas equation https://en.wikipedia.org/wiki/Density_of_air
        #Air_density in [kg/m3]=pressure in [pascal]/(Specific gas constant (sgc)*Temperature in [Kelvin])
        sgc=287.05 #Joule/(kg.Kelvin)
        AD_temperature_K=AD_temperature+ 273.15
        return(AD_pressure/(sgc*AD_temperature_K))




@jit(nopython=True)
def Acceleration_func(Vfirst, Vthird):
    #This function calculates the amount of acceleration for two speed data
    #km/hour to m/second: 1000/3600=1/3.6
    return ((Vthird - Vfirst) / 2 / 3.6)


@jit(nopython=True)
def Acceleration_Array_func(AA_Inp_Mat):
    #This function calculates the amount of acceleration for whole duration/distance
    AA_Inp_Mat=[Acceleration_func(a, b) for a, b in zip(AA_Inp_Mat[0:-2], AA_Inp_Mat[2:])]
    return (AA_Inp_Mat)



@numba.jit(nopython=True)
def Gravity_Force_func(GF_EV_mass,  slop_angle=0):
    #Gravity power=Gravity force*EV speed
    return (GF_EV_mass * GRAVITY * np.sin(np.deg2rad(slop_angle)))

@numba.jit(nopython=True)
def Rotational_Inertia_Force_func(RIF_EV_Passanger_mass, RIF_Inertial_mass, RIF_ACC):
    return ((RIF_EV_Passanger_mass+RIF_Inertial_mass) * RIF_ACC )


@numba.jit(nopython=True)
def Rolling_Resistance_Coeff(RRC_Temp,RRC_speed,road_type=0):
    factor = [1, 1.5, 2.2, 4, 20]
    return (1.9e-6 * RRC_Temp ** 2 - 2.1e-4 * RRC_Temp + 0.013 + 5.4e-5 * RRC_speed)* factor[road_type]



@numba.jit(nopython=True)
def Rolling_Resistance_Force_func(RRF_RR_Coeff,RRF_EV_mass,slop_angle=0):
    return RRF_RR_Coeff * RRF_EV_mass * GRAVITY * np.cos(np.deg2rad(slop_angle))


def Aerodynamic_Drag_Force_func(ADF_air_density, ADF_frontal_area, ADF_drag_coeff, ADF_EV_speed, ADF_wind_speed=0):
    return (1 / 2 * ADF_air_density * ADF_frontal_area * ADF_drag_coeff * (ADF_EV_speed - ADF_wind_speed) ** 2)


def EV_HVAC_func(HVAC_air_density,HVAC_row,HVAC_weather,HVAC_T_target,HVAC_cab_vol,HVAC_flow_air,HVAC_HI_Parameter,HVAC_EV_speed,HVAC_Q_sensible,HVAC_person,HVAC_P_out,HVAC_h_cabin,HVAC_AirSH,HVAC_PW,HVAC_PH,HVAC_Season,SI_HVAC_Inp):
    #HVAC_AirSH stands for the specific heat of air at constant pressure: First column: Temperature [°C]	and Second column: Air specific heat [J/kg-K]
    HVAC_T_out=HVAC_weather[HVAC_row,0]
    zone_layer=HVAC_HI_Parameter[1:5,2:8]
    zone_area=HVAC_HI_Parameter[1:5,-1]
    layer_conductivity=HVAC_HI_Parameter[5,2:8]
    layer_thickness=HVAC_HI_Parameter[6,2:8]

    Air_Density=Weather_Data_class().Air_Density_func(HVAC_P_out,HVAC_T_out)
    Mass_flow_in = HVAC_flow_air * Air_Density

    #Q[0,1,2,3,4,5,6,7]=Q[,Q_person,Q_ventilation,
    Q = np.zeros((HVAC_EV_speed.shape[0], 9))

    Temp_diff=HVAC_T_out-HVAC_T_target

    #Temperature growth rate TGR
    TGR = 0.05
    if Temp_diff>0:
        T_out_lower=HVAC_T_target
        # T_out_upper=HVAC_T_out
    else:
        T_out_lower = HVAC_T_out
        # T_out_upper = HVAC_T_target

    TGR_Array=np.array([TGR]*np.ceil(np.absolute(Temp_diff/TGR)).astype(int))
    try:
        TGR_Array[0]=TGR_Array[0]+T_out_lower
    except:
        TGR_Array = np.array(T_out_lower)

    TGR_Cumu=np.cumsum(TGR_Array).reshape(-1,1)
    if len(TGR_Cumu)>HVAC_EV_speed.shape[0]:
        TGR_Cumu=TGR_Cumu[0:HVAC_EV_speed.shape[0]].reshape(-1,1)

    if Temp_diff > 0:
        TGR_Cumu = np.vstack((np.ones((int(HVAC_EV_speed.shape[0] - len(TGR_Cumu)), 1)) * HVAC_T_target,TGR_Cumu))
    else:
        TGR_Cumu=np.vstack((TGR_Cumu,np.ones((int(HVAC_EV_speed.shape[0]-len(TGR_Cumu)),1))*HVAC_T_target))

    #Calculating the enthalpy of persons in the EV or Q_person
    if HVAC_person>1:
        Met=pow(-1,HVAC_Season+1)*(0.007184*pow(HVAC_PW,0.425)*pow(HVAC_PH,0.725)*(85+(HVAC_person-1)*55))/1000 #convert W to kW
    else:
        Met = pow(-1, HVAC_Season + 1) * (0.007184 * pow(HVAC_PW, 0.425) * pow(HVAC_PH, 0.725) * 85) #convert W to kW

    Q[:,1]=[Met]*Q.shape[0]


    #ρ_(Air,Tamb): Q[:,5] calculates Air specific heat based on input temperature (HVAC_T_out): Interpolation is done between Temperature (HVAC_AirSH[:, 0]) and Air specific heat (HVAC_AirSH[:, 1]), then for the input temperature (HVAC_T_out), the Air specific heat is interpolated.
    Q[:,5]=np.array([np.interp(HVAC_T_out, HVAC_AirSH[:, 0], HVAC_AirSH[:, 1])]*Q.shape[0])

    # ρ_(Air,Tcabin): Q[:,6] calculates Air specific heat of CABIN based on the estimated CABIN temperature (TGR_Cumu)
    Q[:,6]=(np.transpose(np.array([np.interp(TGR_Cumu[:,0], HVAC_AirSH[:, 0], HVAC_AirSH[:, 1])])))[:,0]

    #Q_inflow: converts degree of celious to kelvin, interpolate the COP value, and calculates the enthalpy of input ventilation
    Q[:,2]=(HVAC_air_density*HVAC_flow_air*Q[:,5]*(HVAC_T_out+273.15))

    #Q_outflow: calculates the enthalpy of output ventilation
    TGR_Cumu_Pressure=np.interp(TGR_Cumu,HVAC_weather[:,0].tolist(),HVAC_weather[:,1].tolist())
    TGR_air_density=Weather_Data_class().Air_Density_func(TGR_Cumu_Pressure,TGR_Cumu)

    Q[:, 3] = np.multiply(np.multiply(TGR_air_density[:,0],np.divide(np.array([Mass_flow_in]*TGR_air_density.shape[0]).reshape(-1,1)[:,0] , Q[:,6])),TGR_Cumu[:,0])

    #convert celious to kelvin
    HVAC_Temp_air_cabin_K=TGR_Cumu+273.15
    HVAC_Temp_air_out_K = HVAC_T_out + 273.15

    #calculate the wall thickness/thermal conductivity

    HVAC_Resistance=(zone_layer*layer_thickness/layer_conductivity)
    HVAC_Resistance=HVAC_Resistance.sum(axis=1)

    #Calculate the ambient convection heat transfer coefficient

    wind_speed_threshold=5
    wind_speed_coeff=6.14
    wind_speed_power=0.78

    HVAC_EV_Thresh=np.array([wind_speed_threshold]*HVAC_EV_speed.shape[0]).reshape(-1,1)
    HVAC_EV_speed_amb=np.where(HVAC_EV_speed[:,0]<=wind_speed_threshold,HVAC_EV_Thresh[:,0],HVAC_EV_speed[:,0])
    HVAC_EV_speed_amb=wind_speed_coeff*np.power(HVAC_EV_speed_amb,wind_speed_power)
    #calculates total resistance (1/R_k)
    Rk_Denominator=(1/HVAC_h_cabin+np.repeat(np.transpose(HVAC_Resistance.reshape(-1,1)), repeats=HVAC_EV_speed_amb.shape[0], axis=0))+(1/HVAC_EV_speed_amb).reshape(-1,1)
    Rk_Nominator=np.repeat(np.transpose(zone_area.reshape(-1,1)),repeats=HVAC_EV_speed_amb.shape[0],axis=0)
    R_k=np.divide(Rk_Nominator,Rk_Denominator)
    R_k=R_k.sum(axis=1)
    Q[:, 7]=R_k
    del Rk_Nominator,Rk_Denominator,R_k

    Q_wall=pow(-1,HVAC_Season)*np.multiply((HVAC_Temp_air_cabin_K - HVAC_Temp_air_out_K)[:,0],Q[:, 7])
    Q[:, 4] =Q_wall
    del Q_wall

    #Calculate the solar irradiance load
    if Q.shape[0]>0:
        Q[:, 8]=np.repeat(a=pow(-1,HVAC_Season)*SI_HVAC_Inp/Q.shape[0], repeats=Q.shape[0],axis=0)


    Q[:, 0]=(HVAC_cab_vol*np.multiply(np.multiply(TGR_air_density[:,0],Q[:,6]),(TGR_Cumu-(TGR_Cumu-TGR))[:,0]))-Q[:, 1]-Q[:, 2]+Q[:, 3]-Q[:, 4]-Q[:, 8]
    T=Q[:,5]

    return (Q, T)

def TEPCO_Charging_Plan_func(Low_SoC,Low_Duration,SoC_Data,Des_n,Des_c,VTE_Actual_speed,row,BufferHour_House,SoC,Charging_Energy,Discharging_Energy,SoC_Charging_Cycle,C_rate, VTE_Battery_Capacity,Battery_Charging_Eff,Battery_Discharging_Eff):

    SoC_c = SoC_Data[0] #Current trip SoC
    SoC_n = SoC_Data[1] #Next trip SoC
    SoC_min = SoC_Data[2] #Min SoC
    SoC_max = SoC_Data[3] #Max SoC
    SoC_threshold = SoC_Data[4] #Threshold SoC
    SoC_initial=SoC_Data[5] #Initial SoC
    SoC_Index = SoC_Data[6]  # Index SoC

    Powering_rate_row = 0  # row=0 indicates the "home"
    Duration = VTE_Actual_speed[row, VTE_AS_StayTime_col]

    ###V2G program#####
    Zone_current_V2G = VTE_Actual_speed[row, VTE_AS_EV_Work_city_col]  # Current Destination
    if VTE_Actual_speed[row, VTE_AS_To_col] == "Home":
        Charging_place_V2G = "Home"
        P_charge_V2G = Charging_Station_Data[0, 1]  # Charging power into BEV at "home"
    else:
        Charging_place_V2G = "Public"
        P_charge_V2G = Charging_Station_Data[1, 1]  # Charging power into BEV at "Public" JUST Medium

    try:
        Date_V2G = datetime.strptime(VTE_Actual_speed[row, VTE_AS_Arrdate_col],"%Y-%m-%d %H:%M:%S")  # Current Destination
        Start_Time_V2G = datetime.strptime(VTE_Actual_speed[row, VTE_AS_Arrdate_col], "%Y-%m-%d %H:%M:%S")
    except:
        Date_V2G = datetime.strptime(VTE_Actual_speed[row, VTE_AS_Depdate_col],"%Y-%m-%d %H:%M:%S")  # Current Destination
        Start_Time_V2G = datetime.strptime(VTE_Actual_speed[row, VTE_AS_Depdate_col], "%Y-%m-%d %H:%M:%S")




    if Start_Time_V2G.minute > 0:
        Start_Time_V2G = int(Start_Time_V2G.hour + 1)
    else:
        Start_Time_V2G = int(Start_Time_V2G.hour)


    Tw_V2G = Duration


    Charging_Flag=False
    if SoC_c<=SoC_min:
        Charging_Flag=True
        # column 9 indicates the trip destination, Trip_Distination_3cases = ['Home', 'Workplace', 'Others']
        if VTE_Actual_speed[row, VTE_AS_To_col] == Trip_Distination_3cases[0]:
            Duration += BufferHour_House
        else:
            if (SoC_c<=Low_SoC) and (Duration<=Low_Duration):
                Powering_rate_row = 2  # row=2 indicates the "public:Fast Speed Charging"
            else:
                Powering_rate_row = 1  # row=1 indicates the "public:Medium Speed Charging"
    elif SoC_c>=SoC_max:
        if Tw_V2G >= GV.Tw_min:
            try:
                # Potential V2G program
                Step4_Module.Vehicle2Grid_Discharging_Optimization_Model(C_rate, VTE_Battery_Capacity, Tw_V2G, P_charge_V2G, SoC_c,SoC_threshold, Zone_current_V2G, Start_Time_V2G, Date_V2G,Charging_place_V2G,Battery_Discharging_Eff,Battery_Charging_Eff)
            except:
                pass
        Charging_Flag = False
    else:

        if SoC_n>=SoC_threshold:
            if Tw_V2G >= GV.Tw_min:
                try:
                    # Potential V2G program
                    Step4_Module.Vehicle2Grid_Discharging_Optimization_Model(C_rate, VTE_Battery_Capacity, Tw_V2G, P_charge_V2G,SoC_c, SoC_threshold, Zone_current_V2G, Start_Time_V2G,Date_V2G, Charging_place_V2G,Battery_Discharging_Eff,Battery_Charging_Eff)
                except:
                    pass

            if Des_c==Trip_Distination_3cases[0]:
                Charging_Flag=True
            else:
                Charging_Flag=False
        elif SoC_n>=SoC_min:
            if Des_n==Trip_Distination_3cases[0]:
                Charging_Flag = False
            else:
                Charging_Flag = True
                if (SoC_c <= Low_SoC) and (Duration <= Low_Duration):
                    Powering_rate_row = 2  # row=2 indicates the "public:Fast Speed Charging"
                else:
                    Powering_rate_row = 1  # row=1 indicates the "public:Medium Speed Charging"

        else:
            Charging_Flag=True
            if Des_c == Trip_Distination_3cases[0]:
                Duration += BufferHour_House
                Powering_rate_row = 0  # row=0 indicates the "home"
            else:
                if (SoC_c <= Low_SoC) and (Duration <= Low_Duration):
                    Powering_rate_row = 2  # row=2 indicates the "public:Fast Speed Charging"
                else:
                    Powering_rate_row = 1  # row=1 indicates the "public:Medium Speed Charging"



    if Charging_Flag==True:
            SoC, SoC_Charging_Cycle, SoC_initial = Step4_Module.Grid2Vehicle_Charging(SoC_max, SoC, SoC_Index,SoC_c,Charging_Station_Data,SoC_Charging_Cycle,Duration,Powering_rate_row,Battery_Charging_Eff)
    else:
        SoC[SoC_Index, 1] = SoC_initial + np.sum(Charging_Energy) - np.sum(Discharging_Energy)

    return (SoC, SoC_Charging_Cycle, SoC_initial, Charging_Flag, Powering_rate_row, Duration)

def Next_Trip_Data(VTE_ID,VTE_Actual_speed, row_del,Current_SoC,SoC_Distance):
    timestamp_format = "%Y-%m-%d %H:%M:%S"
    Des_c = VTE_Actual_speed[row_del, VTE_AS_To_col]  # Current Destination

    VTE_Actual_speed_slice = VTE_Actual_speed[row_del + 1:, :]
    VTE_Actual_speed_Cur_BEVID = VTE_Actual_speed_slice[np.where(VTE_Actual_speed_slice[:, 4] == np.array(VTE_ID))[0],:]
    if len(VTE_Actual_speed_Cur_BEVID)>0:
        Date_n=VTE_Actual_speed_Cur_BEVID[0,6] #next date and time

        del VTE_Actual_speed_slice

        finish = datetime.strptime(VTE_Actual_speed_Cur_BEVID[0, VTE_AS_Depdate_col], timestamp_format)
        start = datetime.strptime(VTE_Actual_speed[row_del, VTE_AS_Arrdate_col], timestamp_format)


        if (finish-start).total_seconds() / 3600<0:
            PCT_Departure_Time=VTE_Actual_speed[row_del, VTE_AS_DepTime2_col]
        else:
            PCT_Departure_Time=max(0,int(math.floor((finish-start).total_seconds() / 3600)))   # PCT stands for Potential_Charging_Time
            if PCT_Departure_Time==0:
                PCT_Departure_Time=VTE_Actual_speed[row_del, VTE_AS_DepTime2_col]

        BufferHour_House=max(0,int(math.floor((finish-datetime(finish.year,finish.month,finish.day,0,0,0)).total_seconds()/3600)))
        if BufferHour_House>PCT_Departure_Time:
            BufferHour_House=0

        try:
            Des_n = VTE_Actual_speed_Cur_BEVID[0, VTE_AS_To_col]  # Next Destination
            if SoC_Distance==0:
                SoC_n = Current_SoC
            else:
                SoC_n = Current_SoC - (SoC_Distance * VTE_Actual_speed_Cur_BEVID[0, VTE_AS_TraDis_col] / VTE_Actual_speed[row_del, VTE_AS_TraDis_col])
        except:
            Des_n = GV.Trip_Distination_3cases[0]
            SoC_n = Current_SoC

        del VTE_Actual_speed_Cur_BEVID
    else:
        Des_n=Des_c
        SoC_n=Current_SoC
        Date_n=VTE_Actual_speed[row_del,6]
        PCT_Departure_Time=VTE_Actual_speed[row_del,14]
        BufferHour_House=5 #5 hours after midnight for next travel

    return (Des_c, Des_n, SoC_n,Date_n,PCT_Departure_Time,BufferHour_House)


def Generate_hourly_timestamps(month, year,Weather_data):
    # Create a datetime index for a non-leap year (8760 hours)
    dates = pd.date_range(start='2023-01-01', periods=8760, freq='H')  # Non-leap year
    Total_dates_weather=pd.DataFrame(Weather_data)
    Total_dates_weather['dates']=pd.DataFrame(dates)

    # df = pd.DataFrame(index=dates)
    Total_dates_weather = Total_dates_weather.set_index(Total_dates_weather['dates'])

    # Specify the month you want (e.g., March = 3)
    Total_dates_weather = Total_dates_weather[Total_dates_weather.index.month == month]

    Total_dates_weather=Total_dates_weather.to_numpy()
    Weather_data=Total_dates_weather[:,:-1].astype(float)
    Annual_hourly_timestamp = Total_dates_weather[:,-1]
    return (Weather_data,Annual_hourly_timestamp)


def Vehicle_Tractive_Effort_func(CT_Dic,GP_Dic,VTE_DC_Speed,VTE_Actual_speed,VTE_weather_data,Step1_Mat_column,VTE_motor_efficiency_data,VTE_GP_parameters_data,VTE_AirSH_data,VTE_Num_EV,CHI_parameters,Main_Zone_name,VTE_SI_data,VTE_Mean_Speed_col):

    #CT and GT stand for Car Types, and General Parameters which are in dictionary format
    #This function calculates 4 types of forces including 1)Rolling resistance: F(rr), 2) Aerodynamic drag: F(ad), 3) Climbing/descending/gravity: F(g), and 4) Acceleration/Rotational inertia:F(acc)
    timestamp_format = "%Y-%m-%d %H:%M:%S"


    CT_key=list(CT_Dic.keys())
    GP_key=list(GP_Dic.keys())

    EV_Num_Passanger=GP_Dic[GP_key[6]]
    EV_Passanger_mass=CT_Dic[CT_key[2]]+GP_Dic[GP_key[4]]*EV_Num_Passanger

    Inertial_mass=CT_Dic[CT_key[2]]*(0.04+0.0025*CT_Dic[CT_key[6]]**2)
    Drag_Coefficient=CT_Dic[CT_key[3]]
    Frontal_Area=CT_Dic[CT_key[4]]*CT_Dic[CT_key[5]]
    Cabin_volume=GP_Dic[GP_key[10]]
    Qsensible_heat=GP_Dic[GP_key[5]]
    Air_flow = GP_Dic[GP_key[11]]
    Convective_ht_coef_cabin= GP_Dic[GP_key[3]] #Cabin air  convective  heat  transfer  coefficient (Watts-per- meter-square-kelvin)
    Ave_Press_sea=GP_Dic[GP_key[16]]  #average pressure at sea level

    Battery_Charging_Eff=GP_Dic[GP_key[1]]/100
    Battery_Discharging_Eff = GP_Dic[GP_key[1]]/100
    Battery_Inverter_Eff = GP_Dic[GP_key[2]] / 100
    C_rate = GP_Dic[GP_key[20]]

    VTE_wind_speed=0
    VTE_transmission_eff=GP_Dic[GP_key[0]]/100
    VTE_Nominal_Motor_Power=CT_Dic[CT_key[0]]*1000 # kW to W

    VTE_load_frcation=VTE_motor_efficiency_data[:,0] #x data for interpolation
    VTE_motor_load_function=VTE_motor_efficiency_data[:,1] #motor data is considered as y data which is a function of load fraction data
    VTE_generator_load_function = VTE_motor_efficiency_data[:, 2] #generator data is considered as y data which is a function of load fraction data

    VTE_Battery_Capacity=GP_Dic[GP_key[17]]
    VTE_PW = GP_Dic[GP_key[18]]
    VTE_PH = GP_Dic[GP_key[19]]


    #Defining low capacity and duration time either to choose fast or medium battery charging
    Low_SoC = 0.5 *VTE_Battery_Capacity
    Low_Duration=1 #hour



    #determine the state of charge (SoC) of battery: all BEV's batteries are full in the begining of the simulation model
    SoC_percentage=1 #1 corresponds to 100%
    DoD_percentage=0.80
    if GV.SoC_Flag==True:
        SoC=np.hstack((np.arange(VTE_Num_EV).reshape(-1,1),np.ones((VTE_Num_EV,1))*VTE_Battery_Capacity*SoC_percentage)) #first column refers to the EV car ID
        SoC=np.hstack((SoC,np.zeros((SoC.shape[0],2)))) #Third and fourth, and fifth columns indicate number of battery charging time, the amount of charging based on DoD value, and storing all charging amount into a string, respectively.
    else:
        GVSoC_col=list(GV.SoC)
        SoC = np.hstack((np.arange(VTE_Num_EV).reshape(-1, 1),np.array(GV.SoC[GVSoC_col[1]]).reshape(-1,1) ))  # first column refers to the EV car ID
        SoC = np.hstack((SoC, np.zeros((SoC.shape[0], 2))))
        SoC=SoC.astype(float)


    VTE_ID_col=4
    SoC_max=VTE_Battery_Capacity*DoD_percentage #[kWh]
    SoC_min=VTE_Battery_Capacity*(1-DoD_percentage) #[kWh]
    SoC_threshold=20 #[kWh]

    # PCT stands for Potential_Charging_Time
    PCT_Trip_Duration_col=12
    PCT_Duration_col=14
    PCT_Arrival_col=13
    PCT_Departure_col=15
    PCT_Chargingplace_col=17
    PCT_TEPCO_chargeplan=18


    BufferHour_House_Initial = 5  # after 24:00 till 5:00 AM is considered as buffer hours which can be used for charging
    BufferHour_House=BufferHour_House_Initial
    #Ch_Cycle_col stands for Charging cycle column
    Ch_Cycle_col=['Index','Frequency of charging','SoC at charging time','Charging place','EV ID', 'SoC [kWh]','Charging amount per each time [kWh]']

    SoC_Charging_Cycle=pd.DataFrame(np.hstack((np.arange(1, VTE_Num_EV + 1).reshape(-1, 1), np.zeros((VTE_Num_EV, 1)))),columns=[Ch_Cycle_col[0],Ch_Cycle_col[1]])
    SoC_Charging_Cycle[Ch_Cycle_col[1]] = SoC_Charging_Cycle[Ch_Cycle_col[1]].astype(str)
    SoC_Charging_Cycle[Ch_Cycle_col[2]] = ""
    SoC_Charging_Cycle[Ch_Cycle_col[3]] = ""


    VTE_auxiliary_power=GP_Dic[GP_key[12]] #Watt


    VTE_Dis_col=Step1_Mat_column.index(difflib.get_close_matches('Travel Distance [km]', Step1_Mat_column)[0])
    VTE_Dur_col=Step1_Mat_column.index(difflib.get_close_matches('Travel Time[h]', Step1_Mat_column)[0])

    VTE_Departuretime_col = Step1_Mat_column.index('Departure_Time')
    #New columns
    VTE_Repeat_col=len(Step1_Mat_column)+1
    VTE_Tail_col=len(Step1_Mat_column)+2


    VTE_airdensity_col=4
    VTE_temperature_col = 0


    VTE_cooling_target=VTE_GP_parameters_data[9]
    VTE_heating_target=VTE_GP_parameters_data[8]
    VTE_cooling_COP = VTE_GP_parameters_data[15]
    VTE_heating_COP = VTE_GP_parameters_data[14]



    #This part creates target values for heating and cooling as well as their heat pump's COP
    #Three columns correspond to Target temperature, COP of heat pump, and Flag

    df_VTE_weather_data = pd.DataFrame(VTE_weather_data)
    df_col = list(df_VTE_weather_data.columns)
    df_VTE_Actual_speed = pd.DataFrame(VTE_Actual_speed[:, VTE_AS_Depdate_col], columns=[df_col[-1]])
    df_VTE_Actual_speed = pd.to_datetime(df_VTE_Actual_speed[df_col[-1]].astype(str), format=timestamp_format)
    # Round to nearest hour
    VTE_Actual_speed_rounded = df_VTE_Actual_speed.dt.round('H')

    Left_join = pd.merge(VTE_Actual_speed_rounded, df_VTE_weather_data, on=df_col[-1], how='left')
    if Left_join.isnull().values.any() == True:
        df_VTE_weather_data[df_col[-1]] = df_VTE_weather_data[df_col[-1]].apply(pd.to_datetime, errors='coerce',infer_datetime_format=True)
        VTE_Actual_speed_rounded = VTE_Actual_speed_rounded.apply(pd.to_datetime, errors='coerce',infer_datetime_format=True)
        Left_join = pd.merge(VTE_Actual_speed_rounded, df_VTE_weather_data, on=df_col[-1], how='left')

    # VTE_Aspeed_Weather merges two arrays in order to adjust time in both VTE_weather_data and VTE_Actual_speed
    VTE_Aspeed_Weather = Left_join.to_numpy()
    del df_VTE_Actual_speed, VTE_Actual_speed_rounded, df_VTE_weather_data, Left_join


    VTE_Aspeed_Weather=VTE_Aspeed_Weather[:,1:]
    VTE_air_density=VTE_Aspeed_Weather[:,VTE_airdensity_col]
    VTE_temperature=VTE_Aspeed_Weather[:,VTE_temperature_col]

    zeros = np.zeros((VTE_Aspeed_Weather.shape[0], 1))
    ones = np.ones((VTE_Aspeed_Weather.shape[0], 1))
    HVAC_COP_Target_Temperature=np.zeros((VTE_Aspeed_Weather.shape[0], 3))
    HVAC_COP_Target_Temperature[:,0]=np.nan


    HVAC_Target_HTemp = np.where(VTE_Aspeed_Weather[:, 0] <= VTE_heating_target,VTE_heating_target*ones[:,0],zeros[:,0])
    HVAC_Target_CTemp = np.where(VTE_Aspeed_Weather[:, 0] > VTE_cooling_target,VTE_cooling_target*ones[:,0],zeros[:,0])
    HVAC_Target_CHTemp=(HVAC_Target_HTemp+HVAC_Target_CTemp).reshape(-1,1)

    HVAC_COP_Target_Temperature[:,0]=np.where(HVAC_Target_CHTemp[:,0]!=0,HVAC_Target_CHTemp[:,0],HVAC_COP_Target_Temperature[:,0])
    HVAC_COP_Target_Temperature[np.isnan(HVAC_COP_Target_Temperature)] = 0

    del HVAC_Target_HTemp,HVAC_Target_CTemp,HVAC_Target_CHTemp


    HVAC_Target_HCOP = np.where(VTE_Aspeed_Weather[:, 0] < VTE_heating_target, VTE_heating_COP*ones[:, 0],zeros[:, 0])
    HVAC_Target_CCOP = np.where(VTE_Aspeed_Weather[:, 0] > VTE_cooling_target, VTE_cooling_COP*ones[:, 0],zeros[:, 0])
    HVAC_COP_Target_Temperature[:, 1] = (HVAC_Target_HCOP + HVAC_Target_CCOP).reshape(-1, 1)[:,0]
    del HVAC_Target_HCOP , HVAC_Target_CCOP

    HVAC_Target_HFlag = np.where(VTE_Aspeed_Weather[:, 0] < VTE_heating_target, ones[:, 0], zeros[:, 0])
    HVAC_Target_CFlag = np.where(VTE_Aspeed_Weather[:, 0] > VTE_cooling_target, -1 * ones[:, 0], zeros[:, 0])
    HVAC_COP_Target_Temperature[:, 2] = (HVAC_Target_HFlag + HVAC_Target_CFlag).reshape(-1, 1)[:,0]
    del HVAC_Target_HFlag, HVAC_Target_CFlag

    Timestamp_Flag = False
    First_Time_Timestamp_Flag=True
    Charged_Flag=False
    Final_Timestamp_counter=0

    date_format_1 = '%Y-%m-%d %H:%M:%S'
    date_format_2 = '%m/%d/%Y %H:%M:%S'

    Repeat_row = VTE_Actual_speed.shape[0]

    Final_Timestamp = np.zeros((48, 3))
    Final_Timestamp_NumEVs = np.zeros((48, 3))

    Final_Timestamp_Zone = np.zeros((48, 42))
    Final_Timestamp_ZoneNumEVs = np.zeros((48, 42))

    BEV_Power_Consumption = []  # Record amount of BEV power usage to run the BEV based on its corresponding distance
    timestamp_format = "%Y-%m-%d %H:%M:%S"

    #For each trip (or row), we will generate speed and acceleration data based on driving cycle data. Then, we have to calculate 1) Wheels power, 2) HVAC power, and 3) Accessories power for each trip
    row_del = 0
    for row in range(Repeat_row):
        print("row=",row)

        if row>0:
            #everytime the VTE_Actual_speed matrix is shrinked to speed up the processing time
            VTE_Actual_speed=VTE_Actual_speed[1:,:]

        # base total simulation day calculation
        byear = VTE_Actual_speed[0, VTE_AS_year_col]
        bmonth = VTE_Actual_speed[0, VTE_AS_month_col]
        bday = VTE_Actual_speed[0, VTE_AS_day_col]
        GV.BEV_ID = VTE_Actual_speed[0, VTE_AS_EVID_col]

        # print("GV.BEV_ID=",GV.BEV_ID)

        Date_c = datetime.strptime(VTE_Actual_speed[0, 7], timestamp_format)  # Date and time for the current record


        try:
            Date_Infomration = datetime.strptime(VTE_Actual_speed[row_del, VTE_AS_Depdate_col], date_format_1)
            Year = Date_Infomration.year
            BaseTime = datetime.strptime('{}-01-01 00:00:00'.format(Year), date_format_1)
        except:
            Date_Infomration = datetime.strptime(VTE_Actual_speed[row_del, VTE_AS_Depdate_col], date_format_2)
            Year = Date_Infomration.year
            BaseTime = datetime.strptime('01/01/{} 00:00:00'.format(Year), date_format_2)


        # Day=Date_Infomration.day
        Trip_Duration= VTE_Actual_speed[row_del,PCT_Trip_Duration_col]


        #12,1,2,9,10,11 indicate Dec., Janu, Feb,Sep. Oct, and Nov.
        if VTE_Actual_speed[row_del,VTE_AS_month_col] in [12,1,2,9,10,11]:
            #cold season
            VTE_Season =0
        else:
            #hot season
            VTE_Season = 1

        Timestamp = np.zeros((48 * 2,3))  # 3charging strategies (Home, Workplace, and Public) times two days or 48*2 (30-minute settlement period)

        Charging_Timestamp_Flag = True


        if abs(byear - GV.base_year) + abs(bmonth - GV.base_month) + abs(bday - GV.base_day) > 0:
            GV.ts_day = GV.ts_day + 1
            GV.base_year = byear
            GV.base_month = bmonth
            GV.base_day = bday
            Timestamp_Flag = False


        if Timestamp_Flag==False:
            Final_Timestamp_counter+=1
            Timestamp_Flag = True
            First_Time_Timestamp_Flag=True
            # Timestamp=np.zeros((48*2,3)) #3charging strategies (Home, Workplace, and Public) times two days or 48*2 (30-minute settlement period)


        #PCT stands for Potential_Charging_Time
        PCT_Arrival_Time = VTE_Actual_speed[row_del, PCT_Arrival_col]


        VTE_ID=VTE_Actual_speed[row_del,VTE_ID_col]
        SoC_Index=int((SoC[:,0]==VTE_ID).argmax())
        SoC_initial=SoC[SoC_Index,1]
        SoC_initial_Timestamp=SoC[SoC_Index,1]



        if VTE_Actual_speed[row_del,VTE_Mean_Speed_col]>0:

            VTE_trip_DC=np.array(VTE_DC_Speed.tolist()*VTE_Actual_speed[row_del,VTE_Repeat_col]+VTE_DC_Speed[:VTE_Actual_speed[row_del,VTE_Tail_col]].tolist())
            VTE_Average_EV_Speed=(VTE_Actual_speed[row_del,VTE_Dis_col]/VTE_Actual_speed[row_del,VTE_Dur_col])/3.6 #km/h to m/s


            #generate the trip speed data [m/s]
            VTE_Speed = VTE_trip_DC * VTE_Average_EV_Speed

            #Generate trip acceleration data [m/s^2]
            VTE_ACC=Acceleration_Array_func(VTE_Speed)
            VTE_ACC = np.concatenate(VTE_ACC, axis=0).reshape(-1,1)
            #Adding zero to the beginning and end of VTE_ACC array
            VTE_ACC=np.insert(VTE_ACC,0,values=0)
            VTE_ACC = np.insert(VTE_ACC, -1, values=0).reshape(-1,1)

            #Calculate Wheels power including I) rolling resistance power, II) aerodynamic drag power,III) gravity power, and IV) rotational inertia power.
            Gravity_Force=Gravity_Force_func(EV_Passanger_mass,ROAD_SLOPE)
            Rotational_inertia_Force=Rotational_Inertia_Force_func(EV_Passanger_mass, Inertial_mass, VTE_ACC)
            Aerodynamic_drag_Force=Aerodynamic_Drag_Force_func(VTE_air_density[row],Frontal_Area,Drag_Coefficient,VTE_Speed,VTE_wind_speed)

            # Rolling resistance coefficient should be calculated at first
            RRP_RR_Coeff = Rolling_Resistance_Coeff(VTE_temperature[row], VTE_Speed)
            Rolling_resistance_Force=Rolling_Resistance_Force_func(RRP_RR_Coeff, EV_Passanger_mass, slop_angle=0)

            Total_Tractive_Force=Gravity_Force+Rotational_inertia_Force+Aerodynamic_drag_Force+Rolling_resistance_Force

            zero_mat=np.zeros((Total_Tractive_Force.shape[0],1))
            Regenerative_Braking_Force=np.where(Total_Tractive_Force<0,np.absolute(Total_Tractive_Force),zero_mat)

            #Calculating Power_Wheel or dropping down the negative values
            Power_Wheel=np.where(Total_Tractive_Force>=0, Total_Tractive_Force,zero_mat)*VTE_Speed

            #calculating Motor output and Generator power input via efficiency of transmission (Motor power flow: Battery->Inverter->Motor->Transmission->Wheels;   Generator flow: Wheels->Transmission->Motor->Inverter->Battery)
            Power_Motor_Out = Power_Wheel / VTE_transmission_eff
            VTE_zeros=np.zeros((VTE_ACC.shape[0],1))
            Deceleration =np.where(VTE_ACC==0,VTE_zeros,(np.exp(0.0411 / np.abs(VTE_ACC))) ** (-1)) #neg_acceleration or regenerative braking energy efficiency (grb) in http://dx.doi.org/10.1016/j.apenergy.2016.01.097
            Power_Generator_In=np.where(VTE_ACC<0,Power_Wheel*Deceleration*VTE_transmission_eff,zero_mat)

            # calculating Motor input and Generator power output via efficiency of motor/generator
            Load_Motor=Power_Motor_Out/VTE_Nominal_Motor_Power
            Load_Generator=Power_Generator_In/VTE_Nominal_Motor_Power

            Efficiency_Motor=np.interp(Load_Motor,VTE_load_frcation,VTE_motor_load_function)
            Efficiency_Generator = np.interp(Load_Generator, VTE_load_frcation, VTE_generator_load_function)
            Eff_zeros=np.zeros((Efficiency_Motor.shape[0],1))
            Power_Motor_In=np.where(Efficiency_Motor==0,Eff_zeros,np.nan_to_num(Power_Motor_Out / (Efficiency_Motor*Battery_Inverter_Eff) , copy=False)) #This power is discharged from battery to run the vehicle (wheels' power)

            ## Power_Generator_Out represents total regenerative braking power via the negative values of the EV force
            Power_Generator_Out = Power_Generator_In * Efficiency_Generator*Battery_Inverter_Eff #This power is charged into battery because of regenerative braking: Power_Reg_Braking

            #calculating the auxiliary power
            Power_auxiliary=np.array([VTE_auxiliary_power]*int(len(VTE_Speed))).reshape(-1,1)

            #calculating energy required for the HVAC of the EV, T_Cabin and Q_Device represent the EV cabin temperature and heat provided by device


            #SI stands for Solar Irradiance
            SI_row= int((Date_Infomration - BaseTime).total_seconds() / 3600)
            SI_column = Main_Zone_name.tolist().index(VTE_Actual_speed[row_del, PCT_Chargingplace_col])+4

            #SI_HVAC_Inp includes the hourly solar irradiance for trip duration plus the non irradiance part obtained from multiplication of the trip duration, area(A_windshield+A_sides+A_(rear window)) and the surface transmissivity
            SI_HVAC_Inp=np.array([VTE_SI_data[sirow,SI_column] for sirow in range(SI_row,SI_row+math.ceil(Trip_Duration))])
            if math.ceil(Trip_Duration)>1:
                SI_HVAC_Inp[-1]=SI_HVAC_Inp[-1]*(1-(math.ceil(Trip_Duration)-Trip_Duration))

            SI_HVAC_Inp=Trip_Duration*Surface_transmissivity*np.sum(SI_HVAC_Inp) #Wh/m2 to kWh/m2


            Q_Device,T_Cabin=EV_HVAC_func(VTE_air_density[row],row,VTE_Aspeed_Weather, HVAC_COP_Target_Temperature[row,0], Cabin_volume, Air_flow, CHI_parameters, VTE_Speed, Qsensible_heat, EV_Num_Passanger,Ave_Press_sea,Convective_ht_coef_cabin,VTE_AirSH_data,VTE_PW,VTE_PH,VTE_Season,SI_HVAC_Inp)

            #P_device indicates amount of power required to run the HVAC system in BEVs
            if HVAC_COP_Target_Temperature[row,1]==0:
                P_device = (np.absolute(Q_Device[:, 0])).reshape(-1, 1)
            else:
                P_device=(np.absolute(Q_Device[:,0])/HVAC_COP_Target_Temperature[row,1]).reshape(-1,1)

            #Battery charging and discharging from BEV side
            P_Bat_charging = Power_Generator_Out * Battery_Charging_Eff

            P_Bat_discharging = (Power_Motor_In+P_device+Power_auxiliary) /Battery_Discharging_Eff

            # Calculating of energy consumption to charge battery (from either charging station or EV charging unit) or discharge its power to V2G program side
            Total_Battery_Power=np.add(P_Bat_charging,-1*P_Bat_discharging)
            zeros=np.zeros((len(Total_Battery_Power),1))
            Charging_Energy=np.where(Total_Battery_Power>=0,np.absolute(Total_Battery_Power),zeros)/ 1000 / 3600  # W to kWh
            Discharging_Energy=-(np.where(Total_Battery_Power<0,Total_Battery_Power,zeros)/ 1000 / 3600)  # W to kWh

            BEV_Power_Consumption.append(Discharging_Energy.sum() - Charging_Energy.sum())

            Current_SoC=SoC_initial+np.sum(Charging_Energy)-np.sum(Discharging_Energy)

            SoC_Distance=SoC_initial-Current_SoC

            #########New SoC to estimate SoC for the next trip#########################################
            Des_c, Des_n, SoC_n, Date_n, PCT_Departure_Time, BufferHour_House = Next_Trip_Data(VTE_ID, VTE_Actual_speed,row_del, Current_SoC,SoC_Distance)
            date_format = "%Y-%m-%d %H:%M:%S"
            Home_Duration = math.floor((datetime.strptime(Date_n, date_format) - Date_c).total_seconds() / 3600)


            SoC_Data=[]
            SoC_Data.append(Current_SoC)
            SoC_Data.append(SoC_n)
            SoC_Data.append(SoC_min)
            SoC_Data.append(SoC_max)
            SoC_Data.append(SoC_threshold)
            SoC_Data.append(SoC_initial)
            SoC_Data.append(SoC_Index)


            SoC, SoC_Charging_Cycle, SoC_initial, Charged_Flag, Powering_rate_row, Duration = TEPCO_Charging_Plan_func(Low_SoC,Low_Duration,SoC_Data,Des_n,Des_c,VTE_Actual_speed,row_del,BufferHour_House,SoC,Charging_Energy,Discharging_Energy,SoC_Charging_Cycle,C_rate, VTE_Battery_Capacity,Battery_Charging_Eff,Battery_Discharging_Eff)


            if (Charging_Timestamp_Flag==True) and (Charged_Flag==True):
                Timestamp=Step4_Module.Charging_Timestamp(SoC_initial,Current_SoC,Powering_rate_row,Charging_Station_Data,PCT_Arrival_Time,PCT_Departure_Time,Timestamp,Battery_Charging_Eff)


        else:
            Total_Energy_Charging = np.zeros((1, 1))
            Total_Energy_Discharging = np.zeros((1, 1))
            Current_SoC = SoC_initial + np.sum(Total_Energy_Charging) - np.sum(Total_Energy_Discharging)
            SoC_Distance = SoC_initial - Current_SoC

            Des_c, Des_n, SoC_n, Date_n, PCT_Departure_Time, BufferHour_House = Next_Trip_Data(VTE_ID, VTE_Actual_speed,row_del, Current_SoC,SoC_Distance)
            date_format = "%Y-%m-%d %H:%M:%S"
            Home_Duration = math.floor((datetime.strptime(Date_n, date_format) - Date_c).total_seconds() / 3600)

            SoC_Data = []
            SoC_Data.append(Current_SoC)
            SoC_Data.append(SoC_n)
            SoC_Data.append(SoC_min)
            SoC_Data.append(SoC_max)
            SoC_Data.append(SoC_threshold)
            SoC_Data.append(SoC_initial)
            SoC_Data.append(SoC_Index)


            BEV_Power_Consumption.append(0)

            Duration = VTE_Actual_speed[
                           row_del, VTE_AS_StayTime_col] + BufferHour_House  # this part represents that the BEV remains at home for 24 hours plus BufferHour which occurs in early hours of the next day
            if GV.BEV_Housetype == 1:
                P_charge_V2G = Charging_Station_Data[0, 1]  # Charging power into BEV at "home"
            else:
                P_charge_V2G = Charging_Station_Data[1, 1]  # Charging power into BEV at "home"

            ###V2G program#####
            Zone_current_V2G = VTE_Actual_speed[row_del, VTE_AS_EV_Work_city_col]  # Current Destination
            if (VTE_Actual_speed[row_del, VTE_AS_To_col] == "Home") and (GV.BEV_Housetype == 1):
                Charging_place_V2G = "Home"
            else:
                Charging_place_V2G = "Public"


            Date_V2G = VTE_Actual_speed[row_del, VTE_AS_Arrdate_col]  # Current Destination



            Start_Time_V2G = datetime.strptime(VTE_Actual_speed[row_del, VTE_AS_Arrdate_col], "%Y-%m-%d %H:%M:%S")
            if Start_Time_V2G.minute > 0:
                Start_Time_V2G = int(Start_Time_V2G.hour + 1)
            else:
                Start_Time_V2G = int(Start_Time_V2G.hour)

            Tw_V2G = PCT_Departure_Time

            # Start_Time_V2G=int(Date_V2G[-5:-3])
            # Tw_V2G = 24+Duration

            if Tw_V2G >= GV.Tw_min:

                try:
                    #Potential V2G program
                    Step4_Module.Vehicle2Grid_Discharging_Optimization_Model(C_rate, VTE_Battery_Capacity, Tw_V2G, P_charge_V2G,SoC_initial, SoC_threshold,Zone_current_V2G,Start_Time_V2G,Date_V2G,Charging_place_V2G,Battery_Discharging_Eff,Battery_Charging_Eff)

                except:
                    pass

            max_battery_capacity=VTE_GP_parameters_data[17,0]
            if SoC_initial<max_battery_capacity:
                Total_Energy_Charging = np.zeros((1, 1))
                Total_Energy_Discharging = np.zeros((1, 1))
                Current_SoC = SoC_initial + np.sum(Total_Energy_Charging) - np.sum(Total_Energy_Discharging)

                Powering_rate_row = 0  # row=1 indicates the "home"
                if Current_SoC < SoC_max:
                    Charged_Flag = True
                    SoC, SoC_Charging_Cycle, SoC_initial = Step4_Module.Grid2Vehicle_Charging(SoC_max, SoC, SoC_Index,Current_SoC,Charging_Station_Data,SoC_Charging_Cycle,Duration,Powering_rate_row,Battery_Charging_Eff)
                else:
                    Charged_Flag = False

                if (Charging_Timestamp_Flag == True) and (Charged_Flag == True):
                    try:
                        Timestamp = Step4_Module.Charging_Timestamp(SoC_initial, Current_SoC, Powering_rate_row,Charging_Station_Data, PCT_Arrival_Time,PCT_Departure_Time, Timestamp,Battery_Charging_Eff)
                    except:
                        PCT_Departure_Time = 0
                        Timestamp = Step4_Module.Charging_Timestamp(SoC_initial, Current_SoC, Powering_rate_row,Charging_Station_Data, PCT_Arrival_Time,PCT_Departure_Time, Timestamp,Battery_Charging_Eff)


        Timestamp_NumEVs=np.where(Timestamp>0,np.zeros((48 * 2, 3))+1,np.zeros((48 * 2, 3))) # this variable measures the number of EVs in the charging station's queue

        #three types of charging methods (slow, medium, and fast)
        charging_methods=3
        Zone_np=np.zeros((len(Timestamp), len(Main_Zone_name.tolist())*charging_methods))
        Zone_NumberEVs_np = np.zeros((len(Timestamp), len(Main_Zone_name.tolist()) * charging_methods))
        zone_col = Main_Zone_name.tolist().index(VTE_Actual_speed[row_del, PCT_Chargingplace_col])
        zone_col_start=zone_col*charging_methods
        zone_col_finish=zone_col_start+charging_methods
        # zone_power_data=Timestamp.sum(axis=1)


        if Final_Timestamp_counter == 1:
            # if Charged_Flag == True:
            if First_Time_Timestamp_Flag == True:
                Final_Timestamp = Timestamp
                Final_Timestamp_NumEVs = Timestamp_NumEVs
                #creation of main_zone EV power consumption
                Final_Timestamp_Zone=Zone_np.copy()
                Final_Timestamp_Zone[:,zone_col_start:zone_col_finish]=Timestamp.copy()

                # creation of main_zone EV numbers
                Final_Timestamp_ZoneNumEVs = Zone_NumberEVs_np.copy()
                Final_Timestamp_ZoneNumEVs[:, zone_col_start:zone_col_finish] = Timestamp_NumEVs.copy()

                First_Time_Timestamp_Flag = False
            else:
                Final_Timestamp = np.add(Final_Timestamp, Timestamp)
                Final_Timestamp_Zone[:, zone_col_start:zone_col_finish] = Final_Timestamp_Zone[:,zone_col_start:zone_col_finish] + Timestamp.copy()

                Final_Timestamp_NumEVs = np.add(Final_Timestamp_NumEVs, Timestamp_NumEVs)
                Final_Timestamp_ZoneNumEVs[:, zone_col_start:zone_col_finish] = Final_Timestamp_ZoneNumEVs[:,zone_col_start:zone_col_finish] + Timestamp_NumEVs.copy()


        else:

            if Charged_Flag == True:
                #srow represents the selected row
                if First_Time_Timestamp_Flag == True:
                    Final_Timestamp_Zone[-48:, zone_col_start:zone_col_finish] = Final_Timestamp_Zone[-48:, zone_col_start:zone_col_finish] + Timestamp[:48,:]
                    Final_Timestamp_Zone = np.vstack((Final_Timestamp_Zone, Zone_np[-48:, :]))
                    Final_Timestamp_Zone[-48:, zone_col_start:zone_col_finish] = Final_Timestamp_Zone[-48:, zone_col_start:zone_col_finish] + Timestamp[:48,:]

                    #EV numbers
                    Final_Timestamp_ZoneNumEVs[-48:, zone_col_start:zone_col_finish] = Final_Timestamp_ZoneNumEVs[-48:,zone_col_start:zone_col_finish] + Timestamp_NumEVs[:48,:]
                    Final_Timestamp_ZoneNumEVs = np.vstack((Final_Timestamp_ZoneNumEVs, Zone_np[-48:, :]))
                    Final_Timestamp_ZoneNumEVs[-48:, zone_col_start:zone_col_finish] = Final_Timestamp_ZoneNumEVs[-48:,zone_col_start:zone_col_finish] + Timestamp_NumEVs[:48,:]


                    Final_Timestamp[-48:, :] = Final_Timestamp[-48:, :] + Timestamp[:48, :]
                    Final_Timestamp = np.vstack((Final_Timestamp, Timestamp[-48:, :]))
                    First_Time_Timestamp_Flag = False

                    #EV numbers
                    Final_Timestamp_NumEVs[-48:, :] = Final_Timestamp_NumEVs[-48:, :] + Timestamp_NumEVs[:48, :]
                    Final_Timestamp_NumEVs = np.vstack((Final_Timestamp_NumEVs, Timestamp_NumEVs[-48:, :]))

                else:
                    Final_Timestamp[-96:,:] = np.add(Final_Timestamp[-96:,:], Timestamp)
                    Final_Timestamp_Zone[-96:, zone_col_start:zone_col_finish] = Final_Timestamp_Zone[-96:,zone_col_start:zone_col_finish] + Timestamp

                    #EV numbers
                    Final_Timestamp_NumEVs[-96:, :] = np.add(Final_Timestamp_NumEVs[-96:, :], Timestamp_NumEVs)
                    Final_Timestamp_ZoneNumEVs[-96:, zone_col_start:zone_col_finish] = Final_Timestamp_ZoneNumEVs[-96:,zone_col_start:zone_col_finish] + Timestamp_NumEVs
                    # print("Day={}......Size={}".format(Final_Timestamp_counter,Final_Timestamp.shape[0]))


    SoC=SoC[:,0:3]
    Ch_Cycle_col = ['Index', 'Frequency of charging', 'SoC at charging time', 'Charging place', 'EV ID', 'SoC [kWh]','Charging amount per each time [kWh]']

    SoC_column = [Ch_Cycle_col[4], Ch_Cycle_col[5], Ch_Cycle_col[1],Ch_Cycle_col[2], Ch_Cycle_col[6],Ch_Cycle_col[3]]
    SoC=pd.DataFrame(np.hstack((SoC,SoC_Charging_Cycle[[Ch_Cycle_col[2],Ch_Cycle_col[1],Ch_Cycle_col[3]]])),columns=SoC_column)
    Final_Timestamp=pd.DataFrame(Final_Timestamp,columns=Charging_Strategy)
    Final_Timestamp_NumEVs = pd.DataFrame(Final_Timestamp_NumEVs, columns=Charging_Strategy)

    zone_name_plus_charge=[]
    for i in range(len(Main_Zone_name)):
        zone_name_plus_charge.append('{}_{}'.format(Main_Zone_name[i],Charging_Strategy[0]))
        zone_name_plus_charge.append('{}_{}'.format(Main_Zone_name[i],Charging_Strategy[1]))
        zone_name_plus_charge.append('{}_{}'.format(Main_Zone_name[i],Charging_Strategy[2]))

    Final_Timestamp_Zone=pd.DataFrame(Final_Timestamp_Zone,columns=zone_name_plus_charge)
    Final_Timestamp_ZoneNumEVs = pd.DataFrame(Final_Timestamp_ZoneNumEVs, columns=zone_name_plus_charge)
    if GV.SoC_Flag==True:
        GV.SoC=SoC
        GV.SoC_Flag = False
    else:
        GV.SoC[Ch_Cycle_col[1]] = GV.SoC[Ch_Cycle_col[1]] + SoC[Ch_Cycle_col[1]]
        GV.SoC[Ch_Cycle_col[2]] = GV.SoC[Ch_Cycle_col[2]] + SoC[Ch_Cycle_col[2]]
        GV.SoC[Ch_Cycle_col[3]] = GV.SoC[Ch_Cycle_col[3]] + SoC[Ch_Cycle_col[3]]
        GV.SoC[Ch_Cycle_col[6]] = GV.SoC[Ch_Cycle_col[6]] + SoC[Ch_Cycle_col[6]]


    return(Final_Timestamp,Final_Timestamp_Zone,Final_Timestamp_NumEVs,Final_Timestamp_ZoneNumEVs,BEV_Power_Consumption)



def Main_Function_Step3(Num_EV, Simu_year,DPD,Step1_Mat_column,Main_Zone_name,Simulation_Month):

    #Reading EV model's parameters including cabin heat insulation, model's parameters, and general parameters

    #CHI stands for Cabin Heat Insulation

    CHI_Layers=["Laminated glass","Tempered glass","Metal","polyurethane (PU) foam","Polyester","Fiberglass"]
    CHI_Zones=["Windshield","Side windows","Rear window","Rest"]
    CHI_Zones_Layers=list(itertools.product(CHI_Zones,CHI_Layers))

    CHI_parameters=pd.read_excel(Input_list[Inp_cabin_heat]).fillna(0).to_numpy()

    CHI_Zone_Flag=CHI_parameters[1:5,2:-1]  # It indicates whether the zone layers (Windshield,Side windows,Rear window,Rest) are applicable or not.
    CHI_Zone_Flag_Flatten=CHI_parameters[1:5,2:-1].flatten()
    CHI_Zone_Flag_Dic={CHI_Zones_Layers[i]: CHI_Zone_Flag_Flatten[i] for i in range(len(CHI_Zones_Layers))}


    CHI_Zone_Area=CHI_parameters[1:5,-1].reshape(-1,1) # It indicates the area of each layer (Windshield,Side windows,Rear window,Rest)
    CHI_Zone_Area_Dic={CHI_Zones[i]: CHI_Zone_Area[i,0] for i in range(len(CHI_Zone_Area))}


    CHI_Zone_Thermal_conductivity=CHI_parameters[5:6,2:-1].reshape(-1,1)  #Thermal conductivity (W/mK)[λj]
    CHI_Zone_Thermal_conductivity_Dic={CHI_Layers[i]: CHI_Zone_Thermal_conductivity[i,0] for i in range(len(CHI_Zone_Thermal_conductivity))}

    CHI_Zone_Layer_thickness=CHI_parameters[-1,2:-1].reshape(-1,1)  #Layer thickness (mm) [xj]
    CHI_Zone_Layer_thickness_Dic={CHI_Layers[i]: CHI_Zone_Layer_thickness[i,0] for i in range(len(CHI_Zone_Layer_thickness))}


    #CT stands for Car Type
    CT_parameters=['Nominal motor power', 'Nominal battery capacity', 'Curb weight', 'Drag coefficient','Height','Width','Gear ratio','Power to mass ratio']
    CT_Model=['Model 3 (Tesla)',	'ID.3 (vW)', 'Nissan Leaf e+',	'Kona (Hyundai)',	'Zeo (Renault)'] # It specifies BEV types in the research society


    CT_parameters_data=pd.read_excel(Input_list[Inp_car_type]).fillna(0).to_numpy()
    CT_parameters_data=CT_parameters_data[1:,2:2+len(CT_Model)]
    #Nissan_col represents the Nissan Leaf e+ EV column among CT_parameters_data matrix
    Nissan_col=2  #Nissan Leaf e+
    CT_parameters_Nissan_Dic={CT_parameters[i]: CT_parameters_data[i,Nissan_col] for i in range(len(CT_parameters))}

    #BEV_GP stands for Battery Electric vehicle General Parameters
    BEV_GP_parameters=["Transmission efficiency",
    "Battery charging/discharging efficiency",
    "Battery inverter efficiency",
    "heat cabin coefficient",
    "Person mass",
    "Person sensible heat",
    "Passengers number",
    "Hourly Temperature Year",
    "Target cabin temperature for heating",
    "Target cabin temperature for cooling",
    "EV cabin air volume",
    "Ventilation rate",
    "Auxiliary power",
    "Driving cycle",
    "HVAC heating COP",
    "HVAC cooling COP","Ave_Press_out","Battery capacity","Average weight","Average height","C-rate"]

    BEV_GP_parameters_data=pd.read_excel(Input_list[Inp_general_parameters]).fillna(0).to_numpy()
    BEV_GP_parameters_data=BEV_GP_parameters_data[:,2].reshape(-1,1)
    BEV_GP_parameters_Dic={BEV_GP_parameters[i]: BEV_GP_parameters_data[i,0] for i in range(len(BEV_GP_parameters))}



    #DC_JC08_Japan stands for Driving Japanese JC08 Cycle
    DC_JC08_Japan=pd.read_excel(Input_list[Inp_driving_cycle],sheet_name='Interpolated_Data').fillna(0).to_numpy()
    DC_JC08_Japan=DC_JC08_Japan[:,0:3].astype(float)
    DC_JC08_Japan=DC_JC08_Japan[:,[0,2]]

    # DC_JC08_Japan[:,1] = DC_JC08_Japan[:,1]/3.6 #Convert [km/h] to [m/s] OR 1000/3600


    #Normalized EV speed data
    Normalized_DC_Speed=DC_JC08_Japan[:,1]/np.mean(DC_JC08_Japan[:,1])
    Normalized_DC_Speed=Normalized_DC_Speed.reshape(-1,1)


    DPD_Actual_speed=DPD.to_numpy()


    DPD_Dis_col = Step1_Mat_column.index(difflib.get_close_matches('Travel Distance [km]', Step1_Mat_column)[0])
    DPD_Dur_col=Step1_Mat_column.index(difflib.get_close_matches('Travel Time[h]', Step1_Mat_column)[0])


    #Calculation of mean speed data
    Mean_Speed_col = DPD.shape[1]
    DPD=np.hstack((DPD,np.zeros((DPD.shape[0],1))))
    #If travel time is positive
    mask=np.where(DPD[:, DPD_Dur_col]>0)
    Positive_speed=DPD[mask]
    Positive_speed=Positive_speed[:,DPD_Dis_col]/Positive_speed[:,DPD_Dur_col]
    DPD[mask,Mean_Speed_col]=np.ceil(Positive_speed/3.6) #km/hr to m/s

    del Positive_speed,mask

    #Calculation of repeating of driving cycle array (DC_Repeat) and its tail (DC_Tail)
    DC_Repeat_col=DPD.shape[1]
    DPD_Actual_speed = np.hstack((DPD, np.zeros((DPD.shape[0], 1))))
    DC_Tail_col = DPD_Actual_speed.shape[1]
    DPD_Actual_speed = np.hstack((DPD_Actual_speed, np.zeros((DPD_Actual_speed.shape[0], 1))))

    DPD_Actual_speed[:,DC_Repeat_col]=np.floor(DPD_Actual_speed[:,DPD_Dur_col]*3600/Normalized_DC_Speed.shape[0]) #hour to second
    DPD_Actual_speed[:, DC_Tail_col] = (DPD_Actual_speed[:,DPD_Dur_col]*3600%Normalized_DC_Speed.shape[0]).astype(int)


    ##################
    # This section read weather data
    Weather_data = pd.read_excel(Input_list[Inp_weather_data]).fillna(0).to_numpy()
    Weather_data = Weather_data.astype(float)

    ############################
    Weather_data, Annual_hourly_timestamp = Generate_hourly_timestamps(Simulation_Month, Simu_year, Weather_data)

    ############################

    Weather_data = Weather_data[:, 2:]

    #####################


    # To calculate the aerodynamic drag force (and power) latter, weather data is required.
    WD_cls=Weather_Data_class()
    WD_Dewpoint_data=WD_cls.Dew_Point_func(Weather_data[:,2],Weather_data[:,0])
    WD_Airdensity_data=WD_cls.Air_Density_func(Weather_data[:,1],Weather_data[:,0])

    Weather_data=np.hstack((Weather_data,WD_Dewpoint_data.reshape(-1,1)))
    Weather_data=np.hstack((Weather_data,WD_Airdensity_data.reshape(-1,1)))

    # Annual_hourly_timestamp=pd.Series(pd.date_range(start=f'01/01/{Simu_year}', end=f'12/31/{Simu_year} 23:00', freq='H')).dt.strftime('%m/%d/%Y %H:%M').to_numpy()
    Weather_data = np.hstack((Weather_data, Annual_hourly_timestamp.reshape(-1, 1)))
    del WD_Airdensity_data, WD_Dewpoint_data


    #This section read motor efficiency data
    Motor_efficiency_data=pd.read_excel(Input_list[Inp_motor_efficiency]).fillna(0).to_numpy()
    Motor_efficiency_data=Motor_efficiency_data.astype(float)

    #This section read Air specific heat data: First column: Temperature [°C]	and Second column: Air specific heat [J/kg-K]
    Air_specific_heat_data=pd.read_excel(Input_list[Inp_air_specific_heat]).fillna(0).to_numpy()
    Air_specific_heat_data=Air_specific_heat_data.astype(float)

    #This section read solar irradiance data
    Solar_irradiance_data = pd.read_excel(Input_list[Inp_solar_irradiance]).fillna(0).to_numpy()
    Solar_irradiance_data = Solar_irradiance_data.astype(float)


    #This section calculates vehicle tractive effort forces
    Final_Timestamp,Final_Timestamp_Zone,Final_Timestamp_NumEVs,Final_Timestamp_ZoneNumEVs,BEV_Power_Consumption=Vehicle_Tractive_Effort_func(CT_parameters_Nissan_Dic,BEV_GP_parameters_Dic,Normalized_DC_Speed,DPD_Actual_speed,Weather_data,Step1_Mat_column,Motor_efficiency_data,BEV_GP_parameters_data,Air_specific_heat_data,Num_EV,CHI_parameters.copy(),Main_Zone_name,Solar_irradiance_data,Mean_Speed_col)
    BEV_Power_Consumption = np.array(BEV_Power_Consumption).reshape(-1, 1)
    return(Final_Timestamp,Final_Timestamp_Zone,Final_Timestamp_NumEVs,Final_Timestamp_ZoneNumEVs,BEV_Power_Consumption)
