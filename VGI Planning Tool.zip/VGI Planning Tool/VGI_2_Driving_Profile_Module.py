import math

import numpy as np
import pandas as pd
import os,sys
import datetime
import random
import openpyxl as xl
import sqlite3
import shutil
from pathlib import Path
from scipy.stats import multivariate_normal

import Global_Var as GV


Input_list=GV.Step_2_Input_list


EV_decimal=2

#Trip destination codes
Trip_Destination={'Home':1,'Workplace':2,'Shopping':3,'Personal':4}

#Driver_type_ID represents the code of driver types
Driver_type_ID={'Non-commuter':0,'Full-time-commuter':1}

#Leaving home and office follow the Triangular distribution
Leaving_Home_Hour=[6,8,9]#hour
Leaving_Work_Hour=[17,18,19]#hour

#Leaving_Home_Hour modifies the first departure time for a trip with more than or equal to 3 times of travel
Leaving_Home_Hour=[8,9,10]
#LWH stands for Leaving_Work_Hour
LWH_Randomness=[8,10,12]#minute

#Personal and shopping duration
Personal_Dur=[30,60] #minute
Shopping_Dur=[60,90,120] #minute


hour_conversion=60


#OD represents the OneDay_Commuting_EV_mat matrix
OD_EV_ID_col = 0
OD_EV_type_col = 1
OD_EV_origin_col = 2
OD_EV_destination_col = 3
OD_EV_distance_col = 4
OD_EV_duration_col = 5
OD_EV_departure1_col = 6
OD_EV_arrival_col = 7
OD_EV_departure2_col = 8
OD_EV_stayingtime_col = 9

# #Driver_type_ID represents the code of driver types
# Driver_type_ID={'Non-commuter':0,'Full-time-commuter':1}


#P_w_shopping and P_w_personal indicate the probability of going for shopping or running personal task for an EV driver who goes to office (working is the primary task of the EV driver)
P_w_shopping=np.array(0.03)
P_w_personal=np.array(0.05)

#P_bw_personal indicates the probability of doing personal task before going to to work (office)
P_bw_personal=np.array(0.48)


#According to the survey data, probability of going for shopping, or running personal task from home and vice versa are as follows:
P_home_shop=np.array(0.48)
P_home_personal=np.array(1-P_home_shop)

P_shop_home=np.array(0.38)
P_personal_home=np.array(1-P_shop_home)


Del_Rows=[0,1,2,10,18]
Div_list=[7,4,6,6,6,5,14]

#n_Com_row (n_Com_col) indicates the number of rows (columns) in the commuter matrix which is read from the "Departure_Destination_Trip.xlsx" file
n_Com_row=7
n_Com_col=6

#Com_col and Ncom_col represent the index columns of the commuter and Non-commuter matrixes
Com_col=[1,2,4,6,8,10]
Ncom_col = [x+1 for x in Com_col[1:]]


#default definition of distance and duration boundaries
min_distance = 2  # km
max_distance = 160

min_time = 5  # minutes
max_time = 165

distance_length = 5  # 5 [km]
time_length = 5  # 5 [minute]
distance_boundary = np.arange(start=5, stop=max_distance + 1, step=distance_length)
time_boundary = np.arange(start=min_time, stop=max_time + 1, step=time_length)

distance_boundary = np.append(min_distance, distance_boundary)

#Trip_Dis_data represents the trip distance data in km. These data are extracted from the "Distance_Duration_Trip.xlsx" file
Trip_Dis_data=np.zeros((len(distance_boundary)-1,2))
Trip_Dis_data[:,0]=distance_boundary[:-1]
Trip_Dis_data[:,1]=distance_boundary[1:]


#Trip_Dur_data represents the trip duration data in minute. These data are extracted from the "Distance_Duration_Trip.xlsx" file
Trip_Dur_data=np.zeros((len(time_boundary)-1,2))
Trip_Dur_data[:,0]=time_boundary[:-1]
Trip_Dur_data[:,1]=time_boundary[1:]


#Step specifies the time step (here 30 minutes)
Step=0.5


#Rules to select consistent daily trip

#Wp_wd_c_FT indicates the workplace at weekday for commuters which are working as full-time with uniform distribution [min hour, max hour]

Wp_wd_c_FT=np.array([7,8])
Wp_we_c_FT=np.array([3,4])

Wp_wd_c_PT=np.array([3.5,4])
Wp_we_c_PT=np.array([3,4])

Wp_wd_nc=Wp_wd_c_FT
Wp_we_nc=Wp_we_c_FT

#Other_destination determines triangular distribution for duration time of other destination
Other_Destination_Duration=np.array([0.5,1,2])


def Distance_Time_Rnd_func(Inp_prob,Num_Rnd,row_edges,column_edges):
    total_sum = math.ceil(np.sum(Inp_prob))
    Inp_prob = Inp_prob / total_sum
    Inp_prob = Inp_prob.astype(float)
    #######
    P_flat = Inp_prob.flatten()
    P_flat /= P_flat.sum()  # Normalize if not already

    # Sample from the matrix according to the joint probability
    indices = np.random.choice(len(P_flat), size=Num_Rnd, p=P_flat)

    # Convert flat indices back to (i, j) positions
    rows = indices // Inp_prob.shape[1]
    cols = indices % Inp_prob.shape[1]

    # Sample uniformly within the bin ranges
    distance_samples = np.random.uniform(row_edges[rows], row_edges[rows + 1])
    time_samples = np.random.uniform(column_edges[cols], column_edges[cols + 1])

    distance_time = np.hstack((distance_samples.reshape(-1, 1), time_samples.reshape(-1, 1)))
    return(distance_time)


def Rand_Sample_Generation_Weighted_func(Inp_prob,Num_Rnd):
    #################
    try:
        n_row, n_col = Inp_prob.shape
        Data = np.arange(1, n_row * n_col + 1).tolist()
        weight = tuple(Inp_prob.flatten().tolist())
    except:
        n_row=len(Inp_prob)
        Data= np.arange(1, n_row+ 1).tolist()
        weight = tuple(Inp_prob.flatten().tolist())
    return (np.array(random.choices(Data, weights=weight, k=Num_Rnd)))

def Rand_Sample_Generation_func(Inp_prob,Num_Rnd):
    #This function generates random sample from Input_data based on an explicit Inp_probability as well as the random numbers' position in the cummulative "Inp_prob" matrix
    rnd_data=np.random.rand(Num_Rnd)
    rnd_pos=np.searchsorted(np.cumsum(Inp_prob), rnd_data, side="right")
    return rnd_pos,rnd_data


def Random_Choice_func(Lower,Upper,Step):
    Rand_list=np.arange(Lower,Upper+Step,Step)
    return (np.random.choice(Rand_list))


def Random_Sample_Departure_Houre_func(RSDH_Inp,RSDH_DH,Step):
    RSDH_Inp=RSDH_Inp.reshape(-1,1)
    RSDH_DH_3D=RSDH_DH[RSDH_Inp]
    RSDH_DH_2D=RSDH_DH_3D.reshape(list(RSDH_DH_3D.shape)[0],list(RSDH_DH_3D.shape)[2])
    Vfunc=np.vectorize(Random_Choice_func)
    return(Vfunc(RSDH_DH_2D[:,0],RSDH_DH_2D[:,1],Step))


def Daily_trip_per_week_NC_func(Input_data,Num_EV,EV_Commuter_data):
    Num_weekdays=5

    workd_ind= Rand_Sample_Generation_Weighted_func(Input_data[:, 0], Num_weekdays * Num_EV)-1
    workd_ind = workd_ind.reshape(Num_EV, Num_weekdays)

    # Assinging at least one trip for workplace if the Driver_type_weekdays is either full-time or part-time commuter
    for i in range(Num_weekdays):
        mask=np.where(EV_Commuter_data[:,i]==1)
        mask_lst=mask[0].tolist()
        if len(mask)!=0:
            selected_col=workd_ind[mask][:,i]
            workd_ind[mask_lst,i]=np.max(np.vstack((selected_col,np.array([2]*selected_col.shape[0]))),axis=0)


    # Generate 2 random numbers corresponding to 2 weekend days
    weekend_ind = Rand_Sample_Generation_Weighted_func(Input_data[:, 1], 2*Num_EV)-1
    weekend_ind = weekend_ind.reshape(Num_EV, 2)

    EV_Day=np.hstack((workd_ind,weekend_ind))

    return(EV_Day)


def Daily_distance_duration_data_func(Trip_Dis_data,Trip_Dur_data,EV_Inp_Mat,coeff_data,Row_pos,Col_pos):
    EV_zone_col=3
    Dis_col=5
    Dur_col=6
    EV_Dis_col=2
    EV_Dur_col=3
    EV_Inp_Mat = np.hstack((EV_Inp_Mat, coeff_data.reshape(-1, 1), Row_pos.reshape(-1, 1), Col_pos.reshape(-1, 1)))

    EV_Inp_Mat=EV_Inp_Mat[EV_Inp_Mat[:, 0].argsort()] #sorting array based on its first colum

    unique, counts = np.unique(EV_Inp_Mat[:,1], return_counts=True)

    for i in range(len(unique)):
        if counts[i]>=1:
            mask=np.where(EV_Inp_Mat[:,1]==unique[i])
            EV_Inp_Filter = EV_Inp_Mat[mask]

            Distance = (EV_Inp_Filter[:, Dis_col].astype(int)).tolist()
            Duration = (EV_Inp_Filter[:, Dur_col].astype(int)).tolist()

            Selected_Distance=Trip_Dis_data[Distance]
            LB = Selected_Distance[:, 1] - Selected_Distance[:, 0]
            Selected_Distance=Selected_Distance[:, 0]+np.multiply(LB,EV_Inp_Filter[:,EV_zone_col+1])
            Selected_Distance =Selected_Distance

            Selected_Duration = Trip_Dur_data[Duration]
            LB = Selected_Duration[:, 1] - Selected_Duration[:, 0]
            Selected_Duration = Selected_Duration[:, 0]+np.multiply(LB, EV_Inp_Filter[:, EV_zone_col+1])
            Selected_Duration = Selected_Duration

            EV_Inp_Mat[mask, EV_Dis_col] = Selected_Distance
            EV_Inp_Mat[mask, EV_Dur_col] = Selected_Duration

    return (EV_Inp_Mat[:,0:EV_zone_col+1])


def Personal_Shopping_Modification_Commuter_EVs_func(Inp_Data,OneDay_Commuting_EV_mat, day, str_Before_After, str_Personal_Shopping):
    Trip_Destination_value=list(Trip_Destination.values())
    BW_Number = int(np.sum(Inp_Data[:, day]))
    if BW_Number > 0:
        Rnd_BW = np.random.uniform(low=0.1,high=0.9,size=BW_Number)
        mask_BW = np.where(Inp_Data[:, day] > 0)
        OneDay_C_PS = OneDay_Commuting_EV_mat[mask_BW]
        OneDay_C_PS[:, OD_EV_distance_col] = np.round(OneDay_C_PS[:, OD_EV_distance_col] * Rnd_BW, decimals=EV_decimal)
        OneDay_C_PS[:, OD_EV_duration_col] = np.round(OneDay_C_PS[:, OD_EV_duration_col] * Rnd_BW, decimals=EV_decimal)
        if str_Before_After == 'after':
            OneDay_C_PS[:, OD_EV_departure1_col] = OneDay_C_PS[:, OD_EV_departure2_col]

        OneDay_C_PS[:, OD_EV_arrival_col] = np.round(OneDay_C_PS[:, OD_EV_departure1_col] + OneDay_C_PS[:, OD_EV_duration_col] / hour_conversion,decimals=EV_decimal)
        # Generating random number for staying hours in personal/shopping tasks
        if str_Personal_Shopping == 'personal':
            OneDay_C_PS[:, OD_EV_stayingtime_col] = np.round(np.random.uniform(low=Personal_Dur[0], high=Personal_Dur[1], size=BW_Number) / hour_conversion, decimals=EV_decimal)
        else:
            OneDay_C_PS[:, OD_EV_stayingtime_col] = np.round(np.random.triangular(Shopping_Dur[0], Shopping_Dur[1], Shopping_Dur[2], size=BW_Number) / hour_conversion,decimals=EV_decimal)

        OneDay_C_PS[:, OD_EV_departure2_col] = OneDay_C_PS[:, OD_EV_arrival_col] + OneDay_C_PS[:, OD_EV_stayingtime_col]


        if str_Personal_Shopping=='shopping':
            OneDay_C_PS[:, OD_EV_origin_col] = Trip_Destination_value[1]
            OneDay_C_PS[:, OD_EV_destination_col] = Trip_Destination_value[2]
            # Trip_Destination = {'Home': 1, 'Workplace': 2, 'Shopping': 3, 'Personal': 4}
        else:
            if str_Before_After == 'after':
                OneDay_C_PS[:, OD_EV_origin_col] = Trip_Destination_value[1]
                OneDay_C_PS[:, OD_EV_destination_col] = Trip_Destination_value[3]
            else:
                OneDay_C_PS[:, OD_EV_destination_col] = Trip_Destination_value[3]

    return (OneDay_C_PS)

def work_2_home_func(Inp_data):
    OR=Inp_data[:,OD_EV_origin_col].copy()
    Inp_data[:,OD_EV_origin_col]=Inp_data[:,OD_EV_destination_col]
    Inp_data[:, OD_EV_destination_col]=OR
    Inp_data[:, OD_EV_departure1_col]=Inp_data[:,OD_EV_departure2_col]
    Inp_data[:, OD_EV_arrival_col]= Inp_data[:, OD_EV_departure1_col]+Inp_data[:, OD_EV_duration_col]/hour_conversion
    Inp_data[:, OD_EV_departure2_col]=24 #last moment of day
    Inp_data[:, OD_EV_stayingtime_col]=Inp_data[:, OD_EV_departure2_col]-Inp_data[:, OD_EV_arrival_col]
    Inp_data=np.round(Inp_data,EV_decimal)

    return(Inp_data)

def Numday_to_Month_Day_func(numday):
  d0 = datetime.date(2023,1,1)
  deltaT = datetime.timedelta(numday-1)
  d  = d0 + deltaT
  return d.month, d.day


def Commuter_Distance_Larger_than_40min_func(data):
    # Step 1: Mask and separate valid (≤40 minutes) and excluded (>40 minutes)
    time_col=2
    distance_col=1
    BEV_ID_col=0
    mask_excluded = data[:, time_col] > GV.Commuter_Minuter_oneway
    valid_data = data[~mask_excluded]
    excluded_ids = data[mask_excluded][:, 0]  # Save EV IDs only

    # Step 2: Extract distance and time from valid data
    valid_dist_time = valid_data[:, 1:3]

    # Step 3: Calculate mean vector and covariance matrix
    mean_vector = np.mean(valid_dist_time, axis=0)  # [mean_distance, mean_time]
    if np.isnan(mean_vector).any():
        col_3 = data[:, time_col]
        closest_row_index = np.argmin(np.abs(col_3 - GV.Commuter_Minuter_oneway))
        valid_dist_time = data[closest_row_index, 1:3]
        mean_vector = np.mean(valid_dist_time, axis=0)  # [mean_distance, mean_time]


    if valid_dist_time.shape[0] < 2:
        cov_matrix = np.eye(valid_dist_time.shape[1]) * 1e-6  # Small variance
    else:
        cov_matrix = np.cov(valid_dist_time.T)

    # Step 4: Generate synthetic [distance, time] from multivariate normal
    n_generate = len(excluded_ids)
    try:
        synthetic_values = np.random.multivariate_normal(mean_vector, cov_matrix, size=n_generate)
    except:
        synthetic_values = multivariate_normal.rvs(mean=mean_vector, cov=cov_matrix, size=n_generate)

    # Optional: Clip values to positive range
    synthetic_values = np.clip(synthetic_values, a_min=0, a_max=None)

    # Step 5: Combine EV IDs with generated values
    generated_data = np.column_stack((excluded_ids, synthetic_values))

    # Step 6: Combine with valid data
    final_data = np.vstack((valid_data, generated_data))

    # Step 7: (Optional) sort by EV ID
    final_data = final_data[np.argsort(final_data[:, 0])]

    return(final_data)

def EV_Commuting_Data_func(Driver_type_weekdays,EV_zone,EV_working_zone,Input_dd_data,Inp_dd_b2cities_data,n_row_dd,distance_bins,time_bins):
    # Generating random numbers for distance&trip duration for Commuter EVs
    EV_mask = np.where(Driver_type_weekdays == np.array(1))
    Commuter_EV_zones = np.hstack((EV_zone[EV_mask[0]], EV_working_zone[EV_mask[0]]))
    OD_mask = np.where(Commuter_EV_zones[:, 0] != Commuter_EV_zones[:, 1])

    # Main_Commuter_EV_mat represents the main EV commuting matrix including each EV ID, EV zone, its daily distance and duration per trip
    Main_Commuter_EV_mat = np.zeros((len(EV_mask[0]), 4)).astype('object')
    Main_Commuter_EV_mat[:, 0] = EV_mask[0]
    Main_Commuter_EV_mat[:, 1] = Commuter_EV_zones[:, 0]


    unique, counts = np.unique(Commuter_EV_zones[:, 0], return_counts=True)

    for i in range(len(unique)):
        mask = np.where(Main_Commuter_EV_mat[:, 1] == np.array(unique[i]))[0]
        if len(mask)>0:
            Rnd_Input = Input_dd_data[unique[i]]
            Main_Commuter_EV_mat[mask,2:4]=Distance_Time_Rnd_func(Rnd_Input, len(mask),distance_bins,time_bins)

    # replacing between two cities data
    Two_cities = Commuter_EV_zones[OD_mask]


    for l in range(len(Two_cities)):
        selected_Origin = np.array(Two_cities[l, 0])
        selected_Destination = np.array(Two_cities[l, 1])
        OD2cities = np.intersect1d(np.where(Inp_dd_b2cities_data[:, 0] == selected_Origin), np.where(Inp_dd_b2cities_data[:, 1] == selected_Destination))
        if np.size(OD2cities) == 0:
            OD2cities = np.intersect1d(np.where(Inp_dd_b2cities_data[:, 0] == selected_Destination), np.where(Inp_dd_b2cities_data[:, 1] == selected_Origin))

        Main_Commuter_EV_mat[OD_mask[0][l], 2] = Inp_dd_b2cities_data[OD2cities[0], 2]
        Main_Commuter_EV_mat[OD_mask[0][l], 3] = Inp_dd_b2cities_data[OD2cities[0], 3] * hour_conversion  # conversion hour to minute


    Main_Commuter_EV_mat = np.delete(Main_Commuter_EV_mat, 1, axis=1).astype(float)  # delete the second column
    # Main_Commuter_EV_mat[:, 0] = Main_Commuter_EV_mat[:, 0] + 1

    mask_excluded = Main_Commuter_EV_mat[:,1] > GV.Commuter_Minuter_oneway  # 40 minutes above are replaced in the commuter data
    if np.any(mask_excluded):
        Main_Commuter_EV_mat = Commuter_Distance_Larger_than_40min_func(Main_Commuter_EV_mat)  # because every commuter trip is set to 40 minute each way, then commuter trip bigger than 40 minutes are replaced.

    return(Main_Commuter_EV_mat)


def Two_Trip_NonCommuter_func(Main_NC_EV_mat):
    Path_Num=2
    # Generating distance and time for two-path trip
    Twopath_mask = np.where(Main_NC_EV_mat[:, -1] == Path_Num)

    if len(Twopath_mask[0]) > 0:
        Origin = np.array([Trip_Destination['Home']] * int(len(Twopath_mask[0]) / Path_Num)).reshape(-1, 1)
        Destination = np.array([Trip_Destination['Shopping']] * int(len(Twopath_mask[0]) / Path_Num))
        Personal_Destination = np.ones((int(len(Twopath_mask[0]) / Path_Num), 1)) * Trip_Destination['Personal']
        shop_personal_Destination = np.random.rand(int(len(Twopath_mask[0]) / Path_Num))
        Destination = np.where(shop_personal_Destination >= P_home_shop, Personal_Destination.reshape(-1, ),Destination).reshape(-1, 1)

        Even_index = np.arange(start=1, stop=int(len(Origin) * Path_Num), step=Path_Num).reshape(-1, 1)
        Odd_index = Even_index - 1
        Origin_Destination = np.vstack((Origin, Destination))
        Origin_Destination = np.hstack((Origin_Destination, np.vstack((Odd_index, Even_index))))

        Origin_Destination = Origin_Destination[Origin_Destination[:, 1].argsort()]
        Origin_Destination[:, 1] = np.roll(Origin_Destination[:, 0], shift=-1)

        Main_NC_EV_mat[Twopath_mask, 2:4] = Origin_Destination

    return(Main_NC_EV_mat)

def Three_Trip_NonCommuter_func(Main_NC_EV_mat):
    Path_Num=3
    Threepath_mask = np.where(Main_NC_EV_mat[:, -1] == Path_Num)
    if len(Threepath_mask[0]) > 0:
        shop_personal_Destination = np.random.rand(int(len(Threepath_mask[0]) / Path_Num))

        Shopping_Destination = np.array([Trip_Destination['Shopping']] * int(len(Threepath_mask[0]) / Path_Num)).reshape(-1, 1)
        Personal_Destination = np.ones((int(len(Threepath_mask[0]) / Path_Num), 1)) * Trip_Destination['Personal']

        Destination_1 = np.where(shop_personal_Destination >= P_home_shop, Personal_Destination.reshape(-1, ),Shopping_Destination.reshape(-1, )).reshape(-1, 1)

        shop_personal_Destination = np.random.rand(int(len(Threepath_mask[0]) / Path_Num))

        Destination_2 = np.where(shop_personal_Destination >= 0.5, Personal_Destination.reshape(-1),Shopping_Destination.reshape(-1, )).reshape(-1, 1)

        Destination_3 = np.ones((len(Destination_2), 1))


        Ranking_Vec_1 = np.arange(start=1, stop=len(Destination_1)*Path_Num, step=Path_Num).reshape(-1,1)
        Ranking_Vec_2 = np.arange(start=2, stop=len(Destination_2)*Path_Num+1, step=Path_Num).reshape(-1,1)
        Ranking_Vec_3 = np.arange(start=3, stop=len(Destination_3)*Path_Num+2, step=Path_Num).reshape(-1,1)


        Destination_1 = np.hstack((Ranking_Vec_1, Destination_1))
        Destination_2 = np.hstack((Ranking_Vec_2, Destination_2))
        Destination_3 = np.hstack((Ranking_Vec_3, Destination_3))

        Total_three_path=np.vstack((Destination_1,Destination_2,Destination_3))

        Total_three_path = Total_three_path[Total_three_path[:, 0].argsort()]
        Total_three_path = Total_three_path[:,1].reshape(-1,1)

        Total_three_path = np.hstack((np.ones((len(Total_three_path), 1)), Total_three_path))
        Total_three_path[1:, 0] = Total_three_path[:-1, 1]
        Main_NC_EV_mat[Threepath_mask, 2:4] = Total_three_path

    return(Main_NC_EV_mat)

def Four_Trip_nonCommuter_func(Main_NC_EV_mat):
    Path_Num=4
    Fourpath_mask = np.where(Main_NC_EV_mat[:, -1] == Path_Num)

    if len(Fourpath_mask[0]) > 0:
        shop_personal_Destination = np.random.rand(int(len(Fourpath_mask[0]) / Path_Num))

        Shopping_Destination = np.array([Trip_Destination['Shopping']] * int(len(Fourpath_mask[0]) / Path_Num)).reshape(-1, 1)
        Personal_Destination = np.ones((int(len(Fourpath_mask[0]) / Path_Num), 1)) * Trip_Destination['Personal']


        Destination_1 = np.where(shop_personal_Destination >= P_home_shop, Personal_Destination.reshape(-1, ), Shopping_Destination.reshape(-1, )).reshape(-1, 1).astype(int)

        Destination_2 = np.ones((len(Destination_1), 1))


        # Getting back home if EV driver has been in shopping
        sh2ho_mask = np.where(Destination_1[:, 0] == Trip_Destination['Shopping'])
        if len(sh2ho_mask[0]) > 0:
            sh2ho_Rnd = np.random.rand(int(len(sh2ho_mask[0])))

            Personal_Destination_2 = np.ones((len(sh2ho_Rnd), 1)) * Trip_Destination['Personal']
            Shopping_Destination_2 = np.ones((len(sh2ho_Rnd), 1)) * Trip_Destination['Shopping']
            Home_Destination_2 = np.ones((len(sh2ho_Rnd), 1)) * Trip_Destination['Home']

            shop_personal_2 = np.where(sh2ho_Rnd >= 0.5, Personal_Destination_2.reshape(-1),Shopping_Destination_2.reshape(-1, )).reshape(-1, 1)
            Destination_2[sh2ho_mask, 0] = np.where(sh2ho_Rnd >= P_shop_home, shop_personal_2.reshape(-1, ),Home_Destination_2.reshape(-1, ))

        # Getting back home if EV driver has been running its personal task
        per2ho_mask = np.where(Destination_1[:, 0] == Trip_Destination['Personal'])
        if len(per2ho_mask[0]) > 0:
            per2ho_Rnd = np.random.rand(int(len(per2ho_mask[0])))
            Personal_Destination_2 = np.ones((len(per2ho_Rnd), 1)) * Trip_Destination['Personal']
            Shopping_Destination_2 = np.ones((len(per2ho_Rnd), 1)) * Trip_Destination['Shopping']
            Home_Destination_2 = np.ones((len(per2ho_Rnd), 1)) * Trip_Destination['Home']

            shop_personal_2 = np.where(per2ho_Rnd >= 0.5, Personal_Destination_2.reshape(-1),Shopping_Destination_2.reshape(-1, )).reshape(-1, 1)
            Destination_2[per2ho_mask, 0] = np.where(per2ho_Rnd >= P_personal_home, shop_personal_2.reshape(-1, ),Home_Destination_2.reshape(-1, ))

        Rnd_Des3 = np.random.rand(len(Destination_1))
        Personal_Destination_3 = np.ones((len(Destination_1), 1)) * Trip_Destination['Personal']
        Shopping_Destination_3 = np.ones((len(Destination_1), 1)) * Trip_Destination['Shopping']

        Destination_3 = np.where(Rnd_Des3 >= 0.5, Personal_Destination_3.reshape(-1),Shopping_Destination_3.reshape(-1)).reshape(-1, 1)

        ho2shper_mask = np.where(Destination_2[:, 0] == Trip_Destination['Home'])
        if len(ho2shper_mask[0]) > 0:
            ho2shper_Rnd = np.random.rand(int(len(ho2shper_mask[0])))
            Personal_Destination_3 = np.ones((len(ho2shper_Rnd), 1)) * Trip_Destination['Personal']
            Shopping_Destination_3 = np.ones((len(ho2shper_Rnd), 1)) * Trip_Destination['Shopping']

            Home_Destination_3 = np.where(ho2shper_Rnd >= P_home_shop, Personal_Destination_3.reshape(-1, ),Shopping_Destination_3.reshape(-1, ))

            Destination_3[ho2shper_mask, 0] = Home_Destination_3

        Destination_4 = np.ones((len(Destination_3), 1))

        Ranking_Vec_1 = np.arange(start=1, stop=len(Destination_1) * Path_Num, step=Path_Num).reshape(-1, 1)
        Ranking_Vec_2 = np.arange(start=2, stop=len(Destination_2) * Path_Num + 1, step=Path_Num).reshape(-1, 1)
        Ranking_Vec_3 = np.arange(start=3, stop=len(Destination_3) * Path_Num + 2, step=Path_Num).reshape(-1, 1)
        Ranking_Vec_4 = np.arange(start=4, stop=len(Destination_4) * Path_Num + 3, step=Path_Num).reshape(-1, 1)

        Destination_1 = np.hstack((Ranking_Vec_1, Destination_1))
        Destination_2 = np.hstack((Ranking_Vec_2, Destination_2))
        Destination_3 = np.hstack((Ranking_Vec_3, Destination_3))
        Destination_4 = np.hstack((Ranking_Vec_4, Destination_4))

        Total_four_path = np.vstack((Destination_1, Destination_2, Destination_3, Destination_4))

        Total_four_path = Total_four_path[Total_four_path[:, 0].argsort()]
        Total_four_path = Total_four_path[:, 1].reshape(-1, 1)

        Total_four_path = np.hstack((np.ones((len(Total_four_path), 1)), Total_four_path))
        Total_four_path[1:, 0] = Total_four_path[:-1, 1]

        Main_NC_EV_mat[Fourpath_mask, 2:4] = Total_four_path
    return(Main_NC_EV_mat)


def Five_Trip_nonCommuter_func(Main_NC_EV_mat):
    Path_Num=5
    Fivepath_mask = np.where(Main_NC_EV_mat[:, -1] == Path_Num)

    if len(Fivepath_mask[0]) > 0:
        shop_personal_Destination = np.random.rand(int(len(Fivepath_mask[0]) / Path_Num))

        #Two trip primary

        Shopping_Destination = np.array([Trip_Destination['Shopping']] * int(len(Fivepath_mask[0]) / Path_Num)).reshape(-1, 1)
        Personal_Destination = np.ones((int(len(Fivepath_mask[0]) / Path_Num), 1)) * Trip_Destination['Personal']

        Destination_1 = np.where(shop_personal_Destination >= P_home_shop, Personal_Destination.reshape(-1, ),Shopping_Destination.reshape(-1, )).reshape(-1, 1).astype(int)

        shop_personal_Destination = np.random.rand(int(len(Fivepath_mask[0]) / Path_Num))
        Destination_2 = np.where(shop_personal_Destination >= P_home_shop, Personal_Destination.reshape(-1, ),Shopping_Destination.reshape(-1, )).reshape(-1, 1).astype(int)



        Destination_3 = np.ones((len(Destination_1), 1))

        # Two next trips primary

        shop_personal_Destination = np.random.rand(int(len(Fivepath_mask[0]) / Path_Num))
        Destination_4 = np.where(shop_personal_Destination >= P_home_shop, Personal_Destination.reshape(-1, ),Shopping_Destination.reshape(-1, )).reshape(-1, 1).astype(int)


        Destination_5 = np.ones((len(Destination_1), 1))



        Ranking_Vec_1 = np.arange(start=1, stop=len(Destination_1) * Path_Num, step=Path_Num).reshape(-1, 1)
        Ranking_Vec_2 = np.arange(start=2, stop=len(Destination_2) * Path_Num + 1, step=Path_Num).reshape(-1, 1)
        Ranking_Vec_3 = np.arange(start=3, stop=len(Destination_3) * Path_Num + 2, step=Path_Num).reshape(-1, 1)
        Ranking_Vec_4 = np.arange(start=4, stop=len(Destination_4) * Path_Num + 3, step=Path_Num).reshape(-1, 1)
        Ranking_Vec_5 = np.arange(start=5, stop=len(Destination_5) * Path_Num + 4, step=Path_Num).reshape(-1, 1)

        Destination_1 = np.hstack((Ranking_Vec_1, Destination_1))
        Destination_2 = np.hstack((Ranking_Vec_2, Destination_2))
        Destination_3 = np.hstack((Ranking_Vec_3, Destination_3))
        Destination_4 = np.hstack((Ranking_Vec_4, Destination_4))
        Destination_5 = np.hstack((Ranking_Vec_5, Destination_5))

        Total_five_path = np.vstack((Destination_1, Destination_2, Destination_3, Destination_4, Destination_5))

        Total_five_path = Total_five_path[Total_five_path[:, 0].argsort()]
        Total_five_path = Total_five_path[:, 1].reshape(-1, 1)

        Total_five_path = np.hstack((np.ones((len(Total_five_path), 1)), Total_five_path))
        Total_five_path[1:, 0] = Total_five_path[:-1, 1]

        Main_NC_EV_mat[Fivepath_mask, 2:4] = Total_five_path
    return (Main_NC_EV_mat)


def Non_Commuter_Path_Generation_func(NCPG_Inp_data,NCPG_EV_ID,NCPG_EV_zone,NCPG_Input_dd_data,n_row_dd,Input_DeDe_data,NCPG_Driver_Type,distance_bins,time_bins):

    ones = np.ones((len(NCPG_Inp_data), 1))
    NCPG_Inp_data_wz=np.where(NCPG_Inp_data == 0, ones, NCPG_Inp_data).astype(int)
    Rows_Number=int(np.sum(NCPG_Inp_data_wz))

    EV_NC_zone=NCPG_EV_zone[NCPG_EV_ID.reshape(-1,)]

    # Generating random numbers for distance&trip duration
    Rnd_pos = np.zeros((Rows_Number, 1))
    # Main_NC_EV_mat represents the main NonCommuter EV matrix including each EV ID, EV zone, its daily distance and duration per trip
    Main_NC_EV_mat = np.zeros((Rows_Number, 4)).astype('object')
    Main_NC_EV_mat[:, 0] = np.repeat(NCPG_EV_ID.reshape(-1,),repeats=NCPG_Inp_data_wz[:,0])
    Main_NC_EV_mat[:, 1] = np.repeat(EV_NC_zone.reshape(-1,),repeats=NCPG_Inp_data_wz[:,0])
    unique, counts = np.unique(Main_NC_EV_mat[:, 1] , return_counts=True)

    for i in range(len(unique)):
        mask = np.where(Main_NC_EV_mat[:, 1] == unique[i])[0]
        if len(mask)>0:
            Rnd_Input = NCPG_Input_dd_data[unique[i]]
            Main_NC_EV_mat[mask, 2:4]=Distance_Time_Rnd_func(Rnd_Input, len(mask), distance_bins,time_bins)

    Main_NC_EV_mat = np.delete(Main_NC_EV_mat, 1, axis=1).astype(float)  # delete the second column

    #Adding driver type to Main_NC_EV_mat
    NCPG_Driver_Type=np.hstack((np.arange(len(NCPG_Driver_Type)).reshape(-1,1),NCPG_Driver_Type))
    mapping = dict(zip(NCPG_Driver_Type[:, 0], range(len(NCPG_Driver_Type))))

    EV_Driver_Type=np.hstack((Main_NC_EV_mat, np.array([NCPG_Driver_Type[mapping[key], 1:] for key in Main_NC_EV_mat[:, 0]])))
    EV_Driver_Type=EV_Driver_Type[:,-1].reshape(-1,1)
    Main_NC_EV_mat = np.hstack((Main_NC_EV_mat[:, :1], EV_Driver_Type, Main_NC_EV_mat[:, 1:]))

    # Adding Origina and Destination columns to Main_NC_EV_mat
    Main_NC_EV_mat = np.hstack((Main_NC_EV_mat[:, :2], np.ones((len(Main_NC_EV_mat), 2)), Main_NC_EV_mat[:, 2:]))

    ###sorting data
    num_rows = Main_NC_EV_mat.shape[0]
    row_indices = np.arange(num_rows)  # Get original row indices

    # Sort by: first column 1, then original row index (to break ties)
    sort_order = np.lexsort((row_indices, Main_NC_EV_mat[:, 0]))

    # Apply sort
    Main_NC_EV_mat = Main_NC_EV_mat[sort_order]


    ############################################################################################

    unique, counts = np.unique(Main_NC_EV_mat[:,0], return_counts=True)

    #Adding trip numbers based on EV ID (at the end, it should be deleted)
    Main_NC_EV_mat=np.hstack((Main_NC_EV_mat, np.repeat(counts, counts).reshape(-1, 1)))


    # Generating distance and time for two-path trip
    Main_NC_EV_mat=Two_Trip_NonCommuter_func(Main_NC_EV_mat)

    # Generating distance and time for three-path trip
    Main_NC_EV_mat=Three_Trip_NonCommuter_func(Main_NC_EV_mat)

    # Generating distance and time for four-path trip
    Main_NC_EV_mat=Four_Trip_nonCommuter_func(Main_NC_EV_mat)

    # Generating distance and time for five-path trip
    Main_NC_EV_mat=Five_Trip_nonCommuter_func(Main_NC_EV_mat)


    #Generating the first Departure Time (DT), Arrival time, second departure time, and staying hour in the arrival place
    row,col=Main_NC_EV_mat.shape
    Main_NC_EV_mat=np.hstack((Main_NC_EV_mat[:,:col-1],np.zeros((row,4)),Main_NC_EV_mat[:,-1].reshape(-1,1)))


    Rnd_pos= Rand_Sample_Generation_Weighted_func(Input_DeDe_data.flatten(), row)
    Rnd_pos = -np.sort(-Rnd_pos)

    #Sorting Main_NC_EV_mat to assign initial departure time
    sort_data=np.arange(1,len(Main_NC_EV_mat)+1).reshape(-1,1)
    Main_NC_EV_mat=np.hstack((Main_NC_EV_mat,sort_data))
    Main_NC_EV_mat = Main_NC_EV_mat[Main_NC_EV_mat[:, -2].argsort()]
    Main_NC_EV_mat[:,6]=Rnd_pos
    Main_NC_EV_mat = Main_NC_EV_mat[Main_NC_EV_mat[:, -1].argsort()]
    Main_NC_EV_mat = Main_NC_EV_mat[:,:-1]

    Dis_Zeros=np.where(Main_NC_EV_mat[:,4]==0)
    Main_NC_EV_mat[Dis_Zeros,6]=np.zeros((len(Dis_Zeros[0]),1)).reshape(-1,)

    Dis_Nonzero=np.where(Main_NC_EV_mat[:,6]>0)
    Main_NC_EV_mat[Dis_Nonzero,7]=Main_NC_EV_mat[Dis_Nonzero,6]+Main_NC_EV_mat[Dis_Nonzero,5]/hour_conversion


    #Modifying the initial departure time for trips with more than 3 times of travel per day
    Dep_45_mask=np.where((Main_NC_EV_mat[:,-1]==np.array(4))|(Main_NC_EV_mat[:,-1]==np.array(5)))
    Rnd_45_trip=np.round(np.random.triangular(Leaving_Home_Hour[0], Leaving_Home_Hour[1], Leaving_Home_Hour[2],size=len(Dep_45_mask[0])) , decimals=EV_decimal)
    Main_NC_EV_mat[Dep_45_mask, 6]=Rnd_45_trip
    Main_NC_EV_mat[Dep_45_mask, 7] = Main_NC_EV_mat[Dep_45_mask, 6] + Main_NC_EV_mat[Dep_45_mask, 5] / hour_conversion

    #Shopping time
    Shopping_mask=np.where(Main_NC_EV_mat[:,3]==Trip_Destination['Shopping'])
    Main_NC_EV_mat[Shopping_mask,8]=np.round(np.random.triangular(Shopping_Dur[0], Shopping_Dur[1], Shopping_Dur[2],size=len(Shopping_mask[0])) / hour_conversion, decimals=EV_decimal)

    # Personal time
    Personal_mask = np.where(Main_NC_EV_mat[:, 3] == Trip_Destination['Personal'])
    Main_NC_EV_mat[Personal_mask, 8] = np.round(np.random.uniform(low=Personal_Dur[0], high=Personal_Dur[1], size=len(Personal_mask[0])) / hour_conversion,decimals=EV_decimal)

    #Completing the second departure time
    Dep_2_mask=np.where(Main_NC_EV_mat[:, 8]>0)
    Main_NC_EV_mat[Dep_2_mask, 9]=Main_NC_EV_mat[Dep_2_mask, 7]+Main_NC_EV_mat[Dep_2_mask, 8]

    #Assigning the second departure time for EV drivers who stayed at home
    Dep_2_mask = np.where(Main_NC_EV_mat[:, 10] ==1)
    Main_NC_EV_mat[Dep_2_mask, 9]=np.ones((len(Dep_2_mask[0]),))*24

    # Assigning the second departure time for EV drivers with two trips
    Dep_2_mask=np.where((Main_NC_EV_mat[:, 10] ==2) & (Main_NC_EV_mat[:, 2] ==1) )
    First_Part_2trip=Main_NC_EV_mat[Dep_2_mask[0],:]
    First_Part_2trip[:, 6] = First_Part_2trip[:, 9]
    First_Part_2trip[:, 9]=np.array([24]*int(len(First_Part_2trip)))
    First_Part_2trip[:, 7] = First_Part_2trip[:, 6]+First_Part_2trip[:, 5]/hour_conversion
    First_Part_2trip[:, 8] =First_Part_2trip[:, 9] - First_Part_2trip[:, 7]
    Main_NC_EV_mat[Dep_2_mask[0]+1,4:]=First_Part_2trip[:,4:]

    # Assigning the second departure time for EV drivers with more than two trips
    Dep_345_mask = np.where(Main_NC_EV_mat[:, 10] > 2)
    First_Part_345trip = Main_NC_EV_mat[Dep_345_mask[0], :]


    unique, counts = np.unique(First_Part_345trip[:, 0], return_counts=True)
    cum_counts_sum = np.cumsum(counts)

    for i in range(len(counts)):
        if i==0:
            Start_row=i+1
            Finish_row=cum_counts_sum[i]
            Departure_time = First_Part_345trip[i, 9]
        else:
            Start_row = cum_counts_sum[i-1]+1
            Finish_row = cum_counts_sum[i]
            Departure_time = First_Part_345trip[Start_row-1, 9]


        for j in range(Start_row,Finish_row):
            First_Part_345trip[j, 6]=Departure_time
            First_Part_345trip[j, 7]=First_Part_345trip[j, 6]+First_Part_345trip[j, 5]/hour_conversion
            if ((First_Part_345trip[j, 8]==np.array(0))&(j<(Finish_row-1))):
                First_Part_345trip[j, 8]=2 #stay at home for 2 hours
                First_Part_345trip[j, 9] =First_Part_345trip[j, 7]+First_Part_345trip[j, 8]
            elif ((First_Part_345trip[j, 8]==np.array(0))&(j==(Finish_row-1))):
                First_Part_345trip[j, 9] =24
                First_Part_345trip[j, 8]=First_Part_345trip[j, 9]-First_Part_345trip[j, 7]
            else:
                First_Part_345trip[j, 9]=First_Part_345trip[j, 7]+First_Part_345trip[j, 8]

            Departure_time = First_Part_345trip[j, 9]


    Main_NC_EV_mat[Dep_345_mask, :]=First_Part_345trip

    # swapping column 8 and 9
    Main_NC_EV_mat[:, [8, 9]] = Main_NC_EV_mat[:, [9, 8]]

    #EVID45 mask
    EVID_From_Main=Main_NC_EV_mat[:,[0,2,10]]
    EVID_From_shift = Main_NC_EV_mat[:, [0, 3]]
    EVID_From_shift=np.vstack((EVID_From_shift[1:,:],EVID_From_shift[0,:]))


    EVID45_mask=np.where((EVID_From_Main[:,0]==EVID_From_shift[:,0])&(EVID_From_Main[:,1]==EVID_From_shift[:,1])&(EVID_From_Main[:,2]>3)&(EVID_From_Main[:,1]==np.array(Trip_Destination['Home'])))
    if len(EVID45_mask[0])>0:
        EVID45_mask_1=np.vstack((EVID45_mask[0].reshape(-1,1),(EVID45_mask[0]+np.array(1)).reshape(-1,1)))
        unq, count = np.unique(EVID45_mask_1, axis=0, return_counts=True)
        Repeated_rows=unq[count>1]-1

        EVID45_mask=set(EVID45_mask[0].flatten())
        Repeated_rows=set(Repeated_rows.flatten())

        EVID45_mask=np.array(list(EVID45_mask-Repeated_rows)).reshape(-1,1)
        Main_NC_EV_mat[EVID45_mask+1,[4,5]]=Main_NC_EV_mat[EVID45_mask,[4,5]]
        Main_NC_EV_mat[EVID45_mask + 1, 7]=Main_NC_EV_mat[EVID45_mask + 1, 6]+Main_NC_EV_mat[EVID45_mask + 1, 5]/hour_conversion
        Main_NC_EV_mat[EVID45_mask + 1, 9] = Main_NC_EV_mat[EVID45_mask + 1, 8] - Main_NC_EV_mat[EVID45_mask + 1, 7]

    return(Main_NC_EV_mat[:,:-1])


def fix_origins_vectorized(data, col):

    # Compare current and previous BEV_IDs
    bev_id_prev = data[:-1, col[0]]
    bev_id_curr = data[1:, col[0]]

    # Destination from previous rows
    destination_prev = data[:-1, col[3]]

    # Boolean mask where BEV_ID doesn't change between rows
    same_bev_mask = bev_id_prev == bev_id_curr

    # Apply: set origin (col 2) to previous destination (col 8) if same BEV_ID
    data[1:, col[2]][same_bev_mask] = destination_prev[same_bev_mask]
    return(data)


def update_departure_arrival_and_idle(data, col):
    # Extract relevant slices
    bev_id_prev = data[:-1, col[0]]
    bev_id_curr = data[1:, col[0]]

    # Define current row data
    second_dep_prev = data[:-1, col[8]]  # second_departure[t-1]
    departure_curr = data[1:, col[6]]  # departure[t]
    duration_curr = data[1:, col[5]]  # duration[t]
    second_dep_curr = data[1:, col[8]]  # second_departure[t]

    # Find valid rows where BEV_ID continues
    same_bev_mask = bev_id_prev == bev_id_curr
    row_indices = np.where(same_bev_mask)[0] + 1  # Absolute row indices in `data`

    # Compute updated departures
    updated_departures = np.maximum(second_dep_prev[same_bev_mask], departure_curr[same_bev_mask])

    # Find rows where departure changes
    departure_changed = updated_departures != departure_curr[same_bev_mask]
    changed_indices = row_indices[departure_changed]

    # Apply updated departure
    data[changed_indices, col[6]] = updated_departures[departure_changed]

    # Compute and apply updated arrival
    updated_arrivals = updated_departures[departure_changed] + duration_curr[same_bev_mask][departure_changed] / 60
    data[changed_indices, col[7]] = updated_arrivals

    # Compute and apply column 9 = second_departure - updated arrival
    idle_times = second_dep_curr[same_bev_mask][departure_changed] - updated_arrivals
    data[changed_indices, col[9]] = idle_times
    return(data)



#To improve the speed of processing instead of numpy 'isin' built-in function
def is_in_set_func(a, b):
    set_b = set(b)
    return np.array([x in set_b for x in a])

def Storing_SQLite_DB_func(Storing_path,SQLite_File_Inp,File_Number):
    Output_path = Storing_path + '\\Step1_BEV Mobility_{}.db'.format(File_Number)
    # Create your connection.
    conn = sqlite3.connect(Output_path)

    #Storing data into conn
    SQLite_File_Inp.to_sql(name='EV_Data', con=conn)

    if conn:
        conn.close()

    return

def Reading_SQLite_PV_DB_func(Storing_path):
    # Create a SQL connection to the SQLite database
    con = sqlite3.connect(Storing_path)

    # creating cursor
    cur = con.cursor()

    Table_Name = os.path.basename(Storing_path)
    Table_Name = Table_Name[:-3]

    try:
        # Reading data from EV_Data table
        df = pd.read_sql_query('SELECT * FROM {}'.format(Table_Name), con)
    except:

        res = con.execute("SELECT name FROM sqlite_master WHERE type='table';")
        for name in res.fetchall():
            Table_Name=name[0]

            # Reading data from EV_Data table
            df = pd.read_sql_query('SELECT * FROM {}'.format(Table_Name), con)



    # Drop the index column
    try:
        df = df.drop('index', axis=1)
    except:
        pass

    # close the connection
    con.close()
    return (df)


def Hour_Minute(Inp_data):
    Inp_hour = np.floor(Inp_data).astype(int)
    Inp_minute = np.round((Inp_data - Inp_hour) * 60).astype(int)
    Inp_hour = np.hstack((Inp_hour.reshape(-1, 1), Inp_minute.reshape(-1, 1)))
    df = pd.DataFrame(Inp_hour)
    df_col = list(df.columns)
    df['time'] = df[df_col[0]].astype(str) + ':' + df[df_col[1]].astype(str).str.zfill(2)
    return(pd.DataFrame(df['time']))


def ABS_Check(Total_Main_EV_matrix):
    col_Arrival=7
    col_TD=10 #TD stands for travel distance
    col_TT=12 #TT stands for travel time
    col_AT=13 #AT stands for arrival time
    col_FDT=11 #FDT stands for the first departure time
    col_Dur_stay=14 #duration of stay column

    # Convert timestamp column (column 7) to datetime if it's not already
    Total_Main_EV_matrix.iloc[:, col_Arrival] = pd.to_datetime(Total_Main_EV_matrix.iloc[:, col_Arrival])

    # Save a copy of original column 12 (index 11) to detect where values changed
    original_col12 = Total_Main_EV_matrix.iloc[:, col_TT].copy()

    # Step 1: Make columns 10 and 12 positive (absolute value)
    Total_Main_EV_matrix.iloc[:, col_TD] = Total_Main_EV_matrix.iloc[:, col_TD].abs()
    Total_Main_EV_matrix.iloc[:, col_TT] = Total_Main_EV_matrix.iloc[:, col_TT].abs()

    # Step 2: Update column 13 for rows where column 12 became positive
    #         Column 13 = Column 11 + Column 12
    #         Only apply where original column 12 was negative (before abs())
    updated_rows = original_col12 < 0  # rows where value changed

    Total_Main_EV_matrix.loc[updated_rows, Total_Main_EV_matrix.columns[col_AT]] = (
            Total_Main_EV_matrix.loc[updated_rows, Total_Main_EV_matrix.columns[col_FDT]] +
            Total_Main_EV_matrix.loc[updated_rows, Total_Main_EV_matrix.columns[col_TT]]
    )


    # Now update the time in timestamp (column 7) based on column 13
    def update_time(row):
        original_datetime = row.iloc[col_Arrival]  # Column 7 = index 6
        decimal_hours = row.iloc[col_AT]  # Column 13 = index 12
        if pd.isnull(decimal_hours):
            return original_datetime  # Skip if NaN

        hours = int(decimal_hours)
        minutes = int(round((decimal_hours - hours) * 60))

        return original_datetime.replace(hour=hours, minute=minutes)




    Total_Main_EV_matrix.iloc[:, col_Arrival] = Total_Main_EV_matrix.apply(update_time, axis=1)

    # Step 0: Convert to datetime to ensure consistency
    Total_Main_EV_matrix.iloc[:, col_Arrival] = pd.to_datetime(Total_Main_EV_matrix.iloc[:, col_Arrival], errors='coerce')

    # Step 1: Format consistently as string with seconds
    Total_Main_EV_matrix.iloc[:, col_Arrival] = Total_Main_EV_matrix.iloc[:, col_Arrival].dt.strftime("%m/%d/%Y %H:%M:%S")

    #Updating the column of duration of stay
    col=list(Total_Main_EV_matrix.columns)
    Total_Main_EV_matrix.loc[updated_rows, col[col_Dur_stay]]=Total_Main_EV_matrix.loc[updated_rows, col[col_Dur_stay+1]].astype(float)-Total_Main_EV_matrix.loc[updated_rows, col[col_Dur_stay-1]].astype(float)


    return(Total_Main_EV_matrix)


# determine if application is a script file or frozen exe
if getattr(sys, 'frozen', False):
    application_path = os.path.dirname(sys.executable)
elif __file__:
    application_path = os.path.dirname(__file__)

def Main_Function_Step2(Num_EV, Simu_Day_in_Month,Sim_Month,Simu_year,Step1_Mat_column,Main_Zone_name,Storage_path,Max_CSV_Rows):
    origin_path = str(Path(Storage_path).parent) + '\\{}.db'.format(GV.Initial_Mat_Sqlit_Name)
    destination_path = Storage_path + '\\{}.db'.format(GV.Initial_Mat_Sqlit_Name)
    shutil.copy2(origin_path, destination_path)
    GV.Initial_BEV_Mat = Reading_SQLite_PV_DB_func(destination_path)
    col = list(GV.Initial_BEV_Mat.columns)
    Initial_Matrix = GV.Initial_BEV_Mat.to_numpy()
    Driver_type_weekdays=Initial_Matrix[:,3].reshape(-1,1).astype(int)

    mask_prime = np.where(Driver_type_weekdays == np.array(1))
    EV_C_ID = mask_prime[0]
    
    EV_zone=Initial_Matrix[:,1].reshape(-1,1)
    EV_working_zone=Initial_Matrix[:,2].reshape(-1,1)



    unique, counts = np.unique(EV_working_zone, return_counts=True)
    EV_Working_Zone = dict()
    for i in range(len(unique)):
        key = unique[i]
        value = np.where(EV_working_zone == key)[0]
        EV_Working_Zone[key] = value

    unique, counts = np.unique(EV_zone, return_counts=True)
    EV_Living_Zone = dict()
    for i in range(len(unique)):
        key = unique[i]
        value = np.where(EV_zone == key)[0]
        EV_Living_Zone[key] = value



    #############################Daily trip per week is generated for each EV#################
    Inp_dtpw_path = sys.path[0] + '\\' + Input_list[1]
    sheet_name = xl.load_workbook(Inp_dtpw_path).sheetnames
    Input_dtwp_data = dict.fromkeys(Main_Zone_name)  # initialize a dict with keys from the sheet_name value

    for i in range(len(sheet_name)):
        Input_dtwp_data[Main_Zone_name[i]] = pd.read_excel(Inp_dtpw_path, sheet_name=sheet_name[i]).to_numpy()[:, 1:]


    #############################Reading joint probability distribution of the distance and duration per each trip#################
    Inp_dd_path = sys.path[0]+'\\'+Input_list[2]
    sheet_name = xl.load_workbook(Inp_dd_path).sheetnames

    Input_dd_data=dict.fromkeys(Main_Zone_name) # initialize a dict with keys from the sheet_name value

    for i in range(len(sheet_name)):
        Input_dd_data[Main_Zone_name[i]]=pd.read_excel(Inp_dd_path,sheet_name=sheet_name[i]).to_numpy()[1:,1:]

    n_row_dd,n_col_dd=Input_dd_data[sheet_name[0]].shape

    # EV_ID=np.arange(1,Num_EV+1)
    #Reading the distance and duration data for a trip between two cities
    Inp_dd_b2cities_data=pd.read_excel(sys.path[0]+'\\'+Input_list[3]).to_numpy()
    Inp_dd_b2cities_data[:,-1]=Inp_dd_b2cities_data[:,-1]/hour_conversion


    #############################This part reads the Departure_Destination_Trip matrix#################
    Inp_DeDe_path = sys.path[0]+'\\'+Input_list[4]

    Input_DeDe_data = pd.read_excel(Inp_DeDe_path).to_numpy()[:,1:]

    # Define distance and time bins
    distance_bins = np.arange(5, 165, 5)  # [2, 5), [5, 10), ..., [160, 165)
    time_bins = np.arange(5, 170, 5)  # [5, 10), [10, 15), ..., [165, 170)
    distance_bins = np.insert(distance_bins, 0, 2)

    #######this function creates distance and duration (minute) for commuting EVs for one day
    OneDay_Commuting_EV_mat=EV_Commuting_Data_func(Driver_type_weekdays,EV_zone,EV_working_zone,Input_dd_data,Inp_dd_b2cities_data,n_row_dd,distance_bins,time_bins)


    OneDay_Commuting_EV_mat=np.round(OneDay_Commuting_EV_mat,decimals=EV_decimal)

    #One column is added to return the OneDay_Commuting_EV_mat matrix to its initial order latter
    OneDay_Commuting_EV_mat=np.hstack((np.arange(len(OneDay_Commuting_EV_mat)).reshape(-1,1),OneDay_Commuting_EV_mat))
    OneDay_Commuting_EV_mat = OneDay_Commuting_EV_mat[OneDay_Commuting_EV_mat[:, -1].argsort()]

    #Generate random number for leaving home [C stands for commuter EV drivers]
    OneDay_C_LeaveHomeTime=np.round(np.random.triangular(Leaving_Home_Hour[0], Leaving_Home_Hour[1], Leaving_Home_Hour[2], len(OneDay_Commuting_EV_mat)).reshape(-1,1),decimals=EV_decimal)
    OneDay_C_LeaveHomeTime=OneDay_C_LeaveHomeTime[OneDay_C_LeaveHomeTime[:,0].argsort()]
    OneDay_C_LeaveHomeTime=np.flip(OneDay_C_LeaveHomeTime)

    #Adding the home departure time to the commuting EVs
    OneDay_Commuting_EV_mat=np.hstack((OneDay_Commuting_EV_mat,OneDay_C_LeaveHomeTime))
    del OneDay_C_LeaveHomeTime
    OneDay_Commuting_EV_mat = OneDay_Commuting_EV_mat[OneDay_Commuting_EV_mat[:, 0].argsort()]
    #Adding office arrival time to the commuting EVs
    OneDay_Commuting_EV_mat=np.hstack((OneDay_Commuting_EV_mat,np.round((OneDay_Commuting_EV_mat[:,3]/hour_conversion+OneDay_Commuting_EV_mat[:,4]).reshape(-1,1),decimals=EV_decimal)))
    OneDay_Commuting_EV_mat = OneDay_Commuting_EV_mat[OneDay_Commuting_EV_mat[:, -1].argsort()]

    # Generate random number for leaving work
    OneDay_C_LeaveWorkTime = np.round(np.random.triangular(Leaving_Work_Hour[0], Leaving_Work_Hour[1], Leaving_Work_Hour[2],len(OneDay_Commuting_EV_mat)).reshape(-1, 1), decimals=EV_decimal)
    OneDay_C_LeaveWorkTime = OneDay_C_LeaveWorkTime[OneDay_C_LeaveWorkTime[:, 0].argsort()]

    # Adding the work departure time to the commuting EVs
    OneDay_Commuting_EV_mat = np.hstack((OneDay_Commuting_EV_mat, OneDay_C_LeaveWorkTime))
    del OneDay_C_LeaveWorkTime
    # columns of the OneDay_Commuting_EV_mat are: EV ID, distance, duration (minute), departure from home, Arrival to office, and departure from office (initial: latter a randomness values are inserted) to calculate total staying hours at office
    OneDay_Commuting_EV_mat = OneDay_Commuting_EV_mat[OneDay_Commuting_EV_mat[:, 0].argsort()]
    OneDay_Commuting_EV_mat=OneDay_Commuting_EV_mat[:,1:]

    # Integration of commuter EV data with associated departure and destination locations
    Driver_ID_value = list(Driver_type_ID.values())
    TD_value = list(Trip_Destination.values())

    #Adding three columns of driver type, home and work as destination places
    OneDay_Commuting_EV_mat = np.hstack((OneDay_Commuting_EV_mat[:, :1],np.array([Driver_ID_value[1]] * len(OneDay_Commuting_EV_mat)).reshape(-1, 1),OneDay_Commuting_EV_mat[:, 1:]))
    OneDay_Commuting_EV_mat = np.hstack((OneDay_Commuting_EV_mat[:, :2],np.array([TD_value[0]] * len(OneDay_Commuting_EV_mat)).reshape(-1, 1),OneDay_Commuting_EV_mat[:, 2:]))
    OneDay_Commuting_EV_mat = np.hstack((OneDay_Commuting_EV_mat[:, :3],np.array([TD_value[1]] * len(OneDay_Commuting_EV_mat)).reshape(-1, 1),OneDay_Commuting_EV_mat[:, 3:]))


    Total_Day_counter = 0

    Output_File_Flag = True
    Output_File_Counter=0


    Simu_week=int(Simu_Day_in_Month/7)
    if (Simu_Day_in_Month/7)>int(Simu_Day_in_Month/7):
        Simu_week+=1

    Total_Day_counter_Falg = False
    for i in range(Simu_week): #week counter

        ####Creating EV_trip matrix for Non_commuter drivers for a week
        EV_NC_mask = np.where(Driver_type_weekdays == np.array(0))
        EV_Non_Commuting_Zone = EV_zone[EV_NC_mask]
        EV_NC_Trip = np.zeros((len(EV_NC_mask[0]), 7))

        # creating EV_non commuter id for 7 days of weekdays
        EV_NC_ID = np.repeat(EV_NC_mask[0].reshape(-1, 1), repeats=7, axis=1)

        for k in range(len(Main_Zone_name)):
            mask = np.where(EV_Non_Commuting_Zone == Main_Zone_name[k])
            if len(mask[0]) > 0:
                # Daily trip per week:DTPW
                DTPW_Input = Input_dtwp_data[Main_Zone_name[k]]
                try:
                    EV_NC_Trip[mask[0], :] = Daily_trip_per_week_NC_func(DTPW_Input, len(mask[0]), EV_NC_ID[mask[0], :])
                except:
                    pass


        #Modifying Number of trips for commuter EVs based on shopping and personal probability values
        EV_C_mask = np.where(Driver_type_weekdays == np.array(1))
        for k in range(2):
            one_Prob = np.ones((len(EV_C_mask[0]), 5))
            zero_Prob = np.zeros((len(EV_C_mask[0]), 5))
            Rnd_Prob = np.random.rand(len(EV_C_mask[0]), 5)
            if k==0:
                Rnd_Prob_bw_personal = np.random.rand(len(EV_C_mask[0]), 5)
                EV_Commuter_Trip_personal=np.where(P_w_personal>=Rnd_Prob,one_Prob,zero_Prob)
                EV_Commuter_bw_personal = np.where(P_bw_personal >= Rnd_Prob_bw_personal, one_Prob, zero_Prob)
                EV_Commuter_bw_personal=np.multiply(EV_Commuter_bw_personal,EV_Commuter_Trip_personal)
                EV_Commuter_aw_personal=EV_Commuter_Trip_personal-EV_Commuter_bw_personal
                EV_Commuter_Update = np.ones((len(EV_C_mask[0]), 5)) * 2
            else:
                EV_Commuter_Trip_shopping = np.where(P_w_shopping >= Rnd_Prob, one_Prob, zero_Prob)


        EV_C_Trip=EV_Commuter_Update+EV_Commuter_Trip_personal+EV_Commuter_Trip_shopping




        #Create weekends (2days) data for commuter EVs
        EV_C_Trip=np.hstack((EV_C_Trip,np.zeros((len(EV_C_Trip),2))))
        EV_Commuting_Zone=EV_zone[EV_C_mask]
        for mz in range(len(Main_Zone_name)):
            mask = np.where(EV_Commuting_Zone == Main_Zone_name[mz])
            row_number=len(mask[0])
            if row_number>0:
                #Daily trip per week:DTPW
                DTPW_Input = Input_dtwp_data[Main_Zone_name[mz]]
                # Generate 2 random numbers corresponding to 2 days in weekends
                weekend_ind = Rand_Sample_Generation_Weighted_func(DTPW_Input[:, 1], 2 * row_number) - 1
                EV_C_Trip[mask[0],5:7]=weekend_ind.reshape(row_number, 2)



        Sim_week=i+1
        #simulation is carried out for 7 days (equal to one week)
        for j in range(7): #Day counter

            ####Creating EV_trip matrix for Commuter drivers for a week
            OneWeek_Commuting_EV_mat = OneDay_Commuting_EV_mat.copy()

            #Adding a randmness (8 minutes, 10 minutes, and 12 minutes) to the departure time for commuter EVs and calculate total staying time at work
            Rnd_Dep=(np.round(np.random.triangular(LWH_Randomness[0],LWH_Randomness[1],LWH_Randomness[2],len(OneWeek_Commuting_EV_mat)),2)*(2*np.random.randint(0,2,size=len(OneWeek_Commuting_EV_mat))-1)).reshape(-1,1)
            OneWeek_Commuting_EV_mat[:,OD_EV_departure2_col]=OneWeek_Commuting_EV_mat[:,OD_EV_departure2_col]+(Rnd_Dep/hour_conversion).reshape(-1,1)[:,0] #hour conversion
            OneWeek_Commuting_EV_mat[:, OD_EV_departure2_col]=np.round(OneWeek_Commuting_EV_mat[:,OD_EV_departure2_col],decimals=EV_decimal)
            del Rnd_Dep
            #Adding staying hours at work for commuter EVs: columns of the OneWeek_Commuting_EV_mat are: EV ID, distance, duration (minute), departure from home, Arrival to office, departure from office, and working hours
            OneWeek_Commuting_EV_mat = np.hstack((OneWeek_Commuting_EV_mat, np.round((OneWeek_Commuting_EV_mat[:,OD_EV_departure2_col]-OneWeek_Commuting_EV_mat[:,OD_EV_arrival_col]).reshape(-1,1),decimals=EV_decimal)))

            #Building commuter trip data with details for weekdays
            if j<5:
                Flag_P_BW=False
                Flag_P_AW=False
                Flag_Shop=False
                #Total number of personal trips before going to work (commuter EVs)
                BW_Number = int(np.sum(EV_Commuter_bw_personal[:,j]))
                if BW_Number>0:
                    OneDayB_C_Personal=Personal_Shopping_Modification_Commuter_EVs_func(EV_Commuter_bw_personal, OneWeek_Commuting_EV_mat, j, 'before', 'personal')
                    Flag_P_BW=True

                # Total number of personal trips after going to work (commuter EVs)
                AW_Number = int(np.sum(EV_Commuter_aw_personal[:, j]))
                if AW_Number > 0:
                    OneDayA_C_Personal = Personal_Shopping_Modification_Commuter_EVs_func(EV_Commuter_aw_personal,OneWeek_Commuting_EV_mat, j,'after', 'personal')
                    Flag_P_AW=True



                # Total number of shopping trips after going to work (commuter EVs)
                Shopping_Number= int(np.sum(EV_Commuter_Trip_shopping[:, j]))
                if Shopping_Number > 0:
                    OneDay_C_Shopping = Personal_Shopping_Modification_Commuter_EVs_func(EV_Commuter_Trip_shopping,OneWeek_Commuting_EV_mat, j,'after', 'shopping')
                    Flag_Shop=True




                #Create work to home matrix and combine commuter matrices
                OneWeek_Commuting_EV_mat=np.vstack((OneWeek_Commuting_EV_mat,work_2_home_func(OneWeek_Commuting_EV_mat.copy())))
                #Update the OneWeek_Commuting_EV_mat data if before and after office, an EV driver runs other tasks
                if Flag_P_BW==True:
                    #Halve the OneWeek_Commuting_EV_mat
                    Halve_OneWeek_Commuting_EV_mat=OneWeek_Commuting_EV_mat[:int(len(OneWeek_Commuting_EV_mat)/2),:]
                    BW_rows=OneDayB_C_Personal[:,0].astype(int).tolist()
                    HOW_rows=Halve_OneWeek_Commuting_EV_mat[:,0].astype(int).tolist()
                    x = [HOW_rows.index(i) for i in BW_rows]

                    Halve_OneWeek_Commuting_EV_mat[x,OD_EV_distance_col]=Halve_OneWeek_Commuting_EV_mat[x,OD_EV_distance_col]-OneDayB_C_Personal[:,OD_EV_distance_col]
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_duration_col] = Halve_OneWeek_Commuting_EV_mat[x, OD_EV_duration_col] - OneDayB_C_Personal[:,OD_EV_duration_col]
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_departure1_col] = OneDayB_C_Personal[:,OD_EV_departure2_col]
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_arrival_col] =Halve_OneWeek_Commuting_EV_mat[x, OD_EV_departure1_col]+Halve_OneWeek_Commuting_EV_mat[x, OD_EV_duration_col]/hour_conversion
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_departure2_col]=Halve_OneWeek_Commuting_EV_mat[x, OD_EV_departure2_col]+OneDayB_C_Personal[:,OD_EV_stayingtime_col]
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_stayingtime_col] =Halve_OneWeek_Commuting_EV_mat[x, OD_EV_departure2_col]-Halve_OneWeek_Commuting_EV_mat[x, OD_EV_arrival_col]

                    OneWeek_Commuting_EV_mat[:int(len(OneWeek_Commuting_EV_mat) / 2), :]=np.around(Halve_OneWeek_Commuting_EV_mat,decimals=EV_decimal)
                    del Halve_OneWeek_Commuting_EV_mat,x,HOW_rows,BW_rows
                if Flag_P_AW==True:
                    # Halve the OneWeek_Commuting_EV_mat
                    Halve_OneWeek_Commuting_EV_mat = OneWeek_Commuting_EV_mat[int(len(OneWeek_Commuting_EV_mat) / 2):,:]
                    AW_rows = OneDayA_C_Personal[:, 0].astype(int).tolist()
                    HOW_rows = Halve_OneWeek_Commuting_EV_mat[:, 0].astype(int).tolist()
                    x = [HOW_rows.index(i) for i in AW_rows]

                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_distance_col] = Halve_OneWeek_Commuting_EV_mat[x, OD_EV_distance_col] - OneDayA_C_Personal[:,OD_EV_distance_col]
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_duration_col] = Halve_OneWeek_Commuting_EV_mat[x, OD_EV_duration_col] - OneDayA_C_Personal[:,OD_EV_duration_col]
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_departure1_col] = OneDayA_C_Personal[:,OD_EV_departure2_col]
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_arrival_col] = Halve_OneWeek_Commuting_EV_mat[x, OD_EV_departure1_col] + Halve_OneWeek_Commuting_EV_mat[x, OD_EV_duration_col] / hour_conversion
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_stayingtime_col] = Halve_OneWeek_Commuting_EV_mat[x, OD_EV_departure2_col] - Halve_OneWeek_Commuting_EV_mat[ x, OD_EV_arrival_col]

                    OneWeek_Commuting_EV_mat[int(len(OneWeek_Commuting_EV_mat) / 2):, :] = np.around(Halve_OneWeek_Commuting_EV_mat, decimals=EV_decimal)

                    del Halve_OneWeek_Commuting_EV_mat, x, HOW_rows

                if Flag_Shop==True:
                    # Halve the OneWeek_Commuting_EV_mat
                    Halve_OneWeek_Commuting_EV_mat = OneWeek_Commuting_EV_mat[int(len(OneWeek_Commuting_EV_mat) / 2):,:]
                    AWS_rows = OneDay_C_Shopping[:, 0].astype(int).tolist()
                    HOW_rows = Halve_OneWeek_Commuting_EV_mat[:, 0].astype(int).tolist()
                    x = [HOW_rows.index(i) for i in AWS_rows]

                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_distance_col] = Halve_OneWeek_Commuting_EV_mat[x, OD_EV_distance_col] - OneDay_C_Shopping[:,OD_EV_distance_col]
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_duration_col] = Halve_OneWeek_Commuting_EV_mat[x, OD_EV_duration_col] - OneDay_C_Shopping[:,OD_EV_duration_col]
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_departure1_col] = OneDay_C_Shopping[:,OD_EV_departure2_col]
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_arrival_col] = Halve_OneWeek_Commuting_EV_mat[ x, OD_EV_departure1_col] + Halve_OneWeek_Commuting_EV_mat[ x, OD_EV_duration_col] / hour_conversion
                    Halve_OneWeek_Commuting_EV_mat[x, OD_EV_stayingtime_col] = Halve_OneWeek_Commuting_EV_mat[x, OD_EV_departure2_col] - Halve_OneWeek_Commuting_EV_mat[ x, OD_EV_arrival_col]

                    OneWeek_Commuting_EV_mat[int(len(OneWeek_Commuting_EV_mat) / 2):, :] = np.around(Halve_OneWeek_Commuting_EV_mat, decimals=EV_decimal)

                    del Halve_OneWeek_Commuting_EV_mat, x, HOW_rows


                # Update the OneWeek_Commuting_EV_mat data by adding the EV driver's other tasks
                if Flag_P_BW == True:
                    OneWeek_Commuting_EV_mat = np.vstack((OneWeek_Commuting_EV_mat, OneDayB_C_Personal))
                if Flag_P_AW==True:
                    OneWeek_Commuting_EV_mat = np.vstack((OneWeek_Commuting_EV_mat,OneDayA_C_Personal))
                if Flag_Shop==True:
                    OneWeek_Commuting_EV_mat = np.vstack((OneWeek_Commuting_EV_mat,OneDay_C_Shopping))


                #sort by EV driver ID and Origin
                df=pd.DataFrame(OneWeek_Commuting_EV_mat)
                col=list(df.columns)
                OneWeek_Commuting_EV_mat=df.sort_values([col[0],col[2],col[8]], ascending=[True, True,True]).to_numpy()
                OneWeek_Commuting_EV_mat[1:,OD_EV_origin_col]=OneWeek_Commuting_EV_mat[:-1,OD_EV_destination_col]
                del df

                #######Fixing the origin of BEV data
                OneWeek_Commuting_EV_mat = fix_origins_vectorized(OneWeek_Commuting_EV_mat.copy(), col)

                #####update_departure_and_arrival
                OneWeek_Commuting_EV_mat = update_departure_arrival_and_idle(OneWeek_Commuting_EV_mat.copy(), col)



            # Building non_commuter trip data with details for weekdays
            if j<5:
                # Adding staying hours at work for commuter EVs: columns of the OneWeek_Commuting_EV_mat are: EV ID, distance, duration (minute), first departure, Arrival to first destination, departure from first destination, and staying hour in the first destination
                OneDay_NonCommuting_EV_mat=Non_Commuter_Path_Generation_func(EV_NC_Trip[:,j].reshape(-1,1),EV_NC_ID[:,j].reshape(-1,1),EV_zone,Input_dd_data,n_row_dd,Input_DeDe_data,Driver_type_weekdays.copy(),distance_bins,time_bins)

            # Building commuter and non_commuter trip data with details for weekends (just two days)
            if j>=5:

                EV_NC_C_Trip = np.hstack((EV_NC_Trip[:, j] , EV_C_Trip[:, j]))
                EV_NC_C_ID = np.hstack((EV_NC_ID[:, j] , EV_C_ID))

                # Adding staying hours at work for commuter EVs: columns of the OneWeek_Commuting_EV_mat are: EV ID, distance, duration (minute), first departure, Arrival to first destination, departure from first destination, and staying hour in the first destination
                OneDay_NC_C_EV_mat = Non_Commuter_Path_Generation_func(EV_NC_C_Trip.reshape(-1, 1), EV_NC_C_ID.reshape(-1, 1), EV_zone,Input_dd_data, n_row_dd, Input_DeDe_data,Driver_type_weekdays.copy(),distance_bins,time_bins)


            if j<5:
                Main_EV_mat=np.vstack((OneWeek_Commuting_EV_mat,OneDay_NonCommuting_EV_mat))
            else:
                Main_EV_mat =OneDay_NC_C_EV_mat


            #Sorting the Main_EV_mat based on EV ID column
            Main_EV_mat=pd.DataFrame(Main_EV_mat)
            col=list(Main_EV_mat.columns)
            Main_EV_mat=Main_EV_mat.sort_values([col[0], col[8]], ascending=[True, True]).to_numpy()

            Total_Day_counter+=1

            Sim_Month_Next,Sim_Day=Numday_to_Month_Day_func(Total_Day_counter)

            if Total_Day_counter_Falg==True:
                Sim_Month_Next+=1


            if Total_Day_counter==Simu_Day_in_Month:
                Total_Day_counter=0
                Total_Day_counter_Falg=True



            Month_week_day_matrix = np.array([Simu_year] * len(Main_EV_mat)).reshape(-1, 1)
            Month_week_day_matrix = np.hstack((Month_week_day_matrix, np.array([Sim_Month_Next] * len(Main_EV_mat)).reshape(-1, 1)))
            Month_week_day_matrix = np.hstack((Month_week_day_matrix, np.array([Sim_week] * len(Main_EV_mat)).reshape(-1, 1)))
            Month_week_day_matrix = np.hstack((Month_week_day_matrix, np.array([Sim_Day] * len(Main_EV_mat)).reshape(-1, 1)))

            if Output_File_Flag==True:
                Total_Main_EV_matrix=Main_EV_mat
                MWD_matrix=Month_week_day_matrix.copy()
                Output_File_Flag = False
            else:
                Total_Main_EV_matrix=np.vstack((Total_Main_EV_matrix,Main_EV_mat))
                MWD_matrix=np.vstack((MWD_matrix,Month_week_day_matrix))


        if (Total_Main_EV_matrix.shape[0]>Max_CSV_Rows) or ((i==(Simu_week-1) and (j==6))):
            Output_File_Counter+=1
            Output_File_Flag=True
            #convert duration data to hour
            Total_Main_EV_matrix[:,5]=Total_Main_EV_matrix[:,5]/hour_conversion

            #Round the last four columns data
            for r in range(6):
                Total_Main_EV_matrix[:,-(r+1)]=np.round(Total_Main_EV_matrix[:,-(r+1)],decimals=EV_decimal)

            #Create hour column
            Total_Main_EV_matrix[:, 7] = np.where(Total_Main_EV_matrix[:, 7] > 23.99, 23.99,Total_Main_EV_matrix[:, 7])
            Total_Main_EV_matrix[:, 6] = np.where(Total_Main_EV_matrix[:, 6] > 23.99, 23.99,Total_Main_EV_matrix[:, 6])

            Departure_hour = pd.DataFrame(np.floor(Total_Main_EV_matrix[:, 6]).astype(int))
            Arrival_hour = pd.DataFrame(np.floor(Total_Main_EV_matrix[:, 7]).astype(int))

            Departure_hour_format = Hour_Minute(Total_Main_EV_matrix[:, 6].astype(float))
            Arrival_hour_format = Hour_Minute(Total_Main_EV_matrix[:, 7].astype(float))

            MWD_matrix[:,1]=MWD_matrix[:,1]+(Sim_Month-1)
            Total_Main_EV_matrix=np.hstack((MWD_matrix,Total_Main_EV_matrix))

            EV_Matrix_columns=[]
            for h in range(6):
                EV_Matrix_columns.append(Step1_Mat_column[h])
            EV_Matrix_columns.append(Step1_Mat_column[8])
            EV_Matrix_columns.append(Step1_Mat_column[9])
            EV_Matrix_columns.append(Step1_Mat_column[10])
            EV_Matrix_columns.append(Step1_Mat_column[12])
            EV_Matrix_columns.append(Step1_Mat_column[11])
            EV_Matrix_columns.append(Step1_Mat_column[13])
            EV_Matrix_columns.append(Step1_Mat_column[15])
            EV_Matrix_columns.append(Step1_Mat_column[14])
            EV_Matrix_columns.append(Step1_Mat_column[16])
            EV_Matrix_columns.append(Step1_Mat_column[17])

            ####Adding living and working place into the Total_Main_EV_matrix

            Total_Main_EV_matrix=np.hstack((Total_Main_EV_matrix,np.zeros((len(Total_Main_EV_matrix),2))))
            Total_Main_EV_matrix=Total_Main_EV_matrix.astype('object') #because of adding string to float numpy
            EV_ID_col=4
            EV_Living_col=14



            EV_Living_keys = list(EV_Living_Zone.keys())
            for h in range(len(EV_Living_keys)):
                EV_ID_mask=EV_Living_Zone[EV_Living_keys[h]]
                idx=is_in_set_func(Total_Main_EV_matrix[:,EV_ID_col], EV_ID_mask)
                Total_Main_EV_matrix[idx, EV_Living_col]=EV_Living_keys[h]

            EV_Working_keys = list(EV_Working_Zone.keys())
            for h in range(len(EV_Working_keys)):
                EV_ID_mask = EV_Working_Zone[EV_Working_keys[h]]
                idx = is_in_set_func(Total_Main_EV_matrix[:, EV_ID_col], EV_ID_mask)
                Total_Main_EV_matrix[idx, EV_Living_col+1] = EV_Working_keys[h]


            HH_mask=np.where((Total_Main_EV_matrix[:,6]==1)&(Total_Main_EV_matrix[:,7]==1))
            Total_Main_EV_matrix[HH_mask,8:14]=np.zeros((len(HH_mask[0]),6))

            # EV_Matrix_columns=[0'Year',1'Month',2'Week',3'Day',4'EV_ID',5'Travel Distance [km]',6'Travel Time[hour]',7'Driving Type',8'From',9'To',10'First Departure Time [h]',11'Duration Time at TO',12'Arrival Time [h]', 13'Second Departure Time [h]']
            Total_Main_EV_matrix=pd.DataFrame(Total_Main_EV_matrix,columns=EV_Matrix_columns)


            DT_code=list(Driver_type_ID.keys())

            for h in range(len(DT_code)):
                Total_Main_EV_matrix['Driving Type']=Total_Main_EV_matrix['Driving Type'].replace(h,DT_code[h])


            TD_code=list(Trip_Destination.keys())
            for h in range(len(TD_code)):
                Total_Main_EV_matrix['From']=Total_Main_EV_matrix['From'].replace(h + 1, TD_code[h])
                Total_Main_EV_matrix['To']=Total_Main_EV_matrix['To'].replace(h + 1, TD_code[h])

            Total_Main_EV_matrix['Year'] = Total_Main_EV_matrix['Year'].astype(int)
            Total_Main_EV_matrix['Month'] = Total_Main_EV_matrix['Month'].astype(int)
            Total_Main_EV_matrix['Week']=Total_Main_EV_matrix['Week'].astype(int)
            Total_Main_EV_matrix['Day']=Total_Main_EV_matrix['Day'].astype(int)
            Total_Main_EV_matrix['EV_ID']=Total_Main_EV_matrix['EV_ID'].astype(int)

            # convert Departure and Arrival hours of BEV to zero if they are at home
            mask_pd = (Total_Main_EV_matrix['Travel Distance [km]'] == 0).to_numpy().reshape(-1,1)
            mask_pd=np.where(mask_pd==True)[0]
            Departure_hour = Departure_hour.to_numpy()
            Departure_hour[mask_pd,0]=0
            Arrival_hour=Arrival_hour.to_numpy()
            Arrival_hour[mask_pd,0]=0

            Arrival_hour=pd.DataFrame(Arrival_hour)
            Departure_hour=pd.DataFrame(Departure_hour)


            ###############################################
            Departure_hour_format = Departure_hour_format.to_numpy()
            Arrival_hour_format = Arrival_hour_format.to_numpy()

            HM_zero = np.zeros((len(Departure_hour), 1))  # create a vector with hour and minute equal to zero
            HM_zero = Hour_Minute(HM_zero).to_numpy()

            Departure_hour_format[mask_pd] = HM_zero[mask_pd]
            Arrival_hour_format[mask_pd] = HM_zero[mask_pd]

            Dep_col = 'Departure_Time'
            Arr_col = 'Arrival_Time'

            Departure_hour_format = pd.DataFrame(Departure_hour_format, columns=[Dep_col])
            Arrival_hour_format = pd.DataFrame(Arrival_hour_format, columns=[Arr_col])

            Departure_hour_format[Dep_col] = pd.to_datetime(Departure_hour_format[Dep_col])
            Arrival_hour_format[Arr_col] = pd.to_datetime(Arrival_hour_format[Arr_col])

            Departure_hour_format[Dep_col] = Departure_hour_format[Dep_col].dt.time
            Arrival_hour_format[Arr_col] = Arrival_hour_format[Arr_col].dt.time

            ####New part
            cols = ['Year', 'Month', 'Day']
            # Remove rows where 'Month' is not a desired month
            Total_Main_EV_matrix = Total_Main_EV_matrix[Total_Main_EV_matrix['Month'] == Sim_Month]

            df = pd.to_datetime(Total_Main_EV_matrix[cols])
            df = pd.DataFrame(df.dt.date)
            df_col = list(df.columns)

            Total_Main_EV_matrix['Departure_Time'] = pd.to_datetime(df[df_col[0]].astype(str) + ' ' + Departure_hour_format[Dep_col].astype(str),format='%Y-%m-%d %H:%M:%S')
            Total_Main_EV_matrix['Arrival_Time'] = pd.to_datetime(df[df_col[0]].astype(str) + ' ' + Arrival_hour_format[Arr_col].astype(str), format='%Y-%m-%d %H:%M:%S')

            Total_Main_EV_matrix = Total_Main_EV_matrix[Step1_Mat_column]

            del mask_pd, df, Departure_hour_format, Arrival_hour_format

            ##############################################
            ############Assigning electricity rate plan for EV owners from 4 TEPCO electricity rate plans#######################
            # Flexible Plan:1, Night Plan 8:2, Night Plan 12:3, and Smart Life S: 4
            EV_Ele_Rate_Plan=np.arange(Num_EV).reshape(-1,1)
            EV_Ele_Rate_Plan=np.hstack((EV_Ele_Rate_Plan,np.random.randint(low=1, high=5, size=Num_EV).reshape(-1, 1)))

            EV_Ele_Rate_Plan = pd.DataFrame(EV_Ele_Rate_Plan,columns=[EV_Matrix_columns[4],'TEPCO Plan'])

            Total_Main_EV_matrix['Sort']=pd.DataFrame(np.arange(len(Total_Main_EV_matrix)))

            Total_Main_EV_matrix = pd.merge(Total_Main_EV_matrix, EV_Ele_Rate_Plan)
            Total_Main_EV_matrix=Total_Main_EV_matrix.sort_values('Sort')
            Total_Main_EV_matrix = Total_Main_EV_matrix.drop('Sort', axis=1)

            col=list(Total_Main_EV_matrix.columns)

            int_col=[0,1,2,3,4]
            float_col=[10,11,12,13,14,15,18]

            for i in range(len(int_col)):
                Total_Main_EV_matrix[col[int_col[i]]] = Total_Main_EV_matrix[col[int_col[i]]].astype(int)
            for i in range(len(float_col)):
                Total_Main_EV_matrix[col[float_col[i]]] = Total_Main_EV_matrix[col[float_col[i]]].astype(float)


            for col in Total_Main_EV_matrix.columns:
                if Total_Main_EV_matrix[col].dtype == 'object' or pd.api.types.is_string_dtype(Total_Main_EV_matrix[col]):
                    Total_Main_EV_matrix[col] = Total_Main_EV_matrix[col].astype(str)

            Total_Main_EV_matrix=ABS_Check(Total_Main_EV_matrix)


            Storing_SQLite_DB_func(Storage_path,Total_Main_EV_matrix,Output_File_Counter)

            del Total_Main_EV_matrix

    return
