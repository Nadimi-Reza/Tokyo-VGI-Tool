import numpy as np
import pandas as pd
import os,sys
import random
import openpyxl as xl
import sqlite3
import Global_Var as GV


Input_list=GV.Step_2_Input_list



def Rand_Sample_Generation_Weighted_func(Inp_prob,Num_Rnd):
    try:
        n_row, n_col = Inp_prob.shape
        Data = np.arange(1, n_row * n_col + 1).tolist()
        weight = tuple(Inp_prob.flatten().tolist())
    except:
        n_row=len(Inp_prob)
        Data= np.arange(1, n_row+ 1).tolist()
        weight = tuple(Inp_prob.flatten().tolist())
    # Rnd = random.choices(Data, weights=weight, k=Num_Rnd)
    return (np.array(random.choices(Data, weights=weight, k=Num_Rnd)))

def Storing_SQLite_Initial_Matrix_func(Storing_path,SQLite_File_Inp):
    Output_path = Storing_path + '\\{}.db'.format(GV.Initial_Mat_Sqlit_Name)

    if os.path.exists(Output_path):
        os.remove(Output_path)


    # Create your connection.
    conn = sqlite3.connect(Output_path)

    #Storing data into conn
    SQLite_File_Inp.to_sql(name='BEV_Data', con=conn)

    if conn:
        conn.close()

    return


# determine if application is a script file or frozen exe
if getattr(sys, 'frozen', False):
    application_path = os.path.dirname(sys.executable)
elif __file__:
    application_path = os.path.dirname(__file__)

def Initial_Matrix_Generation (Num_BEV):

    Initial_Matrix=np.zeros((Num_BEV,len(GV.Initial_Matrix_col))) #BEV ID, living zone, working zone, and TEPCO plan
    Initial_Matrix=Initial_Matrix.astype(object)
    IM_dic = {value:index for index, value in enumerate(GV.Initial_Matrix_col)}
    Initial_Matrix[:,IM_dic[GV.Initial_Matrix_col[0]]]=np.arange(Num_BEV) #Assigning BEV ID

    #############Asssigning zone label(zl) to drivers##############################
    Inp_zl_path = sys.path[0] + '\\' + Input_list[0]

    sheet_name = xl.load_workbook(Inp_zl_path).sheetnames

    for i in range(len(sheet_name)):
        if i==0:
            Inp_Zone = pd.read_excel(Inp_zl_path,sheet_name=sheet_name[i]).to_numpy()
        else:
            Zone_Inp_Out=pd.read_excel(Inp_zl_path,sheet_name=sheet_name[i]).to_numpy()

    Zone_name = GV.Main_14_Zone
    Main_Zone_name=GV.Main_14_Zone
    Inp_zl_prob=Inp_Zone[:, 1]
    Inp_Commuter_prob=Inp_Zone[:, 2]
    zl_Rnd_pos=Rand_Sample_Generation_Weighted_func(Inp_zl_prob.flatten(), Num_BEV)

    Commuter_prob=Inp_Commuter_prob[zl_Rnd_pos-1]
    BEV_zone=Zone_name[zl_Rnd_pos-1].reshape(-1,1)
    Initial_Matrix[:, IM_dic[GV.Initial_Matrix_col[1]]]=BEV_zone[:,0]

    #############################Type of drivers (commuter:1 or non-commuter:0)#################
    Driver_type_weekdays=np.random.rand(Num_BEV)
    Driver_type_weekdays=np.array(np.where(Driver_type_weekdays<=Commuter_prob, 1,0)).reshape(-1,1)

    #It ensures the existance of one BEV without commuting in the BEV list at least.
    if (np.count_nonzero(Driver_type_weekdays))==len(Driver_type_weekdays):
        BEV_choose=np.random.randint(0,len(Driver_type_weekdays))
        Driver_type_weekdays[BEV_choose]=0



    #####################Determine if a commuter BEV works inside Zone or in another zone##########################
    BEV_working_zone=BEV_zone.copy()
    mask_prime = np.where(Driver_type_weekdays == np.array(1))
    BEV_Commuter=BEV_working_zone[mask_prime[0],0]
    unique, counts = np.unique(BEV_Commuter, return_counts=True)
    for i in range(len(unique)):
        mask=np.where((Driver_type_weekdays==np.array(1))&(BEV_working_zone==unique[i]))
        Zone_index=np.where(Zone_Inp_Out[:,0]==unique[i])[0][0]
        BEV_working_zone[mask[0],0]=Zone_name[Rand_Sample_Generation_Weighted_func(Zone_Inp_Out[Zone_index,1:], len(mask[0]))-1]

    Initial_Matrix[:, IM_dic[GV.Initial_Matrix_col[2]]]=BEV_working_zone[:,0]
    # BEV_Living_Zone and BEV_Working_Zone are created to check if a BEV battery charging/discharging is carried out inside the living place or outside of it
    # Clustering BEV_ID in terms of BEV_zone (two columns, the first column for living city and the second column for working city)

    unique, counts = np.unique(BEV_zone, return_counts=True)
    BEV_Living_Zone = dict()
    for i in range(len(unique)):
        key=unique[i]
        value=np.where(BEV_zone==key)[0]
        BEV_Living_Zone[key]=value

    unique, counts = np.unique(BEV_working_zone, return_counts=True)
    BEV_Working_Zone = dict()
    for i in range(len(unique)):
        key = unique[i]
        value = np.where(BEV_working_zone == key)[0]
        BEV_Working_Zone[key] = value


    Initial_Matrix[:,3]=Driver_type_weekdays.reshape(-1,)
    Initial_Matrix=pd.DataFrame(Initial_Matrix,columns=GV.Initial_Matrix_col)
    GV.Initial_BEV_Mat=Initial_Matrix

    Storing_SQLite_Initial_Matrix_func(application_path, Initial_Matrix)









