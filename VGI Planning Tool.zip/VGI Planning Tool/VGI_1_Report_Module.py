import sys
import pandas as pd
import numpy as np
import warnings
import os
import sqlite3
from natsort import natsorted



import VGI_2_Driving_Profile_Module as Step2_Module
import VGI_3_Electricity_Consumption_Module as Step3_Module
import VGI_4_Charging_Power_Rating_Module as Step4_Module
import Global_Var as GV


warnings.filterwarnings('ignore')



def V2G_Report_func(Storage_path):

	V2G_col = ['BEV ID','Zone', 'Charging_Place', 'Date_Time']
	V2G_final_col = ['BEV ID','Zone', 'Charging_Place', 'Year', 'Month', 'Day']
	for i in range(1, 49):
		V2G_col.append('SP_{}'.format(i))
		V2G_final_col.append('SP_{}'.format(i))
	Inp_V2G_Data = pd.DataFrame(GV.V2G_Matrix, columns=V2G_col)
	df = pd.to_datetime(Inp_V2G_Data[V2G_col[3]])
	# df=Inp_V2G_Data[V2G_col[2]]
	Inp_V2G_Data['Year'] = df.dt.year
	Inp_V2G_Data['Month'] = df.dt.month
	Inp_V2G_Data['Day'] = df.dt.day

	del df

	Inp_V2G_Data = Inp_V2G_Data[V2G_final_col]

	#Total Tokyo Metropolitan analysis

	df_col = list(Inp_V2G_Data.columns)
	values_col = df_col[6:]
	Index_col = [df_col[1], df_col[2], df_col[4], df_col[5]]

	table = pd.pivot_table(Inp_V2G_Data, values=values_col, index=Index_col, aggfunc="sum")

	table = table.reset_index()
	table=table.drop(V2G_col[1],axis=1)



	Output_path = Storage_path + '\\Step2_3_Total_Tokyo_BEV_Vehicle_2_Grid.csv'
	table.to_csv(Output_path, index=False)

	#14 main zones analysis
	values_col = df_col[6:]
	Index_col = [df_col[1],df_col[2], df_col[4], df_col[5]]

	table = pd.pivot_table(Inp_V2G_Data, values=values_col, index=Index_col, aggfunc="sum")
	table = table.reset_index()

	Output_path = Storage_path + '\\Step2_3_Zone_Based_BEV_Vehicle_2_Grid.csv'
	table.to_csv(Output_path, index=False)



def Reading_SQLite_DB_func(Storing_path):
	# Create a SQL connection to the SQLite database
	con = sqlite3.connect(Storing_path)

	#Reading data from EV_Data table
	df = pd.read_sql_query('SELECT * FROM EV_Data', con)

	# Drop the index column
	try:
		df = df.drop('index', axis=1)
	except:
		pass

	# close the connection
	con.close()
	return (df)


def Tail_Head_Sum_func(df_t,df_h,selected_row):
	df_t = df_t.tail(selected_row)
	df_t.reset_index(drop=True, inplace=True)
	df_h = df_h.head(selected_row)
	df_h.reset_index(drop=True, inplace=True)
	return (df_t.iloc[:, 0:] + df_h.iloc[:, 0:])




# determine if application is a script file or frozen exe
if getattr(sys, 'frozen', False):
	application_path = os.path.dirname(sys.executable)
elif __file__:
	application_path = os.path.dirname(__file__)


def Main_func_Step1(Inp_param):
	Inp_parameter=Inp_param.copy()
	BEV_Num=Inp_parameter[0]
	Output_list=Inp_parameter[1]
	Simulation_Month=Inp_parameter[2]
	Simulation_Day_in_Month = Inp_parameter[3]
	Simulation_year=Inp_parameter[4]
	GV.Trip_Module_Run_Flag=Inp_parameter[5]
	GV.Model_V2G_Service_Flag=Inp_parameter[6]
	GV.Unmanaged_Charging_Flag=Inp_parameter[7]
	GV.SoC_Charging_Cycle_Flag=Inp_parameter[8]



	Step1_Mat_column = GV.Step1_Matrix_column_name

	Main_Zone_name = GV.Main_14_Zone

	#parameters definition
	Num_EV= BEV_Num
	Simu_year=Simulation_year
	Settlement_period=48 #The simulation resolution is 30-minute (24 hours *2 )

	Max_CSV_Rows=250000 #250000
	BEV_day_col=3


	if GV.Trip_Module_Run_Flag==True:
		Search_path = application_path + '\\' + Output_list[0]
		if not os.path.exists(Search_path):
			os.makedirs(Search_path)
		else:
			files = os.listdir(Search_path)
			for f in files:
				File_path = Search_path + '\\' + f
				os.remove(File_path)
		Step2_Module.Main_Function_Step2(Num_EV, Simulation_Day_in_Month,Simulation_Month,Simu_year,Step1_Mat_column,Main_Zone_name,Search_path,Max_CSV_Rows)


	Search_path= application_path + '\\' + Output_list[0]
	File_Names=os.listdir(Search_path)
	EV_Files = [s for s in File_Names if "Step1_BEV Mobility_" in s]
	EV_Files=natsorted(EV_Files)

	if len(EV_Files)==1:
		File_path = Search_path + '\\' + EV_Files[0]
		EV_Driving_Profile_Data = Reading_SQLite_DB_func(File_path)
		Step1_Mat_column = list(EV_Driving_Profile_Data.columns)

		##base year,month, and day are set here
		GV.base_year = EV_Driving_Profile_Data.iloc[0,0]
		GV.base_month = EV_Driving_Profile_Data.iloc[0,1]
		GV.base_day = EV_Driving_Profile_Data.iloc[0,3] #column 2 represents the week which we skip here

		G2V_Data, G2V_Data_Zone, G2V_EVNumQueue, G2V_EVNumQueue_Zone,BEV_Power_Consumption = Step3_Module.Main_Function_Step3(Num_EV, Simu_year, EV_Driving_Profile_Data, Step1_Mat_column, Main_Zone_name,Simulation_Month)
		c=1
	else:

		for EV_file_counter in range(len(EV_Files)):
			File_path=Search_path+'\\' +EV_Files[EV_file_counter]
			EV_Driving_Profile_Data = Reading_SQLite_DB_func(File_path)
			Step1_Mat_column = list(EV_Driving_Profile_Data.columns)
			daycol=Step1_Mat_column[3]
			# daycol=EV_Driving_Profile_Data.columns.get_loc(daycol)
			if EV_file_counter == 0:
				##base year,month, and day are set here
				GV.base_year = EV_Driving_Profile_Data.iloc[0, 0]
				GV.base_month = EV_Driving_Profile_Data.iloc[0, 1]
				GV.base_day = EV_Driving_Profile_Data.iloc[0, 3]  # column 2 represents the week which we skip here

				last_day = EV_Driving_Profile_Data.loc[EV_Driving_Profile_Data.index[-1], daycol]-1

				BEV_Day_Data = EV_Driving_Profile_Data[Step1_Mat_column[BEV_day_col]].to_numpy()
				Idx_Day_last_day = np.where(BEV_Day_Data == last_day)[0]
				Idx_Day_last_day = Idx_Day_last_day[-1] + 1
				del BEV_Day_Data

				Remained_Data = EV_Driving_Profile_Data.iloc[Idx_Day_last_day:, :]
				Input_Data = EV_Driving_Profile_Data.iloc[:Idx_Day_last_day, :]
				Remained_Data.reset_index(drop=True, inplace=True)

			elif EV_file_counter==len(EV_Files)-1:

				Input_Data=pd.concat([Remained_Data,EV_Driving_Profile_Data], ignore_index = True)
				Input_Data.reset_index(drop=True, inplace=True)
			else:

				EV_Driving_Profile_Data = pd.concat([Remained_Data, EV_Driving_Profile_Data], ignore_index=True)
				EV_Driving_Profile_Data.reset_index(drop=True, inplace=True)

				last_day = EV_Driving_Profile_Data.loc[EV_Driving_Profile_Data.index[-1], daycol]-1
				BEV_Day_Data = EV_Driving_Profile_Data[Step1_Mat_column[BEV_day_col]].to_numpy()
				Idx_Day_last_day = np.where(BEV_Day_Data == last_day)[0]
				Idx_Day_last_day = Idx_Day_last_day[-1] + 1
				del BEV_Day_Data

				Remained_Data = EV_Driving_Profile_Data.iloc[Idx_Day_last_day:, :]
				Input_Data = EV_Driving_Profile_Data.iloc[:Idx_Day_last_day, :]
				Remained_Data.reset_index(drop=True, inplace=True)


				# Input_Data=EV_Driving_Profile_Data.iloc[]
			G2V_Data_init, G2V_Data_Zone_init, G2V_EVNumQueue_init, G2V_EVNumQueue_Zone_init,BEV_Power_Consumption = Step3_Module.Main_Function_Step3(Num_EV, Simu_year, Input_Data, Step1_Mat_column, Main_Zone_name,Simulation_Month)


			if EV_file_counter==0:
				G2V_Data=G2V_Data_init
				G2V_Data_Zone=G2V_Data_Zone_init
				G2V_EVNumQueue=G2V_EVNumQueue_init
				G2V_EVNumQueue_Zone=G2V_EVNumQueue_Zone_init
			else:
				selected_row = 48

				G2V_Data.iloc[-selected_row:, :] = Tail_Head_Sum_func(G2V_Data, G2V_Data_init, selected_row)
				G2V_Data = pd.concat([G2V_Data,G2V_Data_init.iloc[selected_row:,:]], ignore_index = True)

				G2V_Data_Zone.iloc[-selected_row:, :] = Tail_Head_Sum_func(G2V_Data_Zone, G2V_Data_Zone_init, selected_row)
				G2V_Data_Zone = pd.concat([G2V_Data_Zone,G2V_Data_Zone_init.iloc[selected_row:,:]], ignore_index = True)

				G2V_EVNumQueue.iloc[-selected_row:, :] = Tail_Head_Sum_func(G2V_EVNumQueue, G2V_EVNumQueue_init, selected_row)
				G2V_EVNumQueue = pd.concat([G2V_EVNumQueue,G2V_EVNumQueue_init.iloc[selected_row:,:]], ignore_index = True)

				G2V_EVNumQueue_Zone.iloc[-selected_row:, :] = Tail_Head_Sum_func(G2V_EVNumQueue_Zone, G2V_EVNumQueue_Zone_init, selected_row)
				G2V_EVNumQueue_Zone = pd.concat([G2V_EVNumQueue_Zone,G2V_EVNumQueue_Zone_init.iloc[selected_row:,:]], ignore_index = True)

				###



	Step2_3_Mat_column=list(GV.SoC.columns)

	GV.SoC[Step2_3_Mat_column[1]]=GV.SoC[Step2_3_Mat_column[1]].astype(float).round(2)



	Output_path = application_path + '\\' + Output_list[0]+'\\Step2_3_Total_Tokyo_BEV_Charging.csv'
	GV.SoC.to_csv(Output_path,index=False)




	if len(EV_Files)==1:
		Average_Daily_G2V_Charging_Data=Step4_Module.Charging_G2V_plot(G2V_Data,agg_func='sum')
	else:
		Average_Daily_G2V_Charging_Data = Step4_Module.Charging_G2V_plot(G2V_Data, agg_func='mean')

	Average_Daily_G2V_EVNumQueue=Step4_Module.Charging_G2V_plot(G2V_EVNumQueue,agg_func='max')

	Output_path = application_path + '\\' + Output_list[0]+'\\Step2_3_Total_Tokyo_Average_Daily_Grid_2_Vehicle.csv'
	Average_Daily_G2V_Charging_Data.to_csv(Output_path,index=False)


	Output_path = application_path + '\\' + Output_list[0]+'\\Step2_3_Total_Tokyo_Maximum_Daily_BEV_Queue.csv'
	Average_Daily_G2V_EVNumQueue.to_csv(Output_path,index=False)

	if len(EV_Files)==1:
		Average_Daily_G2V_Charging_Data_Based_on_Zone=Step4_Module.Charging_G2V_plot(G2V_Data_Zone,agg_func='sum')
	else:
		Average_Daily_G2V_Charging_Data_Based_on_Zone = Step4_Module.Charging_G2V_plot(G2V_Data_Zone, agg_func='mean')

	Average_Daily_G2V_EVNumQueue_Based_on_Zone=Step4_Module.Charging_G2V_plot(G2V_EVNumQueue_Zone,agg_func='max')

	Output_path = application_path + '\\' + Output_list[0]+'\\Step2_3_Zone_Based_Average_Daily_Grid_2_Vehicle.csv'
	Average_Daily_G2V_Charging_Data_Based_on_Zone.to_csv(Output_path,index=False)

	Output_path = application_path + '\\' + Output_list[0]+'\\Step2_3_Zone_Based_Average_Daily_BEV_Queue.csv'
	Average_Daily_G2V_EVNumQueue_Based_on_Zone.to_csv(Output_path,index=False)

	repeat_times=int(len(G2V_Data)/Settlement_period)
	SP=np.arange(1,Settlement_period+1).tolist()*repeat_times
	G2V_Data.insert(loc=0, column='Settlement Period', value=SP)
	Output_path = application_path + '\\' + Output_list[0]+'\\Step2_3_Total_Tokyo_BEV_Energy_Usage.csv'
	G2V_Data.to_csv(Output_path,index=False)


	G2V_Data_Zone.insert(loc=0, column='Settlement Period', value=SP)
	Output_path = application_path + '\\' + Output_list[0]+'\\Step2_3_Zone_Based_BEV_Energy_Usage_Data.csv'
	G2V_Data_Zone.to_csv(Output_path,index=False)


	##V2G report
	Output_path = application_path + '\\' + Output_list[0]

	V2G_Report_func(Output_path)
